-- =============================================================
-- Phase 2 RPCs — server-authoritative spin + pending-win flow
-- Run this AFTER supabase-schema.sql.
-- Idempotent: safe to re-run.
-- =============================================================

-- ---------- perform_spin --------------------------------------
-- Server picks the outcome and slice index. Enforces daily cap.
-- Returns the new spin row plus optional pending_win id.
-- =============================================================

create or replace function public.perform_spin(
  p_called_shot text default null,
  p_force_miss boolean default false,
  p_rare_bias boolean default false,
  p_bonus_odds boolean default false
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_today date := (now() at time zone 'utc')::date;
  v_stats public.player_stats%rowtype;
  v_daily_cap constant int := 12;
  v_slices jsonb := '[
    {"i":0,"type":"win"},   {"i":1,"type":"miss"}, {"i":2,"type":"miss"}, {"i":3,"type":"miss"},
    {"i":4,"type":"jolly"}, {"i":5,"type":"miss"}, {"i":6,"type":"miss"}, {"i":7,"type":"bonus"},
    {"i":8,"type":"miss"},  {"i":9,"type":"miss"}, {"i":10,"type":"miss"},{"i":11,"type":"miss"},
    {"i":12,"type":"rare"}, {"i":13,"type":"miss"},{"i":14,"type":"miss"},{"i":15,"type":"jolly"},
    {"i":16,"type":"miss"}, {"i":17,"type":"miss"},{"i":18,"type":"bonus"},{"i":19,"type":"miss"},
    {"i":20,"type":"miss"}, {"i":21,"type":"miss"},{"i":22,"type":"miss"},{"i":23,"type":"miss"}
  ]'::jsonb;
  v_seed bytea := gen_random_bytes(8);
  v_r1 float8;
  v_r2 float8;
  v_target_index int;
  v_outcome text;
  v_bonus_awarded boolean := false;
  v_wins_delta int := 0;
  v_ink_delta int := 0;
  v_streak_delta int := 0;
  v_spin_id uuid;
  v_pending_id uuid;
begin
  if v_user is null then
    raise exception 'unauthenticated' using errcode = '28000';
  end if;

  -- Lock the player_stats row (auto-created by handle_new_user trigger).
  select * into v_stats from public.player_stats where user_id = v_user for update;
  if not found then
    insert into public.player_stats(user_id) values (v_user) returning * into v_stats;
  end if;

  -- Reset daily counter if last_spin_date changed.
  if v_stats.last_spin_date is distinct from v_today then
    v_stats.spins_today := 0;
  end if;

  if v_stats.spins_today >= v_daily_cap then
    raise exception 'daily_cap_reached' using errcode = 'P0001';
  end if;

  -- Two uniform [0,1) randoms derived from the seed.
  v_r1 := (get_byte(v_seed, 0)::int * 256 + get_byte(v_seed, 1)::int) / 65536.0;
  v_r2 := (get_byte(v_seed, 2)::int * 256 + get_byte(v_seed, 3)::int) / 65536.0;

  -- Pick target index honoring modifiers.
  if p_force_miss then
    -- pick a miss index
    with miss as (
      select (s->>'i')::int as i from jsonb_array_elements(v_slices) s where s->>'type' = 'miss'
    )
    select i into v_target_index from miss order by (random()) limit 1;
  elsif p_rare_bias and v_r1 < 0.55 then
    with rare as (
      select (s->>'i')::int as i from jsonb_array_elements(v_slices) s where s->>'type' = 'rare'
    )
    select i into v_target_index from rare order by (random()) limit 1;
  elsif p_bonus_odds and v_r1 < 0.8 then
    with prize as (
      select (s->>'i')::int as i from jsonb_array_elements(v_slices) s where s->>'type' in ('win','rare','bonus')
    )
    select i into v_target_index from prize order by (random()) limit 1;
  else
    v_target_index := floor(v_r1 * 24)::int;
    -- Difficulty: ~80% of raw wins get downgraded to a miss for tension.
    if (v_slices -> v_target_index ->> 'type') = 'win' and v_r2 < 0.8 then
      with miss as (
        select (s->>'i')::int as i from jsonb_array_elements(v_slices) s where s->>'type' = 'miss'
      )
      select i into v_target_index from miss order by (random()) limit 1;
    end if;
  end if;

  v_outcome := v_slices -> v_target_index ->> 'type';

  -- Compute deltas.
  if v_outcome in ('win','rare','bonus') then
    v_wins_delta := 1;
    v_streak_delta := 1;
  elsif v_outcome = 'jolly' then
    v_streak_delta := 1;
  end if;
  v_ink_delta := case v_outcome when 'rare' then 10 when 'win' then 3 when 'bonus' then 2 else 0 end;

  -- Bonus awarded if called shot matched.
  if p_called_shot is not null and p_called_shot = v_outcome then
    v_bonus_awarded := true;
  end if;

  -- Streak continuity: if user missed yesterday or earlier and today is a win/jolly, still +1.
  -- If user missed today (no streak_delta) and last_spin_date is more than 1 day ago, reset to 0.
  if v_streak_delta = 0 and (v_stats.last_spin_date is null or v_stats.last_spin_date < v_today - 1) then
    v_stats.streak := 0;
  end if;

  -- Insert spin row.
  insert into public.spins(user_id, outcome, slice_index, called_shot, bonus_awarded, seed)
  values (v_user, v_outcome::public.spin_outcome, v_target_index, p_called_shot, v_bonus_awarded, v_seed)
  returning id into v_spin_id;

  -- Update stats.
  update public.player_stats
     set spins_today = v_stats.spins_today + 1,
         spins_total = spins_total + 1,
         wins_total  = wins_total + v_wins_delta,
         streak      = greatest(0, v_stats.streak + v_streak_delta),
         last_spin_date = v_today,
         ink_drops   = ink_drops + v_ink_delta + (case when v_bonus_awarded then 1 else 0 end)
   where user_id = v_user
   returning * into v_stats;

  -- Create pending_win for postable outcomes.
  if v_outcome in ('win','rare') then
    insert into public.pending_wins(user_id, spin_id, outcome, expires_at)
    values (v_user, v_spin_id, v_outcome::public.spin_outcome, now() + interval '10 minutes')
    returning id into v_pending_id;
  end if;

  return jsonb_build_object(
    'spin_id', v_spin_id,
    'outcome', v_outcome,
    'slice_index', v_target_index,
    'bonus_awarded', v_bonus_awarded,
    'pending_win_id', v_pending_id,
    'stats', to_jsonb(v_stats)
  );
end;
$$;

revoke all on function public.perform_spin(text, boolean, boolean, boolean) from public;
grant execute on function public.perform_spin(text, boolean, boolean, boolean) to authenticated;

-- ---------- publish_pending_win -------------------------------
-- Move a pending_win into posts (after user typed body).
-- =============================================================

create or replace function public.publish_pending_win(
  p_pending_id uuid,
  p_body text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_pw public.pending_wins%rowtype;
  v_post_id uuid;
begin
  if v_user is null then raise exception 'unauthenticated' using errcode='28000'; end if;
  if p_body is null or length(btrim(p_body)) < 1 or length(p_body) > 600 then
    raise exception 'invalid_body' using errcode='22023';
  end if;

  select * into v_pw from public.pending_wins
   where id = p_pending_id and user_id = v_user for update;
  if not found then raise exception 'not_found' using errcode='P0002'; end if;
  if v_pw.expires_at < now() then
    delete from public.pending_wins where id = v_pw.id;
    raise exception 'expired' using errcode='P0001';
  end if;

  insert into public.posts(user_id, spin_id, outcome, body)
  values (v_user, v_pw.spin_id, v_pw.outcome, p_body)
  returning id into v_post_id;

  delete from public.pending_wins where id = v_pw.id;

  return jsonb_build_object('post_id', v_post_id);
end;
$$;

revoke all on function public.publish_pending_win(uuid, text) from public;
grant execute on function public.publish_pending_win(uuid, text) to authenticated;

-- ---------- discard_pending_win -------------------------------
create or replace function public.discard_pending_win(p_pending_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'unauthenticated' using errcode='28000'; end if;
  delete from public.pending_wins where id = p_pending_id and user_id = v_user;
end;
$$;

revoke all on function public.discard_pending_win(uuid) from public;
grant execute on function public.discard_pending_win(uuid) to authenticated;

-- ---------- toggle_reaction -----------------------------------
create or replace function public.toggle_reaction(p_post_id uuid, p_kind text)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user uuid := auth.uid();
  v_existing uuid;
begin
  if v_user is null then raise exception 'unauthenticated' using errcode='28000'; end if;
  if p_kind not in ('hear','seal','crown') then raise exception 'invalid_kind' using errcode='22023'; end if;

  select id into v_existing from public.reactions
   where post_id = p_post_id and user_id = v_user and kind = p_kind;
  if v_existing is not null then
    delete from public.reactions where id = v_existing;
    return false;
  end if;
  insert into public.reactions(post_id, user_id, kind) values (p_post_id, v_user, p_kind);
  return true;
end;
$$;

revoke all on function public.toggle_reaction(uuid, text) from public;
grant execute on function public.toggle_reaction(uuid, text) to authenticated;

-- ---------- helpful indexes -----------------------------------
create index if not exists idx_spins_user_created on public.spins(user_id, created_at desc);
create index if not exists idx_posts_created on public.posts(created_at desc);
create index if not exists idx_reactions_post on public.reactions(post_id);
create index if not exists idx_pending_user on public.pending_wins(user_id);
