import { createClient, type SupabaseClient } from "@supabase/supabase-js";

// Read URL + anon key from the SSR-injected window.__SUPABASE_CONFIG__ on
// the client, and from process.env during SSR. Both values are publishable.
type Cfg = { url: string; anonKey: string };

function readConfig(): Cfg {
  if (typeof window !== "undefined") {
    const w = (window as unknown as { __SUPABASE_CONFIG__?: Cfg }).__SUPABASE_CONFIG__;
    if (w?.url && w?.anonKey) return w;
  }
  const url = (typeof process !== "undefined" && process.env?.EXTERNAL_SUPABASE_URL) || "";
  const anonKey = (typeof process !== "undefined" && process.env?.EXTERNAL_SUPABASE_ANON_KEY) || "";
  return { url, anonKey };
}

const { url, anonKey } = readConfig();

if (!url || !anonKey) {
  // Avoid hard-throwing during SSR before config injection completes.
  console.warn("[supabase] Missing URL or anon key; auth/storage calls will fail until configured.");
}

export const supabase: SupabaseClient = createClient(url || "http://localhost", anonKey || "anon", {
  auth: {
    persistSession: typeof window !== "undefined",
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storageKey: "keryx-auth",
  },
});
