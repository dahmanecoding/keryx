import { createMiddleware } from "@tanstack/react-start";
import { supabase } from "./client";

// Attaches the current Supabase access token to every server fn request.
export const attachSupabaseAuth = createMiddleware({ type: "function" }).client(
  async ({ next }) => {
    let headers: Record<string, string> = {};
    try {
      const { data } = await supabase.auth.getSession();
      const token = data.session?.access_token;
      if (token) headers = { authorization: `Bearer ${token}` };
    } catch {
      // ignore; server will 401 if a protected fn is hit unauthenticated
    }
    return next({ sendContext: undefined, headers });
  },
);
