import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const url = process.env.EXTERNAL_SUPABASE_URL;
const serviceRoleKey = process.env.EXTERNAL_SUPABASE_SERVICE_ROLE_KEY;

if (!url || !serviceRoleKey) {
  throw new Error(
    "[supabase admin] Missing EXTERNAL_SUPABASE_URL or EXTERNAL_SUPABASE_SERVICE_ROLE_KEY",
  );
}

export const supabaseAdmin: SupabaseClient = createClient(url, serviceRoleKey, {
  auth: { persistSession: false, autoRefreshToken: false },
});
