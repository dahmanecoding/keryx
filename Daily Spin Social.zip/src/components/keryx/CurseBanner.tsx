import { motion } from "framer-motion";

interface CurseBannerProps {
  used: boolean;
}

export function CurseBanner({ used }: CurseBannerProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scaleY: 0.9 }}
      animate={{ opacity: 1, scaleY: 1 }}
      transition={{ duration: 0.35 }}
      className="mx-6 mt-3 flex items-center gap-2 rounded-sm px-3 py-2"
      style={{
        border: "1px dashed var(--ink)",
        background: used ? "rgb(194 65 43 / 0.08)" : "rgb(15 13 11 / 0.04)",
      }}
    >
      <span style={{ fontSize: 14 }}>{used ? "✦" : "✕"}</span>
      <div className="flex flex-1 flex-col leading-tight">
        <span
          className="text-[9px] uppercase"
          style={{
            letterSpacing: "0.3em",
            color: used ? "var(--primary)" : "var(--ink)",
            fontFamily: "JetBrains Mono, monospace",
            fontWeight: 700,
          }}
        >
          {used ? "Curse lifted" : "Curse of the Blank Page"}
        </span>
        <span
          className="font-display italic"
          style={{ fontSize: 12, color: "var(--ink)" }}
        >
          {used
            ? "The page is unmarked. Your next spin tilts toward the prizes."
            : "Your first spin today is a forced miss. Press on — odds boost after."}
        </span>
      </div>
    </motion.div>
  );
}
