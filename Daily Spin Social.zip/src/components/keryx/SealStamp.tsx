import type { Seal } from "@/lib/seals";

interface SealStampProps {
  seal: Seal;
  size?: number;
}

export function SealStamp({ seal, size = 36 }: SealStampProps) {
  return (
    <div
      className="grid place-items-center rounded-full"
      style={{
        width: size,
        height: size,
        background: "radial-gradient(circle at 35% 30%, #d96a4f, var(--primary-deep))",
        border: "1.5px solid var(--ink)",
        boxShadow: "0 4px 10px -4px rgb(15 13 11 / 0.4), inset 0 0 0 2px rgb(255 255 255 / 0.18)",
        color: "var(--paper)",
        fontFamily: "Fraunces, serif",
        fontSize: size * 0.42,
        fontWeight: 800,
        transform: "rotate(-6deg)",
      }}
      title={seal.name}
      aria-label={`Seal: ${seal.name}`}
    >
      {seal.glyph}
    </div>
  );
}
