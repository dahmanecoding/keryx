import { Link, useRouterState } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { Disc3, Library, Users, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { useOverlayOpen } from "@/lib/use-overlay";

const items = [
  { to: "/", label: "Spin", icon: Disc3 },
  { to: "/edition", label: "Edition", icon: Users },
  { to: "/archive", label: "Archive", icon: Library },
  { to: "/profile", label: "Profile", icon: User },
] as const;

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const overlayOpen = useOverlayOpen();

  return (
    <AnimatePresence>
      {!overlayOpen && (
        <motion.nav
          key="bottom-nav"
          initial={{ y: 80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 80, opacity: 0 }}
          transition={{ duration: 0.22, ease: [0.22, 0.61, 0.36, 1] }}
          className="fixed bottom-0 left-1/2 z-40 w-full max-w-[440px] -translate-x-1/2 px-5 pb-5 pt-2"
        >
      <div
        className="flex h-16 items-center rounded-full px-2"
        style={{
          background: "var(--ink)",
          boxShadow: "0 12px 32px -12px rgb(15 13 11 / 0.35)",
        }}
      >
        {items.map(({ to, label, icon: Icon }) => {
          const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
          return (
            <Link
              key={to}
              to={to}
              className={cn(
                "relative flex flex-1 flex-col items-center justify-center gap-1 transition-colors",
              )}
              style={{
                color: active ? "var(--primary)" : "rgb(241 236 224 / 0.45)",
              }}
            >
              <div
                className={cn(
                  "relative grid h-8 w-8 place-items-center rounded-full transition-colors",
                )}
              >
                {active && (
                  <motion.div
                    layoutId="nav-pill"
                    className="absolute inset-0 rounded-full"
                    style={{ background: "rgb(194 65 43 / 0.18)" }}
                    transition={{ type: "tween", duration: 0.22, ease: [0.22, 0.61, 0.36, 1] }}
                  />
                )}
                <Icon className="relative h-4 w-4" strokeWidth={active ? 2.4 : 1.8} />
              </div>
              <span
                className="text-[8px] uppercase"
                style={{ letterSpacing: "0.15em", fontFamily: "JetBrains Mono, monospace" }}
              >
                {label}
              </span>
              {active && (
                <motion.span
                  layoutId="nav-underline"
                  className="absolute -bottom-0.5 h-px w-6"
                  style={{ background: "var(--primary)" }}
                  transition={{ type: "tween", duration: 0.22, ease: [0.22, 0.61, 0.36, 1] }}
                />
              )}
            </Link>
          );
        })}
          </div>
        </motion.nav>
      )}
    </AnimatePresence>
  );
}
