import { useEffect } from "react";
import { useRouter } from "@tanstack/react-router";

/**
 * Preloads sibling route chunks on idle so the first navigation to each
 * tab has no chunk-fetch + parse stall. Renders nothing.
 */
export function AnimationWarmup() {
  const router = useRouter();

  useEffect(() => {
    const routes = ["/", "/archive", "/social", "/profile"] as const;

    const run = () => {
      routes.forEach((to) => {
        router.preloadRoute({ to }).catch(() => {});
      });
    };

    type IdleWindow = Window & {
      requestIdleCallback?: (
        cb: () => void,
        opts?: { timeout?: number },
      ) => number;
      cancelIdleCallback?: (h: number) => void;
    };
    const w = window as IdleWindow;
    let idleId: number | null = null;
    let timeoutId: number | null = null;

    if (w.requestIdleCallback) {
      idleId = w.requestIdleCallback(run, { timeout: 1200 });
    } else {
      timeoutId = window.setTimeout(run, 400);
    }

    return () => {
      if (idleId !== null && w.cancelIdleCallback) w.cancelIdleCallback(idleId);
      if (timeoutId !== null) clearTimeout(timeoutId);
    };
  }, [router]);

  return null;
}
