import { motion, AnimatePresence } from "framer-motion";
import type { CrierEvent } from "@/lib/use-crier";

interface CrierBannerProps {
  event: CrierEvent | null;
}

export function CrierBanner({ event }: CrierBannerProps) {
  return (
    <AnimatePresence>
      {event && (
        <motion.div
          key={event.id}
          initial={{ y: -32, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -32, opacity: 0 }}
          transition={{ duration: 0.4 }}
          className="relative overflow-hidden"
          style={{
            background: "var(--ink)",
            color: "var(--paper)",
          }}
        >
          <motion.div
            className="flex items-center gap-3 px-6 py-2"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            transition={{ duration: 0.6, ease: [0.22, 0.61, 0.36, 1] }}
          >
            <span
              className="grid h-5 w-5 shrink-0 place-items-center rounded-full font-display"
              style={{ background: "var(--primary)", color: "var(--paper)", fontWeight: 800, fontSize: 11 }}
            >
              !
            </span>
            <div className="flex min-w-0 flex-1 items-baseline gap-2">
              <span
                className="text-[9px] uppercase shrink-0"
                style={{
                  letterSpacing: "0.3em",
                  color: "var(--ochre)",
                  fontFamily: "JetBrains Mono, monospace",
                  fontWeight: 700,
                }}
              >
                Crier
              </span>
              <span className="font-display italic truncate" style={{ fontSize: 13 }}>
                {event.title} — {event.copy}
              </span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
