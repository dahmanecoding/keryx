import { motion } from "framer-motion";
import { BADGE_TIERS, getBadgeTier, type Badge } from "@/lib/keryx-data";

interface BadgeChipProps {
  badge: Badge;
  index?: number;
}

export function BadgeChip({ badge, index = 0 }: BadgeChipProps) {
  const tierId = getBadgeTier(badge.count);
  const tier = tierId ? BADGE_TIERS.find((t) => t.id === tierId)! : null;
  const earned = !!tier;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index, 6) * 0.04 }}
      className="relative flex flex-col items-center gap-1 rounded-lg p-3 text-center"
      style={{
        background: earned ? "var(--surface-elevated)" : "var(--surface)",
        border: "1px solid var(--color-border)",
        opacity: earned ? 1 : 0.42,
      }}
    >
      {/* Medallion */}
      <div className="relative">
        <div
          className="grid h-12 w-12 place-items-center rounded-full text-xl"
          style={{
            background: tier ? tier.bg : "var(--muted)",
            border: tier ? `1.5px solid ${tier.ring}` : "1px dashed var(--color-border)",
            boxShadow: tier
              ? `0 4px 14px -4px ${tier.glow}, inset 0 0 0 1.5px rgba(255,255,255,0.18), inset 0 -3px 6px rgba(0,0,0,0.18)`
              : "none",
            color: tier?.fg ?? "var(--muted-foreground)",
          }}
        >
          <span style={{ filter: tier ? "drop-shadow(0 1px 0 rgba(0,0,0,0.25))" : undefined }}>
            {badge.icon}
          </span>
        </div>
        {/* Count chip */}
        {earned && badge.count > 1 && (
          <span
            className="absolute -bottom-1 -right-1 grid h-5 min-w-[20px] place-items-center rounded-full px-1 text-[10px] font-bold tabular-nums"
            style={{
              background: "var(--ink)",
              color: "var(--paper)",
              border: `1.5px solid ${tier!.ring}`,
              fontFamily: "JetBrains Mono, monospace",
              letterSpacing: "0.02em",
            }}
          >
            ×{badge.count}
          </span>
        )}
        {/* Obsidian halo */}
        {tier?.id === "obsidian" && (
          <motion.span
            aria-hidden
            className="absolute inset-0 rounded-full"
            initial={{ opacity: 0.4 }}
            animate={{ opacity: [0.35, 0.7, 0.35] }}
            transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
            style={{
              boxShadow: `0 0 18px 2px ${tier.glow}`,
              pointerEvents: "none",
            }}
          />
        )}
      </div>

      <span
        className="mt-1 text-[9px] uppercase"
        style={{
          letterSpacing: "0.2em",
          fontFamily: "JetBrains Mono, monospace",
          color: "var(--ink)",
          fontWeight: 600,
        }}
      >
        {badge.name}
      </span>
      <span
        className="text-[8px] uppercase"
        style={{
          letterSpacing: "0.25em",
          fontFamily: "JetBrains Mono, monospace",
          color: tier ? tier.fg : "var(--muted-foreground)",
          opacity: 0.85,
        }}
      >
        {tier ? tier.label : "Locked"}
      </span>
    </motion.div>
  );
}
