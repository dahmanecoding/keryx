import type { ReactNode } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useRouterState } from "@tanstack/react-router";
import { BottomNav } from "./BottomNav";
import { CrierBanner } from "./CrierBanner";
import { useCrier } from "@/lib/use-crier";
import { useMotionBudget } from "@/lib/use-motion-budget";
import { AnimationWarmup } from "./AnimationWarmup";

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const { reduceEffects } = useMotionBudget();
  const crier = useCrier();

  const initial = reduceEffects ? { opacity: 0 } : { opacity: 0, y: 8 };
  const animate = { opacity: 1, y: 0 };
  const exit = reduceEffects ? { opacity: 0 } : { opacity: 0, y: -4 };
  const duration = reduceEffects ? 0.12 : 0.22;

  return (
    <div className="relative mx-auto min-h-dvh w-full max-w-[440px] overflow-hidden pb-28">
      <CrierBanner event={crier} />
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={pathname}
          initial={initial}
          animate={animate}
          exit={exit}
          transition={{ duration, ease: [0.22, 0.61, 0.36, 1] }}
          className="relative"
          style={{ willChange: "transform, opacity" }}
        >
          {children}
        </motion.div>
      </AnimatePresence>
      <BottomNav />
      <AnimationWarmup />
    </div>
  );
}

export function ScreenHeader({
  title,
  subtitle,
  right,
}: {
  title: string;
  subtitle?: string;
  right?: ReactNode;
}) {
  return (
    <header className="flex items-end justify-between px-6 pb-3 pt-8">
      <div>
        <p
          className="text-[10px] font-semibold uppercase"
          style={{
            letterSpacing: "0.3em",
            color: "var(--primary)",
            fontFamily: "JetBrains Mono, monospace",
          }}
        >
          {subtitle ?? "Keryx"}
        </p>
        <h1
          className="font-display italic"
          style={{
            fontSize: 32,
            fontWeight: 500,
            letterSpacing: "-0.03em",
            color: "var(--ink)",
          }}
        >
          {title}
        </h1>
      </div>
      {right}
    </header>
  );
}
