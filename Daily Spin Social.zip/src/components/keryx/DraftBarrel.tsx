import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Archive, X } from "lucide-react";
import type { Draft } from "@/lib/use-drafts";

interface DraftBarrelProps {
  drafts: Draft[];
  ripeness: (d: Draft) => number;
  onDevelop: (d: Draft) => void;
  onDiscard: (id: string) => void;
}

export function DraftBarrel({ drafts, ripeness, onDevelop, onDiscard }: DraftBarrelProps) {
  const [open, setOpen] = useState(false);
  if (drafts.length === 0) return null;
  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="relative grid h-9 w-9 place-items-center rounded-full"
        style={{
          background: "var(--surface-elevated)",
          border: "1px solid var(--color-border)",
          color: "var(--ink)",
        }}
        aria-label="Open draft barrel"
      >
        <Archive className="h-4 w-4" />
        <span
          className="absolute -right-1 -top-1 grid h-4 w-4 place-items-center rounded-full text-[9px] font-bold"
          style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
        >
          {drafts.length}
        </span>
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50"
              style={{ background: "rgb(15 13 11 / 0.55)" }}
              onClick={() => setOpen(false)}
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 30, stiffness: 280 }}
              className="fixed inset-x-0 bottom-0 z-50 mx-auto w-full max-w-[440px]"
            >
              <div
                className="max-h-[80dvh] overflow-y-auto rounded-t-[28px] px-6 pb-8 pt-4"
                style={{ background: "var(--paper)", border: "1px solid var(--color-border)" }}
              >
                <div className="mx-auto mb-4 h-1 w-10 rounded-full" style={{ background: "var(--ink)", opacity: 0.2 }} />
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="font-display italic" style={{ fontSize: 22, color: "var(--ink)" }}>
                    The Draft Barrel
                  </h3>
                  <button onClick={() => setOpen(false)}>
                    <X className="h-4 w-4" style={{ color: "var(--muted-foreground)" }} />
                  </button>
                </div>
                <p className="mb-4 text-xs" style={{ color: "var(--muted-foreground)" }}>
                  Drafts ripen over 24h. Develop one to spin again with boosted odds.
                </p>
                <div className="space-y-2">
                  {drafts.map((d) => {
                    const r = ripeness(d);
                    const ripe = r >= 1;
                    const hoursLeft = Math.max(0, Math.ceil((1 - r) * 24));
                    return (
                      <div
                        key={d.id}
                        className="rounded-md p-3"
                        style={{ background: "var(--surface-elevated)", border: "1px solid var(--color-border)" }}
                      >
                        <p className="font-display italic" style={{ fontSize: 14, color: "var(--ink)" }}>
                          "{d.text}"
                        </p>
                        <div className="mt-2 h-0.5 w-full rounded-full" style={{ background: "var(--surface)" }}>
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${Math.round(r * 100)}%`,
                              background: ripe ? "var(--primary)" : "var(--ochre)",
                              transition: "width 0.4s",
                            }}
                          />
                        </div>
                        <div className="mt-2 flex items-center justify-between">
                          <span
                            className="text-[9px] uppercase"
                            style={{
                              letterSpacing: "0.2em",
                              fontFamily: "JetBrains Mono, monospace",
                              color: "var(--muted-foreground)",
                            }}
                          >
                            {ripe ? "Ready" : `${hoursLeft}h to ripen`}
                          </span>
                          <div className="flex gap-2">
                            <button
                              onClick={() => onDiscard(d.id)}
                              className="text-[10px] uppercase"
                              style={{
                                letterSpacing: "0.2em",
                                color: "var(--muted-foreground)",
                                fontFamily: "JetBrains Mono, monospace",
                              }}
                            >
                              Burn
                            </button>
                            <button
                              disabled={!ripe}
                              onClick={() => {
                                onDevelop(d);
                                setOpen(false);
                              }}
                              className="rounded-full px-3 py-1 text-[10px] uppercase disabled:opacity-40"
                              style={{
                                letterSpacing: "0.2em",
                                fontFamily: "JetBrains Mono, monospace",
                                background: ripe ? "var(--ink)" : "transparent",
                                color: ripe ? "var(--paper)" : "var(--muted-foreground)",
                                border: ripe ? "none" : "1px solid var(--color-border)",
                              }}
                            >
                              Develop
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
