import { useEffect, useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { TOTAL_USERS, SPINNERS_NOW } from "@/lib/keryx-data";
import { useGhostSpins } from "@/lib/use-ghost-spins";
import { GhostSpinLayer } from "./GhostSpin";



const DOT_COUNT = 120;

export function OddsMeter() {
  const [youIndex, setYouIndex] = useState(() => Math.floor(Math.random() * DOT_COUNT));
  const [spinners, setSpinners] = useState(SPINNERS_NOW);
  const [pulseKey, setPulseKey] = useState(0);

  useEffect(() => {
    const t = setInterval(() => {
      setYouIndex((i) => (i + 1 + Math.floor(Math.random() * 7)) % DOT_COUNT);
    }, 1800);
    return () => clearInterval(t);
  }, []);

  // Live spinner ticker: nudges up/down every 2.5-5s with a pulse.
  useEffect(() => {
    let timeout: ReturnType<typeof setTimeout>;
    const schedule = () => {
      timeout = setTimeout(() => {
        setSpinners((s) => {
          const delta = Math.random() < 0.65 ? 1 : -1;
          const next = Math.max(1, Math.min(24, s + delta));
          if (next !== s) setPulseKey((k) => k + 1);
          return next;
        });
        schedule();
      }, 2500 + Math.random() * 2500);
    };
    schedule();
    return () => clearTimeout(timeout);
  }, []);

  const dots = useMemo(() => Array.from({ length: DOT_COUNT }), []);
  const ghosts = useGhostSpins();


  return (
    <div className="mx-auto w-full max-w-[320px]">
      <div className="flex items-baseline justify-between">
        <span
          className="text-[9px] uppercase"
          style={{
            letterSpacing: "0.3em",
            fontFamily: "JetBrains Mono, monospace",
            color: "var(--muted-foreground)",
          }}
        >
          Odds today
        </span>
        <motion.span
          key={pulseKey}
          className="flex items-center gap-1.5 text-[9px] uppercase"
          initial={{ scale: 1.15, color: "var(--primary)" }}
          animate={{ scale: 1, color: "var(--muted-foreground)" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          style={{
            letterSpacing: "0.2em",
            fontFamily: "JetBrains Mono, monospace",
          }}
        >
          <span
            className="keryx-pulse-dot h-1.5 w-1.5 rounded-full"
            style={{ background: "var(--primary)" }}
          />
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.span
              key={spinners}
              initial={{ y: -8, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 8, opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="tabular-nums"
            >
              +{spinners}
            </motion.span>
          </AnimatePresence>
          <span>spinning</span>
        </motion.span>
      </div>

      <div className="mt-2 flex items-baseline gap-2 font-mono leading-none">
        <span className="text-5xl" style={{ color: "var(--primary)", fontWeight: 700, letterSpacing: "-0.04em" }}>
          1
        </span>
        <span className="text-3xl" style={{ color: "var(--muted-foreground)", fontWeight: 300 }}>
          /
        </span>
        <span
          className="text-4xl tabular-nums"
          style={{ color: "var(--ink)", fontWeight: 600, letterSpacing: "-0.02em" }}
        >
          {TOTAL_USERS.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
        </span>
      </div>

      <p className="mt-1 text-[10px]" style={{ color: "var(--muted-foreground)", letterSpacing: "0.05em" }}>
        Spinners across the network today. One of them is you.
      </p>

      <div className="relative mt-4">
        <div className="grid gap-[3px]" style={{ gridTemplateColumns: "repeat(20, minmax(0, 1fr))" }}>
          {dots.map((_, i) => {
            const isYou = i === youIndex;
            return (
              <motion.div
                key={i}
                className="aspect-square rounded-full"
                animate={
                  isYou
                    ? { scale: [1, 1.6, 1.6, 1], opacity: [0.4, 1, 1, 0.4] }
                    : { scale: 1, opacity: 0.25 }
                }
                transition={isYou ? { duration: 1.4, times: [0, 0.2, 0.8, 1] } : { duration: 0.3 }}
                style={{ background: isYou ? "var(--primary)" : "var(--ink)" }}
              />
            );
          })}
        </div>
        <GhostSpinLayer ghosts={ghosts} height={120} />
      </div>

    </div>
  );
}
