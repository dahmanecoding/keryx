import { motion } from "framer-motion";
import { Lock, Check } from "lucide-react";
import type { Perk } from "@/lib/perks";

interface Props {
  perk: Perk;
  unlocked: boolean;
  canAfford: boolean;
  onUnlock: () => void;
}

export function PerkCard({ perk, unlocked, canAfford, onUnlock }: Props) {
  return (
    <motion.button
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={unlocked ? undefined : onUnlock}
      disabled={unlocked || !canAfford}
      className="relative flex flex-col items-start rounded-lg p-3 text-left transition disabled:cursor-not-allowed"
      style={{
        background: unlocked ? "var(--ink)" : "var(--surface-elevated)",
        border: "1px solid var(--color-border)",
        opacity: unlocked || canAfford ? 1 : 0.55,
        boxShadow: unlocked ? "0 6px 18px -10px rgb(15 13 11 / 0.4)" : undefined,
      }}
    >
      <div className="flex w-full items-center justify-between">
        <span
          className="text-[8px] uppercase"
          style={{
            letterSpacing: "0.25em",
            fontFamily: "JetBrains Mono, monospace",
            color: unlocked ? "var(--ochre)" : "var(--muted-foreground)",
          }}
        >
          {perk.category}
        </span>
        {unlocked ? (
          <Check className="h-3 w-3" style={{ color: "var(--ochre)" }} />
        ) : (
          <Lock className="h-3 w-3" style={{ color: "var(--muted-foreground)" }} />
        )}
      </div>
      <span
        className="mt-2 font-display italic"
        style={{
          fontSize: 16,
          fontWeight: 500,
          color: unlocked ? "var(--paper)" : "var(--ink)",
          letterSpacing: "-0.02em",
          lineHeight: 1.15,
        }}
      >
        {perk.name}
      </span>
      <p
        className="mt-1 text-[11px]"
        style={{
          color: unlocked ? "rgb(241 236 224 / 0.7)" : "var(--muted-foreground)",
          lineHeight: 1.3,
        }}
      >
        {perk.description}
      </p>
      <div className="mt-2 flex w-full items-center justify-between">
        <span
          className="text-[9px] uppercase tabular-nums"
          style={{
            letterSpacing: "0.2em",
            fontFamily: "JetBrains Mono, monospace",
            color: unlocked ? "var(--ochre)" : canAfford ? "var(--primary)" : "var(--muted-foreground)",
            fontWeight: 700,
          }}
        >
          {unlocked ? "Owned" : `${perk.cost} drops`}
        </span>
        {perk.requirement && !unlocked && (
          <span
            className="text-[9px]"
            style={{
              fontFamily: "JetBrains Mono, monospace",
              color: "var(--muted-foreground)",
              opacity: 0.8,
            }}
          >
            {perk.requirement}
          </span>
        )}
      </div>
    </motion.button>
  );
}
