import { AnimatePresence, motion } from "framer-motion";
import type { GhostSpin } from "@/lib/use-ghost-spins";

/**
 * Renders friend ghost-spins drifting across a parent container.
 * Parent must be `position: relative` and define its size.
 */
export function GhostSpinLayer({ ghosts, height }: { ghosts: GhostSpin[]; height: number }) {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <AnimatePresence>
        {ghosts.map((g) => (
          <motion.div
            key={g.id}
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: [0, 0.7, 0.7, 0], x: g.drift, y: [0, -6, 4, 0] }}
            exit={{ opacity: 0 }}
            transition={{ duration: g.durationMs / 1000, times: [0, 0.2, 0.8, 1], ease: "easeOut" }}
            style={{
              position: "absolute",
              top: g.startY * height,
              left: -24,
              fontSize: 14,
              filter: "drop-shadow(0 1px 2px rgb(15 13 11 / 0.15))",
            }}
          >
            <div className="flex items-center gap-1">
              <span>{g.avatar}</span>
              <span
                className="text-[8px] uppercase"
                style={{
                  letterSpacing: "0.18em",
                  color: "var(--muted-foreground)",
                  fontFamily: "JetBrains Mono, monospace",
                }}
              >
                {g.name} spun
              </span>
            </div>
            {/* trailing dots */}
            <div className="absolute top-1/2 right-full mr-1 flex -translate-y-1/2 gap-0.5">
              {[0.6, 0.4, 0.25, 0.1].map((o, i) => (
                <span
                  key={i}
                  className="block h-1 w-1 rounded-full"
                  style={{ background: "var(--ink)", opacity: o }}
                />
              ))}
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
