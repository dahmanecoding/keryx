import { AnimatePresence, motion } from "framer-motion";
import { formatCountdown, type RiskStage } from "@/lib/use-reset-countdown";
import { useMotionBudget } from "@/lib/use-motion-budget";

interface Props {
  msLeft: number;
  stage: RiskStage;
  atRisk: boolean;
}

/**
 * Streak-at-risk display. Returns null when not at risk so no animations
 * run on the hot path. Heavy infinite loops are gated by motion budget.
 */
export function StreakRiskTimer({ msLeft, stage, atRisk }: Props) {
  if (!atRisk) return null;

  const big = stage === "alarm" || stage === "panic";

  return (
    <>
      {!big && <RiskBand msLeft={msLeft} stage={stage} />}
      <AnimatePresence>
        {big && <PanicOverlay msLeft={msLeft} panic={stage === "panic"} />}
      </AnimatePresence>
    </>
  );
}

function RiskBand({ msLeft, stage }: { msLeft: number; stage: RiskStage }) {
  return (
    <motion.div
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: -40, opacity: 0 }}
      transition={{ type: "tween", duration: 0.28, ease: [0.22, 0.61, 0.36, 1] }}
      className="sticky top-0 z-30 mx-6 mt-3 rounded-full px-4 py-2"
      style={{
        background: stage === "warn" ? "var(--primary)" : "var(--ochre)",
        color: stage === "warn" ? "var(--primary-foreground)" : "var(--ink)",
        boxShadow: stage === "warn" ? "0 8px 22px -10px rgb(194 65 43 / 0.5)" : undefined,
      }}
    >
      <div className="flex items-center justify-between">
        <span
          className="text-[10px] uppercase"
          style={{
            letterSpacing: "0.3em",
            fontFamily: "JetBrains Mono, monospace",
            fontWeight: 700,
          }}
        >
          Streak resets in
        </span>
        <span
          className="tabular-nums"
          style={{
            fontFamily: "JetBrains Mono, monospace",
            fontWeight: 700,
            fontSize: 14,
            letterSpacing: "0.05em",
          }}
        >
          {formatCountdown(msLeft)}
        </span>
      </div>
    </motion.div>
  );
}

function PanicOverlay({ msLeft, panic }: { msLeft: number; panic: boolean }) {
  const { reduceEffects } = useMotionBudget();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="pointer-events-none fixed inset-0 z-[60] flex flex-col items-center justify-center"
      style={{
        background:
          "radial-gradient(circle at center, rgb(15 13 11 / 0.55) 0%, rgb(15 13 11 / 0.85) 100%)",
      }}
    >
      {/* Static red bleed — pulsing this is too expensive on mobile */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(circle at center, transparent 30%, rgb(194 65 43 / 0.45) 100%)",
          mixBlendMode: "multiply",
          opacity: panic ? 0.8 : 0.5,
        }}
      />

      <motion.div
        animate={
          reduceEffects
            ? undefined
            : panic
              ? { x: [0, -3, 3, -2, 2, 0], y: [0, 2, -2, 1, -1, 0] }
              : { x: [0, -1, 1, 0] }
        }
        transition={{ duration: panic ? 0.18 : 0.9, repeat: Infinity }}
        className="flex flex-col items-center"
        style={{ willChange: "transform" }}
      >
        <span
          className="text-[10px] uppercase"
          style={{
            letterSpacing: "0.4em",
            fontFamily: "JetBrains Mono, monospace",
            color: "var(--paper)",
            opacity: 0.7,
          }}
        >
          Your streak ends in
        </span>
        <div
          className="mt-2 font-display italic tabular-nums"
          style={{
            fontSize: 96,
            fontWeight: 500,
            color: "var(--paper)",
            letterSpacing: "-0.06em",
            lineHeight: 1,
            textShadow: "0 0 30px rgb(194 65 43 / 0.6)",
          }}
        >
          {formatCountdown(msLeft)}
        </div>
        <span
          className="mt-4 text-[10px] uppercase"
          style={{
            letterSpacing: "0.35em",
            fontFamily: "JetBrains Mono, monospace",
            color: "var(--primary)",
            opacity: 0.85,
          }}
        >
          Spin to keep it alive
        </span>
      </motion.div>
    </motion.div>
  );
}
