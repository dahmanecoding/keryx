import { motion } from "framer-motion";
import type { WheelTier } from "@/lib/wheel-tiers";
import { useMotionBudget } from "@/lib/use-motion-budget";

/**
 * Decorative tier-specific ambience rendered behind the wheel.
 * Heavy particle ambiences are skipped under a low motion budget
 * (touch + low-end device, or prefers-reduced-motion).
 */
export function WheelAmbience({ tier, size }: { tier: WheelTier; size: number }) {
  const { reduceEffects } = useMotionBudget();
  if (tier.ambience === "none") return null;

  if (tier.ambience === "grain") {
    return (
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 rounded-full"
        style={{
          backgroundImage: "radial-gradient(rgb(15 13 11 / 0.06) 1px, transparent 1px)",
          backgroundSize: "3px 3px",
          mixBlendMode: "multiply",
          opacity: 0.5,
        }}
      />
    );
  }

  if (tier.ambience === "vignette") {
    return (
      <div
        aria-hidden
        className="pointer-events-none absolute"
        style={{
          inset: -28,
          borderRadius: "9999px",
          background: "radial-gradient(circle, transparent 55%, rgb(118 76 32 / 0.18) 100%)",
        }}
      />
    );
  }

  // Particles tier — skip on reduced motion / low-end.
  if (reduceEffects) {
    return (
      <div
        aria-hidden
        className="pointer-events-none absolute"
        style={{
          inset: -28,
          borderRadius: "9999px",
          background:
            tier.ambience === "embers"
              ? "radial-gradient(circle, transparent 55%, rgb(194 65 43 / 0.18) 100%)"
              : "radial-gradient(circle, transparent 55%, rgb(232 195 107 / 0.18) 100%)",
        }}
      />
    );
  }

  if (tier.ambience === "gold-particles") {
    return (
      <div aria-hidden className="pointer-events-none absolute" style={{ inset: -40 }}>
        {Array.from({ length: 10 }).map((_, i) => {
          const angle = (i / 10) * Math.PI * 2;
          const r = size / 2 + 18 + (i % 3) * 6;
          const cx = size / 2 + Math.cos(angle) * r;
          const cy = size / 2 + Math.sin(angle) * r;
          return (
            <motion.span
              key={i}
              className="absolute rounded-full"
              style={{
                left: cx + 40,
                top: cy + 40,
                width: 3,
                height: 3,
                background: "#E8C36B",
                boxShadow: "0 0 6px #E8C36B",
                willChange: "transform, opacity",
              }}
              animate={{ opacity: [0.2, 0.9, 0.2], scale: [0.6, 1.1, 0.6] }}
              transition={{ duration: 3.6, delay: i * 0.18, repeat: Infinity, ease: "easeInOut" }}
            />
          );
        })}
      </div>
    );
  }

  // embers
  return (
    <div aria-hidden className="pointer-events-none absolute" style={{ inset: -60 }}>
      {Array.from({ length: 8 }).map((_, i) => {
        const angle = (i / 8) * Math.PI * 2;
        return (
          <motion.span
            key={i}
            className="absolute rounded-full"
            style={{
              left: "50%",
              top: "50%",
              width: 4,
              height: 4,
              background: "var(--primary)",
              boxShadow: "0 0 10px var(--primary)",
              originX: 0.5,
              originY: 0.5,
              willChange: "transform, opacity",
            }}
            animate={{
              x: [Math.cos(angle) * (size / 2 + 30), Math.cos(angle) * (size / 2 + 70)],
              y: [Math.sin(angle) * (size / 2 + 30), Math.sin(angle) * (size / 2 + 70)],
              opacity: [0, 0.9, 0],
              scale: [0.6, 1.2, 0.6],
            }}
            transition={{ duration: 2.8, delay: i * 0.25, repeat: Infinity, ease: "easeOut" }}
          />
        );
      })}
    </div>
  );
}
