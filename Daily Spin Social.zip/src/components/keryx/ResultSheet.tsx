import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X, Send } from "lucide-react";
import type { Slice } from "@/lib/keryx-data";
import { setOverlayOpen } from "@/lib/use-overlay";

interface ResultSheetProps {
  slice: Slice | null;
  nearMissPrize?: Slice | null;
  coinFaces?: [0 | 1, 0 | 1] | null;
  onClose: () => void;
  onJollyBonusGranted?: () => void;
  onDraft?: () => void;
  onDoubleOrNothing?: () => void;
  doubleChain?: number;
  /** Seed text when resuming a 24h pending win. */
  initialText?: string;
  /** Called with the in-progress text when the win sheet closes unposted. */
  onPendingSave?: (text: string) => void;
  /** Called once the win has been posted (clears any pending). */
  onPosted?: (body?: string) => void;
}

const COPY: Record<Slice["type"], { eyebrow: string; title: string; sub: string }> = {
  win:   { eyebrow: "The wheel chose you", title: "You may speak.",   sub: "One post. The archive is watching." },
  rare:  { eyebrow: "A rare alignment",    title: "Marked.",          sub: "A badge has entered your record." },
  bonus: { eyebrow: "Granted",             title: "One more turn.",   sub: "Spend it now, or hold it for tomorrow." },
  jolly: { eyebrow: "A jolly twist",       title: "Toss the coins.",  sub: "Match the faces and the next spin tilts in your favour." },
  miss:  { eyebrow: "Today's verdict",     title: "Not today.",       sub: "Streak intact. The wheel resets in 23h 14m." },
};

const ACCENT: Record<Slice["type"], string> = {
  win:   "var(--primary)",
  rare:  "var(--rare)",
  bonus: "var(--ochre)",
  jolly: "var(--jolly)",
  miss:  "var(--ink)",
};

const ease = [0.22, 0.61, 0.36, 1] as const;

export function ResultSheet({ slice, nearMissPrize, coinFaces, onClose, onJollyBonusGranted, onDraft, onDoubleOrNothing, doubleChain = 0, initialText, onPendingSave, onPosted }: ResultSheetProps) {
  const [posted, setPosted] = useState(false);
  const [text, setText] = useState("");
  const isWinSlice = !!slice && (slice.type === "win" || slice.type === "rare" || slice.type === "bonus");

  useEffect(() => {
    if (!slice) {
      setPosted(false);
      setText("");
    } else if (isWinSlice) {
      setText(initialText ?? "");
    }
  }, [slice, initialText, isWinSlice]);

  useEffect(() => {
    setOverlayOpen(!!slice);
    return () => setOverlayOpen(false);
  }, [slice]);

  useEffect(() => {
    if (!slice) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && handleClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slice, onClose, posted, text, isWinSlice]);

  function handleClose() {
    // If user is dismissing an unsent win, stash the draft for 24h.
    if (slice && isWinSlice && !posted && text.trim() && onPendingSave) {
      onPendingSave(text.trim());
    }
    onClose();
  }

  return (
    <AnimatePresence mode="wait">
      {slice && (
        slice.type === "miss" ? (
          <MissView key="miss" slice={slice} nearMissPrize={nearMissPrize ?? null} onClose={onClose} onDraft={onDraft} />
        ) : slice.type === "jolly" ? (
          <JollyView
            key={slice.id}
            coinFaces={coinFaces ?? [0, 0]}
            onClose={onClose}
            onBonus={() => {
              onJollyBonusGranted?.();
              onClose();
            }}
          />
        ) : (
          <PrizeView
            key={slice.id}
            slice={slice}
            posted={posted}
            text={text}
            setText={setText}
            onPost={() => {
              setPosted(true);
              onPosted?.(text);
            }}
            onClose={handleClose}
            onDoubleOrNothing={onDoubleOrNothing}
            doubleChain={doubleChain}
          />
        )
      )}
    </AnimatePresence>
  );
}

/* --------------------------------- JOLLY view --------------------------------- */

function Coin({
  face,
  delay,
}: {
  face: 0 | 1;
  delay: number;
}) {
  // 0 = sun, 1 = moon. We pre-decide the landing face and animate flips into it.
  // Land "heads" after even number of half-turns; "tails" after odd.
  const totalTurns = 8 + (face === 1 ? 0.5 : 0); // ends at 0 or 180
  return (
    <motion.div
      className="relative"
      style={{ width: 72, height: 72, perspective: 600 }}
      initial={{ y: -180, opacity: 0 }}
      animate={{ y: [-180, -20, 6, 0], opacity: 1 }}
      transition={{ duration: 2.4, delay, times: [0, 0.55, 0.88, 1], ease }}
    >
      <motion.div
        className="absolute inset-0"
        style={{ transformStyle: "preserve-3d" }}
        initial={{ rotateX: 0 }}
        animate={{ rotateX: totalTurns * 180 }}
        transition={{ duration: 2.4, delay, ease: [0.2, 0.7, 0.3, 1] }}
      >
        {/* Heads — sun */}
        <div
          className="absolute inset-0 grid place-items-center rounded-full"
          style={{
            background: "radial-gradient(circle at 35% 30%, #f4d77a, var(--ochre))",
            border: "2px solid var(--ink)",
            backfaceVisibility: "hidden",
            boxShadow: "0 8px 18px -8px rgb(15 13 11 / 0.45), inset 0 0 0 2px rgb(255 255 255 / 0.25)",
            fontFamily: "Fraunces, serif",
            fontWeight: 800,
            fontSize: 32,
            color: "var(--ink)",
          }}
        >
          ☀
        </div>
        {/* Tails — moon */}
        <div
          className="absolute inset-0 grid place-items-center rounded-full"
          style={{
            background: "radial-gradient(circle at 35% 30%, #6b7f8e, #2a3340)",
            border: "2px solid var(--ink)",
            backfaceVisibility: "hidden",
            transform: "rotateX(180deg)",
            boxShadow: "0 8px 18px -8px rgb(15 13 11 / 0.45), inset 0 0 0 2px rgb(255 255 255 / 0.1)",
            fontFamily: "Fraunces, serif",
            fontWeight: 800,
            fontSize: 28,
            color: "var(--paper)",
          }}
        >
          ☾
        </div>
      </motion.div>
    </motion.div>
  );
}

function JollyView({
  coinFaces,
  onClose,
  onBonus,
}: {
  coinFaces: [0 | 1, 0 | 1];
  onClose: () => void;
  onBonus: () => void;
}) {
  const accent = ACCENT.jolly;
  const match = coinFaces[0] === coinFaces[1];
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setRevealed(true), 3100);
    return () => clearTimeout(t);
  }, []);

  return (
    <>
      <motion.div
        className="fixed inset-0 z-50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        onClick={onClose}
        style={{
          background: "var(--paper)",
          backgroundImage: `radial-gradient(circle at 50% 35%, ${accent}26 0%, transparent 60%)`,
        }}
      />

      <motion.div
        className="fixed inset-0 z-50 flex flex-col items-center justify-between overflow-y-auto px-6 py-6 sm:py-10"
        initial="hidden"
        animate="visible"
        exit="exit"
      >
        <motion.div
          className="flex w-full items-center justify-between pt-4"
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.4, ease }}
        >
          <span
            className="text-[10px] uppercase"
            style={{
              letterSpacing: "0.32em",
              fontFamily: "JetBrains Mono, monospace",
              color: "var(--muted-foreground)",
            }}
          >
            {COPY.jolly.eyebrow}
          </span>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 transition-colors hover:bg-ink/5"
            aria-label="Close"
            style={{ color: "var(--muted-foreground)" }}
          >
            <X className="h-4 w-4" />
          </button>
        </motion.div>

        <div className="relative flex flex-col items-center text-center">
          <motion.h2
            className="font-display italic"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.5, ease }}
            style={{
              fontSize: "clamp(40px, 11vw, 64px)",
              lineHeight: 0.95,
              letterSpacing: "-0.04em",
              fontWeight: 500,
              color: "var(--ink)",
            }}
          >
            {revealed ? (match ? "A match." : "Close call.") : "Toss the coins."}
          </motion.h2>

          <div className="mt-8 flex items-center gap-8">
            <Coin face={coinFaces[0]} delay={0.25} />
            <Coin face={coinFaces[1]} delay={0.45} />
          </div>

          <motion.div
            className="mt-7 h-px w-24"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.5, duration: 0.5, ease }}
            style={{ background: accent, transformOrigin: "center" }}
          />

          <motion.p
            className="mt-5 max-w-[280px] text-sm leading-relaxed"
            initial={{ opacity: 0 }}
            animate={{ opacity: revealed ? 1 : 0.5 }}
            transition={{ duration: 0.5 }}
            style={{ color: "var(--muted-foreground)" }}
          >
            {revealed
              ? match
                ? "Both faces aligned. A boosted spin is yours. Odds tilt toward the prizes."
                : "The faces split. No bonus this time, but your streak stands."
              : COPY.jolly.sub}
          </motion.p>
        </div>

        <motion.div
          className="w-full max-w-[360px]"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.5, ease }}
        >
          <button
            onClick={revealed && match ? onBonus : onClose}
            disabled={!revealed}
            className="flex w-full items-center justify-center rounded-full py-4 font-display text-base italic transition active:scale-[0.99] disabled:opacity-40"
            style={{
              background: revealed && match ? accent : "var(--ink)",
              color: "var(--paper)",
              letterSpacing: "0.02em",
              fontWeight: 500,
            }}
          >
            {revealed ? (match ? "Take the bonus spin" : "Got it") : "Tossing…"}
          </button>
        </motion.div>
      </motion.div>
    </>
  );
}


/* ---------------------------- PRIZE (win / rare / bonus) ---------------------------- */

function PrizeView({
  slice,
  posted,
  text,
  setText,
  onPost,
  onClose,
  onDoubleOrNothing,
  doubleChain = 0,
}: {
  slice: Slice;
  posted: boolean;
  text: string;
  setText: (s: string) => void;
  onPost: () => void;
  onClose: () => void;
  onDoubleOrNothing?: () => void;
  doubleChain?: number;
}) {
  const copy = COPY[slice.type];
  const accent = ACCENT[slice.type];
  const isWin = slice.type === "win";
  const chars = text.length;
  const ringPct = Math.min(100, (chars / 180) * 100);
  // Double-or-nothing now only applies to "+1 SPIN" bonus slices.
  const canDouble = !!onDoubleOrNothing && !posted && doubleChain < 3 && slice.type === "bonus";
  const [sending, setSending] = useState(false);

  function handlePublish() {
    if (!text.trim() || sending) return;
    setSending(true);
    // Let the flying-letter animation play, then commit.
    setTimeout(() => {
      onPost();
      setSending(false);
    }, 1100);
  }

  return (
    <>
      {/* Backdrop with aurora wash */}
      <motion.div
        className="fixed inset-0 z-50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.4 }}
        onClick={onClose}
        style={{ background: "var(--paper)" }}
      >
        <motion.div
          className="absolute inset-0"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.2 }}
          style={{
            background: `radial-gradient(circle at 50% 30%, ${accent}22 0%, transparent 55%), radial-gradient(circle at 50% 85%, ${accent}11 0%, transparent 60%)`,
          }}
        />
      </motion.div>

      {/* Floating particles */}
      <div className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute bottom-0 h-1.5 w-1.5 rounded-full"
            style={{
              left: `${15 + i * 18}%`,
              background: accent,
              boxShadow: `0 0 12px ${accent}`,
            }}
            initial={{ y: 0, opacity: 0 }}
            animate={{ y: -600, opacity: [0, 1, 1, 0] }}
            transition={{
              duration: 6 + i * 0.5,
              delay: 0.4 + i * 0.3,
              repeat: Infinity,
              ease: "linear",
            }}
          />
        ))}
      </div>

      {/* Content */}
      <motion.div
        className="fixed inset-0 z-50 flex flex-col items-center justify-between overflow-y-auto px-6 py-6 sm:py-10"
        initial="hidden"
        animate="visible"
        exit="exit"
      >
        {/* Top eyebrow */}
        <motion.div
          className="flex w-full items-center justify-between pt-4"
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.5, ease }}
        >
          <span
            className="text-[10px] uppercase"
            style={{
              letterSpacing: "0.32em",
              fontFamily: "JetBrains Mono, monospace",
              color: "var(--muted-foreground)",
            }}
          >
            {copy.eyebrow}
          </span>
          <button
            onClick={onClose}
            className="rounded-full p-1.5 transition-colors hover:bg-ink/5"
            aria-label="Close"
            style={{ color: "var(--muted-foreground)" }}
          >
            <X className="h-4 w-4" />
          </button>
        </motion.div>

        {/* Headline block */}
        <div className="relative flex flex-col items-center text-center">
          <motion.h2
            className="font-display"
            initial={{ opacity: 0, y: 24, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ delay: 0.35, duration: 0.6, ease }}
            style={{
              fontSize: "clamp(48px, 14vw, 88px)",
              lineHeight: 0.92,
              letterSpacing: "-0.045em",
              fontWeight: 500,
              fontStyle: "italic",
              color: "var(--ink)",
              willChange: "transform, opacity",
            }}
          >
            {posted ? "Sent." : copy.title}
          </motion.h2>

          {/* WIN: Letterpress POST stamp slams down over the headline */}
          {slice.type === "win" && !posted && (
            <motion.div
              className="pointer-events-none absolute"
              initial={{ opacity: 0, scale: 2.2, rotate: -18 }}
              animate={{ opacity: [0, 0, 1, 1, 0.85], scale: [2.2, 2.2, 0.92, 1, 0.95], rotate: [-18, -18, -7, -7, -7] }}
              transition={{ duration: 1.2, times: [0, 0.4, 0.55, 0.7, 1], ease: ease }}
              style={{
                top: "30%",
                fontFamily: "Fraunces, Georgia, serif",
                fontSize: "clamp(80px, 22vw, 160px)",
                fontWeight: 900,
                color: "var(--primary)",
                letterSpacing: "0.04em",
                mixBlendMode: "multiply",
                textShadow: "1px 1px 0 rgb(15 13 11 / 0.15)",
                opacity: 0.85,
                willChange: "transform, opacity",
              }}
            >
              POST
            </motion.div>
          )}

          {/* RARE: Wax-seal badge drops */}
          {slice.type === "rare" && (
            <motion.div
              className="pointer-events-none absolute"
              initial={{ opacity: 0, scale: 1.8, y: -40, rotate: -25 }}
              animate={{ opacity: 1, scale: [1.8, 0.88, 1.05, 1], y: 0, rotate: -12 }}
              transition={{ duration: 1.1, times: [0, 0.55, 0.78, 1], ease: ease }}
              style={{ top: "10%", right: "12%" }}
            >
              <svg width="96" height="96" viewBox="0 0 96 96" style={{ filter: "drop-shadow(2px 4px 8px rgb(15 13 11 / 0.4))" }}>
                <defs>
                  <radialGradient id="seal-g" cx="40%" cy="35%">
                    <stop offset="0%" stopColor="#d96a4f" />
                    <stop offset="55%" stopColor="var(--primary)" />
                    <stop offset="100%" stopColor="var(--primary-deep)" />
                  </radialGradient>
                </defs>
                <circle cx="48" cy="48" r="44" fill="url(#seal-g)" />
                <circle cx="48" cy="48" r="44" fill="none" stroke="rgb(15 13 11 / 0.2)" strokeWidth="0.8" />
                <circle cx="48" cy="48" r="36" fill="none" stroke="rgb(255 255 255 / 0.25)" strokeWidth="0.6" strokeDasharray="2 3" />
                <text x="48" y="44" textAnchor="middle" fill="var(--paper)" fontFamily="Fraunces, serif" fontSize="18" fontWeight="700" fontStyle="italic">Rare</text>
                <text x="48" y="60" textAnchor="middle" fill="rgb(241 236 224 / 0.7)" fontFamily="JetBrains Mono, monospace" fontSize="7" letterSpacing="0.2em">№ 13</text>
              </svg>
            </motion.div>
          )}

          {/* Hairline divider */}
          <motion.div
            className="mt-6 h-px w-24"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ delay: 0.6, duration: 0.6, ease }}
            style={{ background: accent, transformOrigin: "center" }}
          />

          <motion.p
            className="mt-5 max-w-[280px] text-sm leading-relaxed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.75, duration: 0.5 }}
            style={{ color: "var(--muted-foreground)" }}
          >
            {posted ? "Your moment is live in the archive." : copy.sub}
          </motion.p>
        </div>

        {/* Flying paper-plane / letter when publishing */}
        {sending && (
          <motion.div
            aria-hidden
            className="pointer-events-none fixed left-1/2 z-[60]"
            initial={{ bottom: 96, x: "-50%", y: 0, rotate: -8, opacity: 0, scale: 0.9 }}
            animate={{ bottom: "auto", top: "-15%", y: 0, rotate: 22, opacity: [0, 1, 1, 0], scale: 1.05 }}
            transition={{ duration: 1.05, ease: [0.5, 0.05, 0.6, 1], times: [0, 0.15, 0.7, 1] }}
          >
            <svg width="64" height="64" viewBox="0 0 64 64" style={{ filter: `drop-shadow(0 6px 14px ${accent}66)` }}>
              <defs>
                <linearGradient id="plane-g" x1="0" x2="1" y1="0" y2="1">
                  <stop offset="0%" stopColor="var(--paper)" />
                  <stop offset="100%" stopColor="#e7dfcf" />
                </linearGradient>
              </defs>
              <path d="M4 32 L60 6 L46 58 L34 38 Z" fill="url(#plane-g)" stroke="var(--ink)" strokeWidth="1.2" strokeLinejoin="round" />
              <path d="M34 38 L60 6" fill="none" stroke="var(--ink)" strokeWidth="1.2" />
            </svg>
            {/* Ink trail */}
            <motion.div
              className="absolute right-full top-1/2 h-[2px] origin-right"
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 120, opacity: [0, 0.7, 0] }}
              transition={{ duration: 1.0, ease: "easeOut" }}
              style={{
                background: `linear-gradient(90deg, transparent, ${accent})`,
                transform: "translateY(-50%)",
              }}
            />
          </motion.div>
        )}

        {/* Bottom action area */}
        <motion.div
          className="w-full max-w-[360px]"
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9, duration: 0.55, ease }}
        >
          {isWin && !posted && (
            <div className="mb-4">
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value.slice(0, 180))}
                placeholder="Say something true…"
                rows={3}
                autoFocus
                className="w-full resize-none rounded-lg p-4 font-display text-base italic leading-snug focus:outline-none"
                style={{
                  background: "transparent",
                  border: "1px solid var(--color-border)",
                  color: "var(--ink)",
                }}
              />
              <div
                className="mt-1.5 flex justify-between text-[10px] uppercase"
                style={{
                  letterSpacing: "0.2em",
                  fontFamily: "JetBrains Mono, monospace",
                  color: "var(--muted-foreground)",
                }}
              >
                <span>Public · Archive</span>
                <span>{chars}/180</span>
              </div>
            </div>
          )}

          <div className="flex items-center gap-3">
            {isWin && !posted ? (
              <button
                onClick={handlePublish}
                disabled={!text.trim() || sending}
                className="relative flex flex-1 items-center justify-center gap-2 overflow-hidden rounded-full py-4 font-display text-sm italic transition active:scale-[0.99] disabled:opacity-40"
                style={{
                  background: "var(--ink)",
                  color: "var(--paper)",
                  letterSpacing: "0.02em",
                  fontWeight: 500,
                  fontSize: 16,
                }}
              >
                <motion.span
                  className="flex items-center gap-2"
                  animate={sending ? { x: 320, opacity: 0 } : { x: 0, opacity: 1 }}
                  transition={{ duration: 0.55, ease: [0.5, 0, 0.75, 0] }}
                >
                  <Send className="h-4 w-4" />
                  {sending ? "Sending…" : "Publish"}
                </motion.span>
                {sending && (
                  <motion.span
                    aria-hidden
                    className="absolute inset-0"
                    initial={{ scaleX: 0, originX: 0 }}
                    animate={{ scaleX: 1 }}
                    transition={{ duration: 1.0, ease: "easeInOut" }}
                    style={{
                      background:
                        `linear-gradient(90deg, transparent, ${accent} 50%, transparent)`,
                      opacity: 0.45,
                    }}
                  />
                )}
                {/* Progress ring */}
                <svg
                  className="pointer-events-none absolute inset-0"
                  viewBox="0 0 100 100"
                  preserveAspectRatio="none"
                >
                  <rect
                    x="0.5"
                    y="0.5"
                    width="99"
                    height="99"
                    rx="50"
                    fill="none"
                    stroke={accent}
                    strokeWidth="1"
                    pathLength="100"
                    strokeDasharray="100"
                    strokeDashoffset={100 - ringPct}
                    style={{ transition: "stroke-dashoffset 0.3s ease" }}
                  />
                </svg>
              </button>
            ) : (
              <button
                onClick={onClose}
                className="flex flex-1 items-center justify-center rounded-full py-4 font-display text-base italic transition active:scale-[0.99]"
                style={{
                  background: "var(--ink)",
                  color: "var(--paper)",
                  letterSpacing: "0.02em",
                  fontWeight: 500,
                }}
              >
                {posted ? "Done" : "Got it"}
              </button>
            )}
            {canDouble && (
              <button
                onClick={onDoubleOrNothing}
                className="rounded-full px-4 py-4 font-display text-sm italic"
                style={{
                  border: `1px solid ${accent}`,
                  color: accent,
                  background: "transparent",
                  letterSpacing: "0.02em",
                }}
              >
                Double or nothing{doubleChain > 0 ? ` ·${doubleChain}` : ""}
              </button>
            )}
          </div>
        </motion.div>
      </motion.div>
    </>
  );
}

/* --------------------------------- MISS view --------------------------------- */

function MissView({
  slice,
  nearMissPrize,
  onClose,
  onDraft,
}: {
  slice: Slice;
  nearMissPrize: Slice | null;
  onClose: () => void;
  onDraft?: () => void;
}) {
  const baseCopy = COPY[slice.type];
  const prizeLabel =
    nearMissPrize?.type === "win"
      ? "POST"
      : nearMissPrize?.type === "rare"
        ? "RARE"
        : nearMissPrize?.type === "bonus"
          ? "+1 SPIN"
          : "";
  const copy = nearMissPrize
    ? {
        eyebrow: "One tick away",
        title: "Almost.",
        sub: `The wheel grazed ${prizeLabel}. Streak intact — try again tomorrow.`,
      }
    : baseCopy;

  return (
    <>
      <motion.div
        className="fixed inset-0 z-50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        onClick={onClose}
        style={{ background: "rgb(15 13 11 / 0.55)" }}
      />

      <motion.div
        className="fixed inset-x-0 bottom-0 z-50 mx-auto w-full max-w-[440px]"
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 280 }}
      >
        <div
          className="relative max-h-[90dvh] overflow-y-auto rounded-t-[28px] px-6 pb-10 pt-4"
          style={{
            background: "var(--paper)",
            border: "1px solid var(--color-border)",
            borderBottom: 0,
            boxShadow: "0 -20px 60px -20px rgb(15 13 11 / 0.3)",
          }}
        >
          <div
            className="mx-auto mb-6 h-1 w-10 rounded-full"
            style={{ background: "var(--ink)", opacity: 0.2 }}
          />

          {/* The wheel-arc that "passed by" */}
          <motion.svg
            width="100%"
            height="64"
            viewBox="0 0 320 64"
            className="mx-auto mb-3 block"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.4 }}
          >
            <motion.path
              d="M 20 50 Q 160 -10 300 50"
              fill="none"
              stroke="var(--primary)"
              strokeWidth="1.2"
              strokeLinecap="round"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: [0, 1, 0.4] }}
              transition={{ delay: 0.2, duration: 1.2, ease }}
            />
            {/* tick marks along the arc */}
            {[40, 80, 120, 160, 200, 240, 280].map((x, i) => (
              <motion.line
                key={x}
                x1={x}
                y1={42 - Math.abs(x - 160) * 0.05}
                x2={x}
                y2={48 - Math.abs(x - 160) * 0.05}
                stroke="var(--ink)"
                strokeWidth="0.8"
                opacity="0.4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.4 }}
                transition={{ delay: 0.35 + i * 0.05, duration: 0.3 }}
              />
            ))}
          </motion.svg>

          <div className="relative">
            <motion.p
              className="text-[10px] uppercase"
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.4 }}
              style={{
                letterSpacing: "0.32em",
                fontFamily: "JetBrains Mono, monospace",
                color: "var(--muted-foreground)",
              }}
            >
              {copy.eyebrow}
            </motion.p>

            <motion.h2
              className="relative mt-2 font-display italic"
              initial={{ opacity: 0, y: 20, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: 0.4, duration: 0.55, ease }}
              style={{
                fontSize: "clamp(36px, 10vw, 60px)",
                lineHeight: 0.95,
                letterSpacing: "-0.04em",
                fontWeight: 500,
                color: "var(--ink)",
                willChange: "transform, opacity",
              }}
            >
              {copy.title}
              {/* Scanline sweep */}
              <motion.span
                className="pointer-events-none absolute inset-0"
                initial={{ x: "-100%" }}
                animate={{ x: "100%" }}
                transition={{ delay: 0.5, duration: 0.9, ease: "easeOut" }}
                style={{
                  background:
                    "linear-gradient(90deg, transparent, rgb(194 65 43 / 0.18), transparent)",
                  mixBlendMode: "multiply",
                }}
              />
            </motion.h2>

            <motion.p
              className="mt-4 text-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.55, duration: 0.5 }}
              style={{ color: "var(--muted-foreground)" }}
            >
              {copy.sub}
            </motion.p>
          </div>

          <motion.div
            className="mt-7 flex items-center gap-3"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7, duration: 0.5, ease }}
          >
            <button
              onClick={onClose}
              className="flex flex-1 items-center justify-center rounded-full py-3.5 font-display text-base italic transition active:scale-[0.99]"
              style={{
                background: "var(--ink)",
                color: "var(--paper)",
                fontWeight: 500,
              }}
            >
              Close
            </button>
            {onDraft && (
              <button
                onClick={onDraft}
                className="text-xs uppercase tracking-[0.2em] underline-offset-4 hover:underline"
                style={{
                  color: "var(--primary)",
                  fontFamily: "JetBrains Mono, monospace",
                }}
              >
                Draft
              </button>
            )}
          </motion.div>
        </div>
      </motion.div>
    </>
  );
}
