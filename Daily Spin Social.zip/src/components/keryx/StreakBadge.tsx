import { Flame } from "lucide-react";

interface StreakBadgeProps {
  streak: number;
}

/**
 * Streak indicator that evolves with streak length.
 * Animation is a compositor-only CSS keyframe (transform + color),
 * so it costs ~0 main-thread time even on mid-range Android.
 */
export function StreakBadge({ streak }: StreakBadgeProps) {
  const tier = streak >= 30 ? 2 : streak >= 7 ? 1 : 0;

  const colors = [
    { bg: "var(--surface-elevated)", fg: "var(--ink)", icon: "var(--ochre)", glow: "transparent" },
    { bg: "var(--surface-elevated)", fg: "var(--primary)", icon: "var(--primary)", glow: "rgb(194 65 43 / 0.25)" },
    { bg: "var(--ink)", fg: "var(--paper)", icon: "var(--primary)", glow: "rgb(194 65 43 / 0.5)" },
  ][tier];

  return (
    <div
      className="relative flex items-center gap-2 rounded-full px-3 py-1.5"
      style={{
        border: "1px solid var(--color-border)",
        background: colors.bg,
        boxShadow: tier >= 1 ? `0 0 16px -4px ${colors.glow}` : undefined,
        transform: tier === 2 ? "scale(1.08)" : tier === 1 ? "scale(1.02)" : "scale(1)",
      }}
    >
      <span
        className={tier >= 1 ? "keryx-flame-flicker" : undefined}
        style={{ color: colors.icon, display: "inline-flex", willChange: tier >= 1 ? "transform" : undefined }}
      >
        <Flame
          className={tier === 2 ? "h-4 w-4" : "h-3.5 w-3.5"}
          fill={tier >= 1 ? "currentColor" : "none"}
          strokeWidth={tier === 0 ? 1.8 : 1.4}
        />
      </span>
      <span
        className="text-[10px] uppercase tabular-nums"
        style={{
          letterSpacing: "0.2em",
          fontFamily: "JetBrains Mono, monospace",
          color: colors.fg,
          fontWeight: tier === 2 ? 700 : 500,
        }}
      >
        {streak} day{streak === 1 ? "" : "s"}
      </span>
    </div>
  );
}
