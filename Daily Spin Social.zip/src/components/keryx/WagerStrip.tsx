import { motion, AnimatePresence } from "framer-motion";
import type { SliceType } from "@/lib/keryx-data";

export type WagerType = Exclude<SliceType, "miss">;

export interface WagerSelection {
  type: WagerType;
}

interface WagerStripProps {
  wager: WagerSelection | null;
  onChange: (w: WagerSelection | null) => void;
  disabled?: boolean;
}

const TYPES: {
  id: WagerType;
  label: string;
  glyph: string;
  color: string;
}[] = [
  { id: "win", label: "Post", glyph: "✎", color: "var(--primary)" },
  { id: "rare", label: "Rare", glyph: "✦", color: "var(--rare)" },
  { id: "bonus", label: "+Spin", glyph: "↻", color: "var(--ochre)" },
  { id: "jolly", label: "Jolly", glyph: "✺", color: "var(--jolly)" },
];

export function WagerStrip({ wager, onChange, disabled }: WagerStripProps) {
  const selectedType = wager ? TYPES.find((t) => t.id === wager.type)! : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="mx-6 mt-4 overflow-hidden rounded-lg"
      style={{
        border: "1px solid var(--color-border)",
        background: "var(--surface-elevated)",
        opacity: disabled ? 0.5 : 1,
        boxShadow:
          "inset 0 1px 0 color-mix(in oklab, var(--paper) 60%, transparent), 0 1px 0 color-mix(in oklab, var(--ink) 5%, transparent)",
      }}
    >
      {/* Header strip — newspaper banner */}
      <div
        className="flex items-center justify-between px-3 py-1.5"
        style={{
          borderBottom: "1px solid var(--color-border)",
          background:
            "repeating-linear-gradient(45deg, transparent 0 3px, color-mix(in oklab, var(--ink) 4%, transparent) 3px 4px)",
        }}
      >
        <span
          className="text-[9px] uppercase"
          style={{
            letterSpacing: "0.35em",
            color: "var(--ink)",
            fontFamily: "JetBrains Mono, monospace",
            fontWeight: 600,
          }}
        >
          ◆ Call Your Shot ◆
        </span>
        <span
          className="text-[9px]"
          style={{
            letterSpacing: "0.2em",
            color: "var(--muted-foreground)",
            fontFamily: "JetBrains Mono, monospace",
          }}
        >
          NAIL IT → +1 SPIN
        </span>
      </div>

      <div className="px-3 py-3">
        {/* Type picker — bold chips */}
        <div className="grid grid-cols-4 gap-1.5">
          {TYPES.map((t) => {
            const active = wager?.type === t.id;
            return (
              <button
                key={t.id}
                disabled={disabled}
                onClick={() =>
                  onChange(active ? null : { type: t.id })
                }
                className="group relative flex flex-col items-center justify-center gap-0.5 rounded-md px-1 py-2 transition-all disabled:opacity-40"
                style={{
                  border: `1px solid ${active ? t.color : "var(--color-border)"}`,
                  background: active
                    ? `color-mix(in oklab, ${t.color} 14%, var(--paper))`
                    : "var(--paper)",
                  boxShadow: active
                    ? `0 0 0 2px color-mix(in oklab, ${t.color} 25%, transparent), inset 0 -2px 0 ${t.color}`
                    : "inset 0 -1px 0 color-mix(in oklab, var(--ink) 8%, transparent)",
                  transform: active ? "translateY(-1px)" : "none",
                }}
              >
                <span
                  className="font-display"
                  style={{ fontSize: 18, color: t.color, lineHeight: 1 }}
                >
                  {t.glyph}
                </span>
                <span
                  className="text-[9px] uppercase"
                  style={{
                    letterSpacing: "0.2em",
                    color: active ? t.color : "var(--ink)",
                    fontFamily: "JetBrains Mono, monospace",
                    fontWeight: 600,
                  }}
                >
                  {t.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Hint / confirmation */}
        <AnimatePresence mode="wait">
          {wager && selectedType ? (
            <motion.div
              key={wager.type}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="mt-3 flex items-center justify-between rounded-md px-2.5 py-2"
              style={{
                background: `color-mix(in oklab, ${selectedType.color} 10%, var(--paper))`,
                border: `1px dashed ${selectedType.color}`,
              }}
            >
              <span
                className="text-[10px] italic"
                style={{
                  color: "var(--ink)",
                  fontFamily: "Crimson Pro, serif",
                }}
              >
                Calling <b style={{ color: selectedType.color }}>{selectedType.label}</b> — land it for a bonus spin.
              </span>
              <button
                onClick={() => onChange(null)}
                className="text-[9px] uppercase"
                style={{
                  letterSpacing: "0.2em",
                  color: "var(--muted-foreground)",
                  fontFamily: "JetBrains Mono, monospace",
                }}
              >
                Clear
              </button>
            </motion.div>
          ) : (
            <motion.p
              key="hint"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="mt-3 text-center text-[10px] italic"
              style={{
                color: "var(--muted-foreground)",
                fontFamily: "Crimson Pro, serif",
              }}
            >
              Tap a slice you think will land — guess right, earn a bonus spin.
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
