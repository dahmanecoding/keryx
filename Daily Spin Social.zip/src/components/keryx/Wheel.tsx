import { useState, useMemo, useRef, useEffect, forwardRef, useImperativeHandle } from "react";
import { motion, useMotionValue, animate, useMotionValueEvent, useTransform } from "framer-motion";
import { SLICES, type Slice, type SliceType } from "@/lib/keryx-data";
import { getWheelTier } from "@/lib/wheel-tiers";
import { WheelAmbience } from "./WheelAmbience";
import { useMotionBudget } from "@/lib/use-motion-budget";

export interface WheelHandle {
  spin: () => Promise<void>;
}

interface WheelProps {
  onResult: (slice: Slice, nearMissPrize?: Slice | null) => void;
  onFocusChange?: (focus: number) => void;
  disabled?: boolean;
  streak?: number;
  perks?: string[];
  pointerColor?: string;
  bonusOdds?: boolean;
  /** Force the spin to land on a miss slice (e.g. Curse of the Blank Page). */
  forceMiss?: boolean;
  /** Strongly bias toward rare/win slices (e.g. ripe drafts developing). */
  rareBias?: boolean;
  /** Multiplier on win-slice probability from weather (1 = neutral). */
  winBias?: number;
  /** Visually emphasize slices of this type (active wager). */
  highlightType?: SliceType | null;
  /** If provided, awaited before each spin and its return value is used as the
   *  authoritative landing slice index. Throw to cancel the spin. */
  getTargetIndex?: () => Promise<number>;
}

const SIZE = 320;
const RADIUS = SIZE / 2;

function r4(n: number) {
  return Math.round(n * 10000) / 10000;
}

function polar(cx: number, cy: number, r: number, angleDeg: number) {
  const a = ((angleDeg - 90) * Math.PI) / 180;
  return { x: r4(cx + r * Math.cos(a)), y: r4(cy + r * Math.sin(a)) };
}

function arcPath(startAngle: number, endAngle: number, outerR: number) {
  const start = polar(RADIUS, RADIUS, outerR, endAngle);
  const end = polar(RADIUS, RADIUS, outerR, startAngle);
  const large = endAngle - startAngle <= 180 ? 0 : 1;
  return `M ${RADIUS} ${RADIUS} L ${start.x} ${start.y} A ${outerR} ${outerR} 0 ${large} 0 ${end.x} ${end.y} Z`;
}

function animateTo(
  mv: ReturnType<typeof useMotionValue<number>>,
  to: number,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  opts: any,
): Promise<void> {
  return new Promise<void>((resolve) => {
    animate(mv, to, { ...opts, onComplete: () => resolve() });
  });
}

const TICK_DECAY_MS = 260;
const PRIZE_COLOR: Record<Slice["type"], string> = {
  win: "var(--primary)",
  rare: "var(--rare)",
  bonus: "var(--ochre)",
  jolly: "var(--jolly)",
  miss: "var(--ink)",
};

export const Wheel = forwardRef<WheelHandle, WheelProps>(function Wheel({
  onResult,
  onFocusChange,
  disabled,
  streak = 0,
  perks = [],
  pointerColor,
  bonusOdds = false,
  forceMiss = false,
  rareBias = false,
  winBias = 1,
  highlightType = null,
  getTargetIndex,
}, ref) {
  const tier = useMemo(() => getWheelTier(streak), [streak]);
  const { reduceEffects } = useMotionBudget();
  const has = (id: string) => perks.includes(id);

  const rotation = useMotionValue(0);
  const sheenRotation = useMotionValue(0);
  const idleBreathe = useMotionValue(0);
  const combinedRotation = useTransform(
    [rotation, idleBreathe] as const,
    ([r, b]: number[]) => r + b,
  );

  const [spinning, setSpinning] = useState(false);
  const [, forceRender] = useState(0);
  const [pointerPulse, setPointerPulse] = useState({ key: 0, strong: false });
  const [pointerTilt, setPointerTilt] = useState(0);
  const [nearMissIndex, setNearMissIndex] = useState<number | null>(null);
  const [windingUp, setWindingUp] = useState(false);

  const sliceAngle = 360 / SLICES.length;
  const outerR = RADIUS - 6;

  const flashRef = useRef<number[]>(new Array(SLICES.length).fill(0));
  const lastSliceUnderPointer = useRef<number>(0);
  const totalDistanceRef = useRef<number>(0);
  const startRotationRef = useRef<number>(0);
  const targetRotationRef = useRef<number>(0);

  const segments = useMemo(
    () =>
      SLICES.map((s, i) => {
        const start = i * sliceAngle;
        const end = start + sliceAngle;
        const mid = start + sliceAngle / 2;
        const labelPos = polar(RADIUS, RADIUS, outerR * 0.72, mid);
        const tickInner = polar(RADIUS, RADIUS, outerR - 8, mid);
        const tickOuter = polar(RADIUS, RADIUS, outerR - 1, mid);
        return { slice: s, start, end, mid, labelPos, tickInner, tickOuter, path: arcPath(start, end, outerR) };
      }),
    [sliceAngle, outerR],
  );

  useEffect(() => {
    if (!spinning) return;
    let raf = 0;
    const tick = () => {
      forceRender((n) => (n + 1) % 1_000_000);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [spinning]);

  useEffect(() => {
    if (spinning || windingUp || reduceEffects) return;
    // Pause when the tab isn't visible — no point rendering off-screen.
    if (typeof document !== "undefined" && document.visibilityState !== "visible") return;
    const controls = animate(idleBreathe, [-0.4, 0.4, -0.4], {
      duration: 6,
      ease: "easeInOut",
      repeat: Infinity,
    });
    const onVis = () => {
      if (document.visibilityState !== "visible") controls.stop();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => {
      controls.stop();
      document.removeEventListener("visibilitychange", onVis);
    };
  }, [spinning, windingUp, idleBreathe, reduceEffects]);

  useMotionValueEvent(rotation, "change", (latest) => {
    const norm = ((360 - (latest % 360)) % 360 + 360) % 360;
    const idx = Math.floor(norm / sliceAngle) % SLICES.length;
    const totalDist = totalDistanceRef.current;

    if (idx !== lastSliceUnderPointer.current) {
      lastSliceUnderPointer.current = idx;
      if (!has("anim-silent")) flashRef.current[idx] = performance.now();
      const remaining = totalDist > 0 ? Math.abs(targetRotationRef.current - latest) : 0;
      const strong = totalDist > 0 && remaining < sliceAngle * 6;
      setPointerPulse((p) => ({ key: p.key + 1, strong }));
    }

    if (totalDist > 0 && onFocusChange) {
      const remaining = Math.abs(targetRotationRef.current - latest);
      const focus = Math.min(1, Math.max(0, 1 - remaining / (sliceAngle * 4)));
      onFocusChange(focus);
    }

    if (totalDist > 0) {
      const remaining = Math.abs(targetRotationRef.current - latest);
      if (remaining < sliceAngle * 6) {
        const pointerNormDeg = norm;
        let bestSignedDelta = 0;
        let bestAbs = Infinity;
        SLICES.forEach((s, i) => {
          if (s.type === "miss") return;
          const sliceMid = i * sliceAngle + sliceAngle / 2;
          let d = sliceMid - pointerNormDeg;
          while (d > 180) d -= 360;
          while (d < -180) d += 360;
          if (Math.abs(d) < bestAbs) {
            bestAbs = Math.abs(d);
            bestSignedDelta = d;
          }
        });
        const strength = 1 - remaining / (sliceAngle * 6);
        const tilt = Math.sign(bestSignedDelta) * Math.min(3, bestAbs * 0.05) * strength;
        setPointerTilt(tilt);
      } else {
        setPointerTilt(0);
      }
    }
  });

  async function spin() {
    if (spinning || windingUp || disabled) return;

    const startRot = rotation.get();
    let targetIndex: number;

    if (getTargetIndex) {
      // Server-authoritative: the parent decides the landing slice.
      try {
        targetIndex = await getTargetIndex();
      } catch {
        return; // server refused (e.g. daily cap, not signed in)
      }
      if (typeof targetIndex !== "number" || targetIndex < 0 || targetIndex >= SLICES.length) {
        return;
      }
    } else {
      const missIdx = SLICES.map((s, i) => (s.type === "miss" ? i : -1)).filter((i) => i !== -1);
      const rareIdx = SLICES.map((s, i) => (s.type === "rare" ? i : -1)).filter((i) => i !== -1);
      const prizeIdx = SLICES
        .map((s, i) => ((s.type === "win" || s.type === "rare" || s.type === "bonus") ? i : -1))
        .filter((i) => i !== -1);
      if (forceMiss) {
        targetIndex = missIdx[Math.floor(Math.random() * missIdx.length)];
      } else if (rareBias) {
        const r = Math.random();
        targetIndex =
          r < 0.55 && rareIdx.length
            ? rareIdx[Math.floor(Math.random() * rareIdx.length)]
            : r < 0.9
              ? prizeIdx[Math.floor(Math.random() * prizeIdx.length)]
              : Math.floor(Math.random() * SLICES.length);
      } else if (bonusOdds) {
        targetIndex =
          Math.random() < 0.8
            ? prizeIdx[Math.floor(Math.random() * prizeIdx.length)]
            : Math.floor(Math.random() * SLICES.length);
      } else {
        targetIndex = Math.floor(Math.random() * SLICES.length);
        if (!bonusOdds && SLICES[targetIndex].type === "win" && Math.random() < 0.8) {
          targetIndex = missIdx[Math.floor(Math.random() * missIdx.length)];
        }
        if (winBias < 1 && SLICES[targetIndex].type === "win" && Math.random() > winBias) {
          targetIndex = missIdx[Math.floor(Math.random() * missIdx.length)];
        } else if (winBias > 1 && SLICES[targetIndex].type === "miss" && Math.random() < winBias - 1) {
          const winIdx = SLICES.map((s, i) => (s.type === "win" ? i : -1)).filter((i) => i !== -1);
          if (winIdx.length) targetIndex = winIdx[Math.floor(Math.random() * winIdx.length)];
        }
      }
    }
    const targetMid = targetIndex * sliceAngle + sliceAngle / 2;
    const revolutions = 6;
    const currentMod = ((startRot % 360) + 360) % 360;
    const desiredMod = (360 - targetMid + 360) % 360;
    const delta = ((desiredMod - currentMod) + 360) % 360;
    const finalRot = startRot + revolutions * 360 + delta;

    setWindingUp(true);
    idleBreathe.set(0);

    // Wind-up — triple if perk active
    const triple = has("anim-triple");
    const shudders = triple ? 9 : 5;
    for (let i = 0; i < shudders; i++) {
      const depth = 6 + Math.random() * 8;
      const back = rotation.get() - depth;
      const ret = back + 3 + Math.random() * 2;
      await animateTo(rotation, back, { duration: 0.07 + Math.random() * 0.04, ease: "easeOut" });
      await animateTo(rotation, ret, { duration: 0.05 + Math.random() * 0.03, ease: "easeInOut" });
    }

    setWindingUp(false);
    setSpinning(true);

    const adjustedStart = rotation.get();
    startRotationRef.current = adjustedStart;
    targetRotationRef.current = finalRot;
    totalDistanceRef.current = finalRot - adjustedStart;

    const mainDuration = has("anim-slowmo") ? 5.4 : 4.2;
    const mainEase = [0.16, 0.84, 0.27, 1] as const;

    animate(sheenRotation, sheenRotation.get() + (finalRot - adjustedStart) * 0.5, {
      duration: mainDuration + 0.5,
      ease: mainEase,
    });

    await animateTo(rotation, finalRot + 6, { duration: mainDuration, ease: mainEase });

    await animateTo(rotation, finalRot, {
      type: "spring",
      damping: 14,
      stiffness: 240,
      mass: 0.7,
    });

    if (onFocusChange) onFocusChange(0);
    setPointerTilt(0);

    const prizeIndices = SLICES.map((s, i) => (s.type !== "miss" ? i : -1)).filter((i) => i !== -1);
    const dist = (a: number, b: number) => Math.min(Math.abs(a - b), SLICES.length - Math.abs(a - b));
    const closest = prizeIndices.map((p) => ({ p, d: dist(p, targetIndex) })).sort((a, b) => a.d - b.d)[0];

    const isNearMiss = SLICES[targetIndex].type === "miss" && closest && closest.d === 1;
    let nearMissSlice: Slice | null = null;

    if (isNearMiss) {
      nearMissSlice = SLICES[closest.p];
      setNearMissIndex(closest.p);
      await new Promise((r) => setTimeout(r, 1400));
      setNearMissIndex(null);
    }

    totalDistanceRef.current = 0;
    setSpinning(false);
    onResult(SLICES[targetIndex], nearMissSlice);
  }

  useImperativeHandle(ref, () => ({ spin }));

  const now = performance.now();
  const buttonActive = spinning || windingUp;

  // Pointer perk sizing
  const pointerScale = has("pointer-mini") ? 0.55 : has("pointer-big") ? 1.45 : 1;
  const isQuill = has("pointer-quill");
  const isDagger = has("pointer-dagger");
  const isCompass = has("pointer-compass");
  const cometTrail = has("anim-comet");
  const effectivePointerColor = pointerColor ?? tier.pointer.color;

  return (
    <div className="relative mx-auto" style={{ width: SIZE, height: SIZE }} data-tier={tier.id}>
      <WheelAmbience tier={tier} size={SIZE} />

      {/* Outer printed frame */}
      <div
        className="absolute inset-0 rounded-full"
        style={{
          background: "var(--paper)",
          border: `${tier.rim.width}px solid ${tier.rim.color}`,
          boxShadow:
            tier.id === "mythic"
              ? "0 0 0 1px var(--primary), 0 30px 60px -30px rgb(194 65 43 / 0.45), inset 0 0 30px rgb(15 13 11 / 0.18)"
              : "0 2px 0 0 rgb(15 13 11 / 0.06), 0 30px 60px -30px rgb(15 13 11 / 0.25), inset 0 0 0 1px rgb(15 13 11 / 0.04)",
        }}
      />

      {/* Inner accent ring (tier ≥ apprentice) */}
      {tier.rim.double && (
        <div
          aria-hidden
          className="absolute rounded-full"
          style={{
            inset: 5,
            border: `1px solid ${tier.rim.accent ?? tier.rim.color}`,
            opacity: 0.7,
          }}
        />
      )}

      {/* Sheen */}
      <motion.div
        className="absolute inset-2 rounded-full"
        style={{
          rotate: sheenRotation,
          background:
            "conic-gradient(from 0deg, transparent 0%, rgb(15 13 11 / 0.04) 25%, transparent 50%, rgb(194 65 43 / 0.05) 75%, transparent 100%)",
          transformOrigin: "50% 50%",
        }}
      />

      {/* Wheel SVG */}
      <motion.svg
        width={SIZE}
        height={SIZE}
        viewBox={`0 0 ${SIZE} ${SIZE}`}
        className="relative"
        style={{ rotate: combinedRotation, transformOrigin: "50% 50%" }}
      >
        {segments.map(({ slice, path }, i) => {
          const isMiss = slice.type === "miss";
          const isNearMissTarget = nearMissIndex === i;
          const isHighlighted = !!highlightType && slice.type === highlightType;
          const baseFill = isMiss ? "var(--paper)" : slice.color;
          return (
            <motion.path
              key={`f-${slice.id}`}
              d={path}
              fill={baseFill}
              stroke={isHighlighted ? slice.color : "rgb(15 13 11 / 0.08)"}
              strokeWidth={isHighlighted ? 1.8 : 0.5}
              animate={
                isNearMissTarget
                  ? {
                      fillOpacity: [0.95, 0.35, 1, 0.4, 1, 0.4, 0.95],
                      scale: [1, 1.015, 1, 1.015, 1, 1.01, 1],
                    }
                  : isHighlighted
                    ? { fillOpacity: [0.9, 1, 0.9], scale: [1, 1.018, 1] }
                    : { fillOpacity: isMiss ? 1 : 0.95, scale: 1 }
              }
              transition={
                isNearMissTarget
                  ? { duration: 1.4, ease: "easeInOut" }
                  : isHighlighted
                    ? { duration: 1.6, repeat: Infinity, ease: "easeInOut" }
                    : { duration: 0.2 }
              }
              style={{
                transformOrigin: `${RADIUS}px ${RADIUS}px`,
                filter: isHighlighted
                  ? `drop-shadow(0 0 8px ${slice.color})`
                  : undefined,
              }}
            />
          );
        })}

        {segments.map(({ slice, tickInner, tickOuter }, i) => {
          const flashedAt = flashRef.current[i];
          const age = flashedAt ? now - flashedAt : Infinity;
          const strength = age < TICK_DECAY_MS ? 1 - age / TICK_DECAY_MS : 0;
          const accent = strength > 0 ? tier.tick.flash : PRIZE_COLOR[slice.type];
          const baseWidth = slice.type === "miss" ? tier.tick.baseWidth : tier.tick.baseWidth + 0.6;
          const isNearMissTarget = nearMissIndex === i;
          const stroke = strength > 0 ? accent : isNearMissTarget ? PRIZE_COLOR[slice.type] : tier.tick.grey;
          const widthFlash = baseWidth + strength * 1.6 + (isNearMissTarget ? 1.2 : 0);
          return (
            <line
              key={`t-${slice.id}`}
              x1={tickInner.x}
              y1={tickInner.y}
              x2={tickOuter.x}
              y2={tickOuter.y}
              stroke={stroke}
              strokeWidth={widthFlash}
              strokeLinecap={tier.tick.serif ? "square" : "round"}
              opacity={Math.max(0.55, 0.55 + strength * 0.45)}
              style={{
                filter:
                  strength > 0
                    ? `drop-shadow(0 0 ${4 + strength * 6}px ${accent})`
                    : isNearMissTarget
                      ? `drop-shadow(0 0 6px ${PRIZE_COLOR[slice.type]})`
                      : "none",
                transition: "filter 80ms linear",
              }}
            />
          );
        })}

        {segments.map(({ slice, labelPos, mid }) => {
          if (slice.type === "miss") return null;
          return (
            <text
              key={`l-${slice.id}`}
              x={labelPos.x}
              y={labelPos.y}
              textAnchor="middle"
              dominantBaseline="middle"
              transform={`rotate(${mid} ${labelPos.x} ${labelPos.y})`}
              style={{ fontFamily: "JetBrains Mono, monospace" }}
              fontSize={9}
              fontWeight={700}
              fill={slice.type === "bonus" ? "var(--ink)" : slice.type === "jolly" ? "var(--paper)" : "var(--primary-foreground)"}
              letterSpacing="0.12em"
            >
              {slice.label}
            </text>
          );
        })}

        <circle cx={RADIUS} cy={RADIUS} r={outerR} fill="none" stroke="var(--ink)" strokeWidth={1} opacity={0.5} />
      </motion.svg>

      {nearMissIndex !== null && <NearMissGlow index={nearMissIndex} sliceAngle={sliceAngle} />}

      {/* Pointer */}
      <motion.div
        className="absolute left-1/2 top-0 z-20 flex flex-col items-center"
        animate={{ rotate: pointerTilt, x: "-50%" }}
        transition={{ type: "spring", damping: 20, stiffness: 300 }}
        style={{ transformOrigin: "50% 100%" }}
      >
        {isQuill ? (
          <motion.div
            key={pointerPulse.key}
            initial={{ scale: pointerPulse.strong ? 1.4 : 1.2 }}
            animate={!buttonActive ? { scale: [1, 1.1, 1] } : { scale: 1 }}
            transition={
              !buttonActive
                ? { duration: tier.pointer.pulseSpeed, repeat: Infinity, ease: "easeInOut" }
                : { duration: 0.2 }
            }
            style={{
              width: 14 * pointerScale,
              height: 22 * pointerScale,
              background: effectivePointerColor,
              clipPath: "polygon(50% 0, 100% 60%, 50% 100%, 0 60%)",
              filter: `drop-shadow(0 0 ${tier.pointer.haloRadius}px ${tier.pointer.haloColor ?? "transparent"})`,
            }}
          />
        ) : isDagger ? (
          <motion.div
            key={pointerPulse.key}
            initial={{ scale: 1 }}
            animate={!buttonActive ? { opacity: [1, 0.85, 1] } : { opacity: 1 }}
            transition={{ duration: tier.pointer.pulseSpeed, repeat: Infinity }}
            style={{
              width: 4 * pointerScale,
              height: 28 * pointerScale,
              background: `linear-gradient(180deg, ${effectivePointerColor}, var(--ink))`,
              clipPath: "polygon(50% 0, 100% 90%, 50% 100%, 0 90%)",
              filter: `drop-shadow(0 0 ${tier.pointer.haloRadius}px ${effectivePointerColor})`,
            }}
          />
        ) : isCompass ? (
          <motion.div
            key={pointerPulse.key}
            animate={!buttonActive ? { rotate: [0, 2, -2, 0] } : {}}
            transition={{ duration: tier.pointer.pulseSpeed, repeat: Infinity }}
            style={{
              width: 6 * pointerScale,
              height: 24 * pointerScale,
              background: `linear-gradient(180deg, ${effectivePointerColor} 50%, var(--paper) 50%)`,
              border: "1px solid var(--ink)",
              borderRadius: 1,
            }}
          />
        ) : (
          <motion.div
            key={pointerPulse.key}
            className="rounded-full"
            initial={{ scale: pointerPulse.strong ? 1.6 * pointerScale : 1.35 * pointerScale }}
            animate={
              !buttonActive
                ? { scale: [pointerScale, 1.25 * pointerScale, pointerScale] }
                : { scale: pointerScale }
            }
            transition={
              !buttonActive
                ? { duration: tier.pointer.pulseSpeed, repeat: Infinity, ease: "easeInOut" }
                : { duration: pointerPulse.strong ? 0.28 : 0.18, ease: "easeOut" }
            }
            style={{
              width: 8,
              height: 8,
              background: effectivePointerColor,
              boxShadow: pointerPulse.strong
                ? `0 0 0 3px var(--paper), 0 0 ${tier.pointer.haloRadius + 8}px ${tier.pointer.haloColor ?? effectivePointerColor}`
                : `0 0 0 3px var(--paper), 0 2px 6px ${tier.pointer.haloColor ?? effectivePointerColor}`,
              filter: cometTrail ? `blur(${spinning ? 1.2 : 0}px)` : undefined,
            }}
          />
        )}
        <div style={{ width: 1, height: 26, background: "var(--ink)", opacity: 0.7, marginTop: 2 }} />
      </motion.div>

      {/* Center button */}
      <button
        onClick={spin}
        disabled={buttonActive || disabled}
        className="group absolute left-1/2 top-1/2 z-10 grid -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full transition-transform active:scale-95 disabled:opacity-90"
        style={{
          width: 112,
          height: 112,
          background: "var(--ink)",
          border: "4px solid var(--paper)",
          boxShadow: "0 0 0 1px var(--ink), 0 12px 28px -12px rgb(15 13 11 / 0.5), inset 0 1px 0 rgb(255 255 255 / 0.06)",
        }}
        aria-label="Spin"
      >
        {windingUp ? (
          <motion.div
            className="absolute inset-2 rounded-full border-2"
            style={{ borderColor: "var(--primary)" }}
            animate={{ scale: [1, 1.15, 1], opacity: [0.4, 1, 0.4] }}
            transition={{ duration: 0.4, repeat: Infinity, ease: "easeInOut" }}
          />
        ) : null}
        <div className="relative flex flex-col items-center gap-0.5">
          <span
            className="font-display text-2xl italic leading-none"
            style={{ color: "var(--paper)", letterSpacing: "-0.04em", fontWeight: 500 }}
          >
            {spinning ? "…" : windingUp ? "·" : "Spin"}
          </span>
          <span
            className="text-[8px] uppercase"
            style={{
              color: "rgb(241 236 224 / 0.45)",
              letterSpacing: "0.3em",
              fontFamily: "JetBrains Mono, monospace",
            }}
          >
            {tier.name}
          </span>
        </div>
      </button>
    </div>
  );
});

function NearMissGlow({ index, sliceAngle }: { index: number; sliceAngle: number }) {
  void index;
  return (
    <motion.div
      className="pointer-events-none absolute"
      initial={{ opacity: 0, scale: 0.6 }}
      animate={{ opacity: [0, 0.9, 0.5, 0.9, 0], scale: [0.6, 1.1, 1, 1.1, 0.9] }}
      transition={{ duration: 1.4, ease: "easeInOut" }}
      style={{
        top: -20,
        left: "50%",
        width: 120,
        height: 120,
        marginLeft: -60,
        borderRadius: "9999px",
        background: "radial-gradient(circle, rgb(194 65 43 / 0.35) 0%, transparent 70%)",
        transformOrigin: `60px ${RADIUS + 20}px`,
        transform: `rotate(${sliceAngle}deg)`,
        zIndex: 25,
      }}
    />
  );
}
