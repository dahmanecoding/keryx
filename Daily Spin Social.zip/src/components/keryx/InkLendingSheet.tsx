import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import type { Debt } from "@/lib/use-debt";

interface InkLendingSheetProps {
  open: boolean;
  onClose: () => void;
  debt: Debt | null;
  streak: number;
  onBorrow: (amount: number) => void;
  onRepay: () => void;
}

const AMOUNTS = [50, 100, 200];

export function InkLendingSheet({ open, onClose, debt, streak, onBorrow, onRepay }: InkLendingSheetProps) {
  const [picked, setPicked] = useState(50);
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50"
            style={{ background: "rgb(15 13 11 / 0.55)" }}
            onClick={onClose}
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 280 }}
            className="fixed inset-x-0 bottom-0 z-50 mx-auto w-full max-w-[440px]"
          >
            <div
              className="rounded-t-[28px] px-6 pb-8 pt-4"
              style={{ background: "var(--paper)", border: "1px solid var(--color-border)" }}
            >
              <div className="mx-auto mb-4 h-1 w-10 rounded-full" style={{ background: "var(--ink)", opacity: 0.2 }} />
              <div className="mb-3 flex items-center justify-between">
                <h3 className="font-display italic" style={{ fontSize: 22 }}>
                  The House lends ink
                </h3>
                <button onClick={onClose}>
                  <X className="h-4 w-4" style={{ color: "var(--muted-foreground)" }} />
                </button>
              </div>

              {debt ? (
                <div className="space-y-3">
                  <p className="text-sm" style={{ color: "var(--ink)" }}>
                    You owe the House{" "}
                    <span style={{ color: "var(--primary)" }} className="font-bold tabular-nums">
                      {debt.amount}◌
                    </span>
                    . Due by your next spin.
                  </p>
                  <p className="text-xs" style={{ color: "var(--muted-foreground)" }}>
                    Miss tomorrow's spin and your {streak}-day streak resets — the debt is wiped, but so is your record.
                  </p>
                  <button
                    onClick={onRepay}
                    className="w-full rounded-full py-3 font-display italic"
                    style={{ background: "var(--ink)", color: "var(--paper)" }}
                  >
                    Repay
                  </button>
                </div>
              ) : (
                <>
                  <p className="mb-3 text-xs" style={{ color: "var(--muted-foreground)" }}>
                    Borrow ink drops now. If you miss your next daily spin, your streak resets.
                  </p>
                  <div className="mb-4 flex gap-2">
                    {AMOUNTS.map((a) => (
                      <button
                        key={a}
                        onClick={() => setPicked(a)}
                        className="flex-1 rounded-md py-2 text-sm tabular-nums"
                        style={{
                          border: `1px solid ${picked === a ? "var(--primary)" : "var(--color-border)"}`,
                          background: picked === a ? "rgb(194 65 43 / 0.1)" : "transparent",
                          color: picked === a ? "var(--primary)" : "var(--ink)",
                          fontFamily: "JetBrains Mono, monospace",
                        }}
                      >
                        {a}◌
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={() => {
                      onBorrow(picked);
                      onClose();
                    }}
                    className="w-full rounded-full py-3 font-display italic"
                    style={{ background: "var(--ink)", color: "var(--paper)" }}
                  >
                    Sign the ledger · {picked}◌
                  </button>
                </>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
