export type PerkCategory = "pointer" | "wheel" | "animation" | "profile" | "ritual";

export interface Perk {
  id: string;
  name: string;
  description: string;
  category: PerkCategory;
  cost: number; // ink drops
  requirement?: string; // human-readable unlock requirement
}

/**
 * Currency: "ink drops" — earned from wins (+3), rares (+10), bonuses (+2),
 * and streak days (+1/day). Stored in localStorage under keryx.inkDrops.
 */
export const PERKS: Perk[] = [
  // Pointer (5)
  { id: "pointer-big",        name: "Bigger Arrow",       category: "pointer",   cost: 30,  description: "Pointer dot scales up by 40%. Hard to miss." },
  { id: "pointer-mini",       name: "Miniature Arrow",    category: "pointer",   cost: 30,  description: "Pointer shrinks for surgical precision." },
  { id: "pointer-quill",      name: "Quill Pointer",      category: "pointer",   cost: 80,  description: "A feathered nib replaces the dot." },
  { id: "pointer-dagger",     name: "Dagger Pointer",     category: "pointer",   cost: 120, description: "A slim blade that glints on landing." },
  { id: "pointer-compass",    name: "Compass Needle",     category: "pointer",   cost: 150, description: "Red/white split needle, wobbles on stop." },

  // Wheel skins (5)
  { id: "wheel-aged",         name: "Parchment Aged",     category: "wheel",     cost: 60,  description: "Yellower paper. Ink bleeds at the edges." },
  { id: "wheel-obsidian",     name: "Obsidian Wheel",     category: "wheel",     cost: 200, description: "Black wheel, gold-leaf labels." , requirement: "30-day streak" },
  { id: "wheel-vellum",       name: "Vellum Wheel",       category: "wheel",     cost: 90,  description: "Translucent paper. Faint grid behind." },
  { id: "wheel-stars",        name: "Constellation Rim",  category: "wheel",     cost: 140, description: "Tick marks become tiny stars." },
  { id: "wheel-crimson",      name: "Crimson Edition",    category: "wheel",     cost: 170, description: "Red wax border. Ochre slices." },

  // Animation (5)
  { id: "anim-slowmo",        name: "Slow-Mo Finale",     category: "animation", cost: 100, description: "Final 3 ticks play at half speed." },
  { id: "anim-confetti",      name: "Confetti Wax",       category: "animation", cost: 70,  description: "Wins drop additional wax flecks." },
  { id: "anim-triple",        name: "Triple Wind-Up",     category: "animation", cost: 80,  description: "Spin charges with three backward shudders." },
  { id: "anim-silent",        name: "Silent Spin",        category: "animation", cost: 50,  description: "Removes tick flashes. Zen mode." },
  { id: "anim-comet",         name: "Comet Trail",        category: "animation", cost: 110, description: "Long motion-blur trail follows the pointer." },

  // Profile / social (5)
  { id: "profile-motto",      name: "Custom Motto",       category: "profile",   cost: 40,  description: "A second line under your name across the app." },
  { id: "profile-animavatar", name: "Animated Avatar",    category: "profile",   cost: 60,  description: "Your emoji gently breathes." },
  { id: "profile-gilded",     name: "Hall-of-Fame Halo",  category: "profile",   cost: 180, description: "Gilded border on your posts in Social." , requirement: "5 wins" },
  { id: "profile-cameo",      name: "Ghost-Spin Cameo",   category: "profile",   cost: 90,  description: "Your avatar shows up more often in friends' dot-fields." },
  { id: "profile-stamp",      name: "Verdict Stamp",      category: "profile",   cost: 100, description: "Pick a personal stamp printed on your tickets." },

  // Ritual / meta (5)
  { id: "ritual-secondchance",name: "Second Chance",      category: "ritual",    cost: 250, description: "Once a week, re-spin a miss." , requirement: "14-day streak" },
  { id: "ritual-shield",      name: "Streak Shield",      category: "ritual",    cost: 300, description: "Protects your streak once if you miss a day." , requirement: "30-day streak" },
  { id: "ritual-bookmark",    name: "Edition Bookmark",   category: "ritual",    cost: 40,  description: "Pin one verdict permanently to the top of Archive." },
  { id: "ritual-whisper",     name: "Whisper Mode",       category: "ritual",    cost: 80,  description: "Your handle appears anonymized in Social for a day." },
  { id: "ritual-eye",         name: "Oracle's Eye",       category: "ritual",    cost: 220, description: "See a 1-second cosmetic preview of your next slice." , requirement: "60-day streak" },
];

export const CATEGORY_LABEL: Record<PerkCategory, string> = {
  pointer: "Pointer",
  wheel: "Wheel Skin",
  animation: "Animation",
  profile: "Profile",
  ritual: "Ritual",
};
