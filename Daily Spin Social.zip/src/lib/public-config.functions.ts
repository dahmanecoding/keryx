import { createServerFn } from "@tanstack/react-start";

// Publishable Supabase config for SSR injection into window.__SUPABASE_CONFIG__.
export const getPublicSupabaseConfig = createServerFn({ method: "GET" }).handler(async () => {
  return {
    url: process.env.EXTERNAL_SUPABASE_URL ?? "",
    anonKey: process.env.EXTERNAL_SUPABASE_ANON_KEY ?? "",
  };
});
