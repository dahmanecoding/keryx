export type WheelTierId = "novice" | "apprentice" | "adept" | "oracle" | "mythic";
export type HandwritingTier = "plain" | "inked" | "embossed" | "illuminated";

export function getHandwritingTier(streak: number): HandwritingTier {
  if (streak >= 100) return "illuminated";
  if (streak >= 30) return "embossed";
  if (streak >= 7) return "inked";
  return "plain";
}

export const HANDWRITING_CLASS: Record<HandwritingTier, string> = {
  plain: "",
  inked: "kx-type-inked",
  embossed: "kx-type-embossed",
  illuminated: "kx-type-illuminated",
};

export interface WheelTier {
  id: WheelTierId;
  name: string;
  minStreak: number;
  rim: {
    width: number;
    color: string;
    double: boolean;
    accent?: string; // optional inner accent ring (gold/red)
  };
  tick: {
    baseWidth: number;
    grey: string;
    flash: string;
    serif: boolean;
  };
  pointer: {
    color: string;
    haloColor: string | null;
    haloRadius: number; // 0 = no halo
    pulseSpeed: number; // seconds
  };
  ambience: "none" | "grain" | "vignette" | "gold-particles" | "embers";
  description: string;
}

export const WHEEL_TIERS: WheelTier[] = [
  {
    id: "novice",
    name: "Novice",
    minStreak: 0,
    rim: { width: 1, color: "var(--ink)", double: false },
    tick: { baseWidth: 0.6, grey: "rgb(15 13 11 / 0.55)", flash: "var(--primary)", serif: false },
    pointer: { color: "var(--primary)", haloColor: null, haloRadius: 0, pulseSpeed: 2.4 },
    ambience: "none",
    description: "The first days. Quiet, plain.",
  },
  {
    id: "apprentice",
    name: "Apprentice",
    minStreak: 7,
    rim: { width: 1.5, color: "var(--ink)", double: true, accent: "var(--ochre)" },
    tick: { baseWidth: 0.75, grey: "rgb(15 13 11 / 0.6)", flash: "var(--ochre)", serif: false },
    pointer: { color: "var(--primary)", haloColor: "var(--ochre)", haloRadius: 5, pulseSpeed: 2.0 },
    ambience: "grain",
    description: "A second ring appears. The paper hums.",
  },
  {
    id: "adept",
    name: "Adept",
    minStreak: 14,
    rim: { width: 2, color: "var(--ochre)", double: true, accent: "var(--ink)" },
    tick: { baseWidth: 1, grey: "rgb(15 13 11 / 0.65)", flash: "var(--ochre)", serif: true },
    pointer: { color: "var(--primary)", haloColor: "var(--ochre)", haloRadius: 7, pulseSpeed: 1.6 },
    ambience: "vignette",
    description: "Gilt rim. Hairline serifs on every tick.",
  },
  {
    id: "oracle",
    name: "Oracle",
    minStreak: 30,
    rim: { width: 3, color: "var(--ochre)", double: true, accent: "var(--primary)" },
    tick: { baseWidth: 1.2, grey: "rgb(15 13 11 / 0.7)", flash: "#E8C36B", serif: true },
    pointer: { color: "#E8C36B", haloColor: "#E8C36B", haloRadius: 10, pulseSpeed: 1.4 },
    ambience: "gold-particles",
    description: "An engraved laurel. The wheel watches back.",
  },
  {
    id: "mythic",
    name: "Mythic",
    minStreak: 60,
    rim: { width: 3.5, color: "var(--ink)", double: true, accent: "var(--primary)" },
    tick: { baseWidth: 1.5, grey: "rgb(15 13 11 / 0.85)", flash: "var(--primary)", serif: true },
    pointer: { color: "var(--primary)", haloColor: "var(--primary)", haloRadius: 14, pulseSpeed: 1.1 },
    ambience: "embers",
    description: "Obsidian. Wax flecks. Embers orbit.",
  },
];

export function getWheelTier(streak: number): WheelTier {
  return [...WHEEL_TIERS].reverse().find((t) => streak >= t.minStreak) ?? WHEEL_TIERS[0];
}

export function getNextTier(streak: number): WheelTier | null {
  return WHEEL_TIERS.find((t) => streak < t.minStreak) ?? null;
}
