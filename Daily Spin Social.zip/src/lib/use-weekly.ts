import { useCallback, useEffect, useState } from "react";

export function isoWeekKey(d = new Date()): string {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const day = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - day);
  const start = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((date.getTime() - start.getTime()) / 86400000 + 1) / 7);
  return `${date.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}

interface WeeklyState {
  votedSliceIndex: number | null;
  votes: Record<number, number>;
}

const DEFAULT: WeeklyState = { votedSliceIndex: null, votes: {} };

function key() {
  return `keryx.weekly.${isoWeekKey()}.v1`;
}

export function useWeekly() {
  const [state, setState] = useState<WeeklyState>(DEFAULT);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(key());
      if (raw) setState({ ...DEFAULT, ...JSON.parse(raw) });
    } catch {
      /* noop */
    }
    setHydrated(true);
  }, []);

  const vote = useCallback((sliceIndex: number) => {
    setState((s) => {
      const next: WeeklyState = {
        votedSliceIndex: sliceIndex,
        votes: { ...s.votes, [sliceIndex]: (s.votes[sliceIndex] ?? 0) + 1 },
      };
      try {
        localStorage.setItem(key(), JSON.stringify(next));
      } catch {
        /* noop */
      }
      return next;
    });
  }, []);

  return { state, vote, hydrated };
}
