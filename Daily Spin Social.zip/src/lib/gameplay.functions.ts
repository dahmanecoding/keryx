import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const SpinInput = z
  .object({
    calledShot: z.enum(["win", "miss", "rare", "bonus", "jolly"]).nullable().optional(),
    forceMiss: z.boolean().optional(),
    rareBias: z.boolean().optional(),
    bonusOdds: z.boolean().optional(),
  })
  .default({});

export const performSpin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => SpinInput.parse(d ?? {}))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: row, error } = await supabase.rpc("perform_spin", {
      p_called_shot: data.calledShot ?? null,
      p_force_miss: data.forceMiss ?? false,
      p_rare_bias: data.rareBias ?? false,
      p_bonus_odds: data.bonusOdds ?? false,
    });
    if (error) throw new Error(error.message);
    return row as {
      spin_id: string;
      outcome: "win" | "miss" | "rare" | "bonus" | "jolly";
      slice_index: number;
      bonus_awarded: boolean;
      pending_win_id: string | null;
      stats: {
        user_id: string;
        spins_today: number;
        spins_total: number;
        streak: number;
        wins_total: number;
        ink_drops: number;
        last_spin_date: string | null;
      };
    };
  });

export const getPlayerStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("player_stats")
      .select("*")
      .eq("user_id", context.userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return data;
  });

export const getPendingWin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("pending_wins")
      .select("id, outcome, expires_at, created_at, spin_id")
      .eq("user_id", context.userId)
      .gt("expires_at", new Date().toISOString())
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return data;
  });

export const publishPendingWin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ pendingId: z.string().uuid(), body: z.string().min(1).max(600) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase.rpc("publish_pending_win", {
      p_pending_id: data.pendingId,
      p_body: data.body,
    });
    if (error) throw new Error(error.message);
    return row as { post_id: string };
  });

export const discardPendingWin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ pendingId: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.rpc("discard_pending_win", {
      p_pending_id: data.pendingId,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
