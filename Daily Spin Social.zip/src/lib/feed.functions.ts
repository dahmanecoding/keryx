import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ReactionKind = z.enum(["hear", "seal", "crown"]);

export const listFeed = createServerFn({ method: "GET" })
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: posts, error } = await supabaseAdmin
      .from("posts")
      .select("id, body, outcome, created_at, user_id")
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) throw new Error(error.message);
    const ids = (posts ?? []).map((p) => p.user_id);
    const userIds = Array.from(new Set(ids));
    const profilesById = new Map<string, { handle: string | null; display_name: string | null; avatar_url: string | null }>();
    if (userIds.length) {
      const { data: profs } = await supabaseAdmin
        .from("profiles")
        .select("id, handle, display_name, avatar_url")
        .in("id", userIds);
      (profs ?? []).forEach((p) => profilesById.set(p.id, p));
    }
    const postIds = (posts ?? []).map((p) => p.id);
    const counts: Record<string, { hear: number; seal: number; crown: number }> = {};
    if (postIds.length) {
      const { data: rx } = await supabaseAdmin
        .from("reactions")
        .select("post_id, kind")
        .in("post_id", postIds);
      (rx ?? []).forEach((r) => {
        const k = counts[r.post_id] ?? { hear: 0, seal: 0, crown: 0 };
        if (r.kind === "hear") k.hear++;
        else if (r.kind === "seal") k.seal++;
        else if (r.kind === "crown") k.crown++;
        counts[r.post_id] = k;
      });
    }
    return (posts ?? []).map((p) => {
      const prof = profilesById.get(p.user_id);
      const c = counts[p.id] ?? { hear: 0, seal: 0, crown: 0 };
      return {
        id: p.id,
        body: p.body,
        outcome: p.outcome,
        created_at: p.created_at,
        handle: prof?.handle ?? "anon",
        display_name: prof?.display_name ?? null,
        avatar_url: prof?.avatar_url ?? null,
        reactions: c,
        total_reactions: c.hear + c.seal + c.crown,
      };
    });
  });

export const myReactions = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ postIds: z.array(z.string().uuid()) }).parse(d))
  .handler(async ({ data, context }) => {
    if (!data.postIds.length) return [];
    const { data: rows, error } = await context.supabase
      .from("reactions")
      .select("post_id, kind")
      .eq("user_id", context.userId)
      .in("post_id", data.postIds);
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const toggleReaction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z.object({ postId: z.string().uuid(), kind: ReactionKind }).parse(d),
  )
  .handler(async ({ data, context }) => {
    const { data: nowOn, error } = await context.supabase.rpc("toggle_reaction", {
      p_post_id: data.postId,
      p_kind: data.kind,
    });
    if (error) throw new Error(error.message);
    return { on: !!nowOn };
  });
