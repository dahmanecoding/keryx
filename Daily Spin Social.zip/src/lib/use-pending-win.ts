import { useCallback, useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPendingWin } from "./gameplay.functions";
import { supabase } from "@/integrations/supabase/client";
import { SLICES, type Slice } from "./keryx-data";

const TEXT_CACHE_KEY = "keryx.pendingWin.text.v2";

export interface PendingWin {
  slice: Slice;
  text: string;
  createdAt: number;
  id?: string;
  expiresAt?: number;
}

function sliceForOutcome(outcome: string): Slice {
  return (
    SLICES.find((s) => s.type === outcome) ?? SLICES[0]
  );
}

function readText(): string {
  if (typeof window === "undefined") return "";
  try { return localStorage.getItem(TEXT_CACHE_KEY) ?? ""; } catch { return ""; }
}
function writeText(t: string | null) {
  try {
    if (t === null) localStorage.removeItem(TEXT_CACHE_KEY);
    else localStorage.setItem(TEXT_CACHE_KEY, t);
  } catch { /* noop */ }
}

export function usePendingWin() {
  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  useEffect(() => {
    let m = true;
    supabase.auth.getUser().then(({ data }) => m && setSignedIn(!!data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => m && setSignedIn(!!s?.user));
    return () => { m = false; sub.subscription.unsubscribe(); };
  }, []);

  const getPendingFn = useServerFn(getPendingWin);
  const query = useQuery({
    queryKey: ["pending_win"],
    queryFn: () => getPendingFn(),
    enabled: signedIn === true,
    staleTime: 15_000,
    refetchInterval: 30_000,
  });

  const [textCache, setTextCache] = useState("");
  useEffect(() => { setTextCache(readText()); }, []);

  const pending: PendingWin | null = query.data
    ? {
        slice: sliceForOutcome(query.data.outcome),
        text: textCache,
        createdAt: new Date(query.data.created_at).getTime(),
        id: query.data.id,
        expiresAt: new Date(query.data.expires_at).getTime(),
      }
    : null;

  const save = useCallback((_slice: Slice, text: string) => {
    writeText(text);
    setTextCache(text);
  }, []);

  const clear = useCallback(() => {
    writeText(null);
    setTextCache("");
  }, []);

  const msLeft = pending?.expiresAt ? Math.max(0, pending.expiresAt - Date.now()) : 0;
  return { pending, save, clear, msLeft };
}

export function formatHoursLeft(ms: number): string {
  const h = Math.floor(ms / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}
