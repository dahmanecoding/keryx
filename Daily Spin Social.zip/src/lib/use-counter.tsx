import { useEffect, useState } from "react";
import { motion, useMotionValue, useTransform, animate } from "framer-motion";

/** Animated number counter — eases from previous to next when `value` changes. */
export function useAnimatedNumber(value: number, duration = 0.9) {
  const mv = useMotionValue(value);
  const [display, setDisplay] = useState(value);

  useEffect(() => {
    const controls = animate(mv, value, { duration, ease: [0.22, 0.61, 0.36, 1] });
    const unsub = mv.on("change", (v) => setDisplay(v));
    return () => {
      controls.stop();
      unsub();
    };
  }, [value, duration, mv]);

  return display;
}

interface CounterProps {
  value: number;
  format?: (n: number) => string;
  className?: string;
  style?: React.CSSProperties;
  duration?: number;
}

export function AnimatedCounter({ value, format, className, style, duration = 0.9 }: CounterProps) {
  const display = useAnimatedNumber(value, duration);
  const text = format ? format(display) : Math.round(display).toString();
  return (
    <motion.span className={className} style={style}>
      {text}
    </motion.span>
  );
}

/** Split-flap style digit flip on value change. */
export function FlipDigits({
  value,
  width = 2,
  className,
  style,
}: {
  value: number;
  width?: number;
  className?: string;
  style?: React.CSSProperties;
}) {
  const str = Math.round(value).toString().padStart(width, "0");
  return (
    <span className={className} style={style}>
      {str.split("").map((d, i) => (
        <FlipDigit key={i} digit={d} index={i} />
      ))}
    </span>
  );
}

function FlipDigit({ digit, index }: { digit: string; index: number }) {
  return (
    <motion.span
      key={digit + "-" + index}
      initial={{ y: -8, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.35, delay: index * 0.04, ease: [0.22, 0.61, 0.36, 1] }}
      style={{ display: "inline-block" }}
    >
      {digit}
    </motion.span>
  );
}

// Re-export to avoid unused warning
export { useTransform };
