import { useEffect, useState } from "react";
import { chanceFromSeed, seededRng } from "./use-daily-seed";

export interface CrierEvent {
  id: string;
  title: string;
  copy: string;
  /** Multiplier on rare ink-drop reward while active. */
  rareMultiplier: number;
  endsAt: number;
}

const EVENTS = [
  { id: "press", title: "The Press is Running", copy: "All wins double in visibility for the next hour.", rareMultiplier: 2 },
  { id: "fog", title: "Foggy Edition", copy: "Rares pay triple — if you can find one.", rareMultiplier: 3 },
  { id: "open", title: "Open Submissions", copy: "Drafts develop twice as fast this hour.", rareMultiplier: 1 },
  { id: "verdict", title: "Reader's Verdict", copy: "The community vote weighs heavier this hour.", rareMultiplier: 1 },
] as const;

/**
 * Returns the active crier event for the current hour, or null.
 * Deterministic: each hour has a ~12% chance of triggering an event.
 */
export function useCrier(): CrierEvent | null {
  const [event, setEvent] = useState<CrierEvent | null>(null);

  useEffect(() => {
    function refresh() {
      const now = new Date();
      const hourSeed = `crier:${now.toISOString().slice(0, 13)}`;
      if (!chanceFromSeed(hourSeed, 0.12)) {
        setEvent(null);
        return;
      }
      const rng = seededRng(hourSeed + ":pick");
      const e = EVENTS[Math.floor(rng() * EVENTS.length)];
      const endOfHour = new Date(now);
      endOfHour.setMinutes(59, 59, 999);
      setEvent({ ...e, endsAt: endOfHour.getTime() });
    }
    refresh();
    const t = setInterval(refresh, 60_000);
    return () => clearInterval(t);
  }, []);

  return event;
}
