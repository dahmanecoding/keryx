import { useEffect, useState, useCallback } from "react";

const KEY = "keryx.reduceEffects.v1";

/**
 * Returns the current motion budget for the app.
 * - "low"  → skip infinite loops, ambient particles, blur filters.
 * - "high" → all effects on.
 *
 * Auto-low when the OS reports prefers-reduced-motion, or when the device
 * looks underpowered (≤4 cores or ≤4GB RAM). User can override via the
 * "Reduce effects" toggle in Profile → Settings.
 */
export function useMotionBudget() {
  const [prefersReduced, setPrefersReduced] = useState(false);
  const [autoLow, setAutoLow] = useState(false);
  const [userOverride, setUserOverride] = useState<boolean | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setPrefersReduced(mq.matches);
    const onMq = (e: MediaQueryListEvent) => setPrefersReduced(e.matches);
    mq.addEventListener?.("change", onMq);

    // Heuristic for low-end devices.
    const nav = navigator as Navigator & { deviceMemory?: number };
    const cores = nav.hardwareConcurrency ?? 8;
    const mem = nav.deviceMemory ?? 8;
    const touch = "ontouchstart" in window || (nav.maxTouchPoints ?? 0) > 0;
    setAutoLow(touch && (cores <= 4 || mem <= 4));

    try {
      const raw = localStorage.getItem(KEY);
      if (raw !== null) setUserOverride(raw === "1");
    } catch {
      /* noop */
    }

    setHydrated(true);
    return () => mq.removeEventListener?.("change", onMq);
  }, []);

  const reduceEffects =
    userOverride !== null ? userOverride : prefersReduced || autoLow;

  const setReduceEffects = useCallback((v: boolean) => {
    setUserOverride(v);
    try {
      localStorage.setItem(KEY, v ? "1" : "0");
    } catch {
      /* noop */
    }
  }, []);

  return {
    budget: (reduceEffects ? "low" : "high") as "low" | "high",
    reduceEffects,
    setReduceEffects,
    prefersReducedMotion: prefersReduced,
    hydrated,
  };
}
