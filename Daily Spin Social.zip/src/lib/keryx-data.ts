export type SliceType = "win" | "miss" | "rare" | "bonus" | "jolly";

export interface Slice {
  id: string;
  label: string;
  type: SliceType;
  color: string;
}

// 24 slices: 1 win, 1 rare, 2 bonus, 2 jolly, 18 miss.
// Win/rare/bonus/jolly scattered so the eye doesn't cluster them.
function makeSlices(): Slice[] {
  const arr: Slice[] = Array.from({ length: 24 }, (_, i) => ({
    id: String(i + 1),
    label: "—",
    type: "miss",
    color: "var(--miss)",
  }));
  arr[0]  = { id: "1",  label: "POST",     type: "win",   color: "var(--win)" };
  arr[4]  = { id: "5",  label: "JOLLY",    type: "jolly", color: "var(--jolly)" };
  arr[7]  = { id: "8",  label: "+1 SPIN",  type: "bonus", color: "var(--ochre)" };
  arr[12] = { id: "13", label: "RARE",     type: "rare",  color: "var(--rare)" };
  arr[15] = { id: "16", label: "JOLLY",    type: "jolly", color: "var(--jolly)" };
  arr[18] = { id: "19", label: "+1 SPIN",  type: "bonus", color: "var(--ochre)" };
  return arr;
}

export const SLICES: Slice[] = makeSlices();

// Mocked community size for the "1 in N" odds display.
export const TOTAL_USERS = 12_847;
export const SPINNERS_NOW = 3;

// User's running counters (mock for the visual prototype)
export const MOCK_USER = {
  streak: 7,
  totalSpins: 48,
  wins: 15,
};

export interface Verdict {
  id: string;
  edition: number;
  date: string; // "Jun 11"
  sliceLabel: string;
  sliceNumber: number;
  result: "WIN" | "MISS" | "RARE" | "BONUS";
  note?: string;
}

export const VERDICTS: Verdict[] = [
  { id: "v1", edition: 7, date: "Jun 11", sliceLabel: "POST", sliceNumber: 1, result: "WIN", note: "Told her." },
  { id: "v2", edition: 6, date: "Jun 10", sliceLabel: "—", sliceNumber: 14, result: "MISS" },
  { id: "v3", edition: 5, date: "Jun 09", sliceLabel: "RARE", sliceNumber: 13, result: "RARE", note: "Oracle badge." },
  { id: "v4", edition: 4, date: "Jun 08", sliceLabel: "—", sliceNumber: 22, result: "MISS" },
  { id: "v5", edition: 3, date: "Jun 07", sliceLabel: "+1 SPIN", sliceNumber: 8, result: "BONUS" },
  { id: "v6", edition: 2, date: "Jun 06", sliceLabel: "—", sliceNumber: 17, result: "MISS" },
  { id: "v7", edition: 1, date: "Jun 05", sliceLabel: "POST", sliceNumber: 1, result: "WIN", note: "First time." },
];


export interface Post {
  id: string;
  author: string;
  handle: string;
  avatar: string;
  text: string;
  mood: "deep" | "funny" | "wild" | "felt";
  reactions: number;
  time: string;
}

export const MOODS = ["all", "deep", "funny", "wild", "felt"] as const;

export const POSTS: Post[] = [
  { id: "p1", author: "Nia", handle: "nia.k", avatar: "🦊", text: "I think I only feel alive on Tuesdays. The rest is rehearsal.", mood: "deep", reactions: 248, time: "2h" },
  { id: "p2", author: "Theo", handle: "theo_", avatar: "🐺", text: "Just told my barista I love her. The wheel made me do it.", mood: "wild", reactions: 1204, time: "5h" },
  { id: "p3", author: "Aya", handle: "ayalight", avatar: "🌙", text: "Saw a man cry at a bus stop today. Sat next to him. Said nothing. It was enough.", mood: "felt", reactions: 892, time: "8h" },
  { id: "p4", author: "Rex", handle: "rexish", avatar: "🐉", text: "My therapist is just my dog with extra steps.", mood: "funny", reactions: 533, time: "1d" },
  { id: "p5", author: "Mira", handle: "mira.x", avatar: "✨", text: "Everyone keeps asking what I want. I want quiet. I want a window. I want time.", mood: "deep", reactions: 412, time: "1d" },
  { id: "p6", author: "Juno", handle: "juno", avatar: "🪐", text: "Spun, lost, posted anyway in my notes app. The wheel doesn't own me.", mood: "wild", reactions: 87, time: "2d" },
];

export interface FriendActivity {
  id: string;
  name: string;
  avatar: string;
  action: string;
  time: string;
  streak?: number;
}

export const FRIEND_ACTIVITY: FriendActivity[] = [
  { id: "a1", name: "Theo", avatar: "🐺", action: "hit a 14-day streak", time: "12m", streak: 14 },
  { id: "a2", name: "Aya", avatar: "🌙", action: "won a rare slice", time: "1h" },
  { id: "a3", name: "Nia", avatar: "🦊", action: "posted a deep one", time: "2h" },
  { id: "a4", name: "Rex", avatar: "🐉", action: "missed today. Sad.", time: "3h" },
  { id: "a5", name: "Mira", avatar: "✨", action: "earned the Oracle badge", time: "5h" },
];

export const HALL_OF_FAME: Post[] = [POSTS[1], POSTS[2], POSTS[4]];

export const BADGE_TIERS = [
  { id: "basic",    label: "Basic",    bg: "linear-gradient(135deg, #d9cfbf, #b8a890)", fg: "#3a2f23", ring: "rgba(58,47,35,0.35)", glow: "transparent" },
  { id: "gold",     label: "Gold",     bg: "linear-gradient(135deg, #f6d77a, #c79a2b)", fg: "#3a2a05", ring: "rgba(199,154,43,0.55)", glow: "rgba(246,215,122,0.55)" },
  { id: "diamond",  label: "Diamond",  bg: "linear-gradient(135deg, #d6f1ff, #6fb3e0)", fg: "#0d2a3b", ring: "rgba(111,179,224,0.6)",  glow: "rgba(214,241,255,0.7)" },
  { id: "platinum", label: "Platinum", bg: "linear-gradient(135deg, #f3f4f5, #9aa3ad)", fg: "#1d242b", ring: "rgba(154,163,173,0.6)",  glow: "rgba(243,244,245,0.7)" },
  { id: "obsidian", name: "Obsidian", label: "Obsidian", bg: "linear-gradient(135deg, #2a2d33, #0a0b0d)", fg: "#f3d77a", ring: "rgba(243,215,122,0.7)", glow: "rgba(194,65,43,0.55)" },
] as const;

export type BadgeTier = (typeof BADGE_TIERS)[number]["id"];

export function getBadgeTier(count: number): BadgeTier | null {
  if (count <= 0) return null;
  if (count >= 16) return "obsidian";
  if (count >= 8)  return "platinum";
  if (count >= 4)  return "diamond";
  if (count >= 2)  return "gold";
  return "basic";
}

export interface Badge {
  id: string;
  name: string;
  icon: string;
  count: number; // 0 = locked
}

export const BADGES: Badge[] = [
  { id: "b1", name: "First Spin",   icon: "🎯", count: 9  }, // platinum
  { id: "b2", name: "Week Strong",  icon: "🔥", count: 3  }, // gold
  { id: "b3", name: "Oracle",       icon: "🔮", count: 5  }, // diamond
  { id: "b4", name: "Rare Hunter",  icon: "💎", count: 1  }, // basic
  { id: "b5", name: "Hall of Fame", icon: "👑", count: 0  },
  { id: "b6", name: "100 Days",     icon: "⚡", count: 0  },
];
