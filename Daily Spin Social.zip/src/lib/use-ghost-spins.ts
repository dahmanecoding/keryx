import { useEffect, useState } from "react";
import { FRIEND_ACTIVITY } from "@/lib/keryx-data";
import { useMotionBudget } from "@/lib/use-motion-budget";

export interface GhostSpin {
  id: string;
  name: string;
  avatar: string;
  startY: number; // 0..1 vertical lane in the dot field
  drift: number; // px horizontal drift
  durationMs: number;
}

let counter = 0;

function makeSpin(): GhostSpin {
  const friend = FRIEND_ACTIVITY[Math.floor(Math.random() * FRIEND_ACTIVITY.length)];
  return {
    id: `g${++counter}-${friend.id}`,
    name: friend.name,
    avatar: friend.avatar,
    startY: 0.15 + Math.random() * 0.7,
    drift: 80 + Math.random() * 80,
    durationMs: 2200 + Math.random() * 900,
  };
}

/**
 * Simulated friend ghost-spin feed. Emits a ghost every 7–18 seconds.
 * Drops ghosts older than 4s to keep the list bounded.
 */
export function useGhostSpins(): GhostSpin[] {
  const [ghosts, setGhosts] = useState<GhostSpin[]>([]);
  const { reduceEffects } = useMotionBudget();

  useEffect(() => {
    if (reduceEffects) setGhosts([]);
  }, [reduceEffects]);

  useEffect(() => {
    if (reduceEffects) return;
    let cancelled = false;
    let timeout: ReturnType<typeof setTimeout>;

    const schedule = () => {
      const delay = 7000 + Math.random() * 11000;
      timeout = setTimeout(() => {
        if (cancelled) return;
        const g = makeSpin();
        setGhosts((arr) => [...arr.slice(-2), g]);
        setTimeout(() => {
          if (!cancelled) setGhosts((arr) => arr.filter((x) => x.id !== g.id));
        }, g.durationMs + 200);
        schedule();
      }, delay);
    };

    // First ghost arrives a little faster so the user sees the feature.
    timeout = setTimeout(() => {
      if (cancelled) return;
      const g = makeSpin();
      setGhosts([g]);
      setTimeout(() => {
        if (!cancelled) setGhosts((arr) => arr.filter((x) => x.id !== g.id));
      }, g.durationMs + 200);
      schedule();
    }, 2500);

    return () => {
      cancelled = true;
      clearTimeout(timeout);
    };
  }, [reduceEffects]);

  return ghosts;
}
