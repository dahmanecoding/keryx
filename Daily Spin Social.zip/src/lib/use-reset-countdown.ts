import { useEffect, useState } from "react";

export type RiskStage = "safe" | "watch" | "warn" | "alarm" | "panic";

export interface ResetCountdown {
  msLeft: number;
  stage: RiskStage;
  atRisk: boolean; // true once we're within the warning window AND haven't spun
  hasSpunToday: boolean;
}

function msToNextLocalMidnight(now = new Date()): number {
  const next = new Date(now);
  next.setHours(24, 0, 0, 0);
  return next.getTime() - now.getTime();
}

function stageFor(ms: number): RiskStage {
  const min = ms / 60_000;
  if (min > 60) return "safe";
  if (min > 15) return "watch";
  if (min > 5) return "warn";
  if (min > 1) return "alarm";
  return "panic";
}

/**
 * Adaptive tick rate: cheap (60s) when the user is safely outside the
 * risk window; only ticks every second in the final stretch where the
 * UI actually needs second-resolution updates.
 */
function tickRateFor(stage: RiskStage): number {
  switch (stage) {
    case "panic":
    case "alarm":
      return 1_000;
    case "warn":
      return 5_000;
    case "watch":
      return 15_000;
    default:
      return 60_000;
  }
}

export function useResetCountdown(hasSpunToday: boolean): ResetCountdown {
  const [msLeft, setMsLeft] = useState(() => msToNextLocalMidnight());

  useEffect(() => {
    let id: ReturnType<typeof setTimeout>;
    const schedule = () => {
      const now = msToNextLocalMidnight();
      setMsLeft(now);
      id = setTimeout(schedule, tickRateFor(stageFor(now)));
    };
    schedule();
    return () => clearTimeout(id);
  }, []);

  const stage = stageFor(msLeft);
  const atRisk = !hasSpunToday && stage !== "safe";

  return { msLeft, stage, atRisk, hasSpunToday };
}

export function formatCountdown(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
