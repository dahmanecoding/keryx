export interface Seal {
  id: string;
  name: string;
  glyph: string; // unicode used inside the wax stamp
  requirement: { kind: "streak" | "wins" | "rare" | "drafts" | "always"; value: number };
}

export const SEALS: Seal[] = [
  { id: "starter", name: "First Mark", glyph: "✦", requirement: { kind: "always", value: 0 } },
  { id: "fox", name: "Fox", glyph: "ᚠ", requirement: { kind: "streak", value: 3 } },
  { id: "moon", name: "Crescent", glyph: "☾", requirement: { kind: "streak", value: 7 } },
  { id: "key", name: "Key", glyph: "⚷", requirement: { kind: "wins", value: 10 } },
  { id: "eye", name: "All-Seeing", glyph: "◉", requirement: { kind: "rare", value: 1 } },
  { id: "crown", name: "Crown", glyph: "♛", requirement: { kind: "streak", value: 30 } },
  { id: "ouroboros", name: "Ouroboros", glyph: "∞", requirement: { kind: "streak", value: 60 } },
  { id: "quill", name: "Quill", glyph: "✒", requirement: { kind: "drafts", value: 3 } },
  { id: "ember", name: "Ember", glyph: "✸", requirement: { kind: "wins", value: 25 } },
  { id: "compass", name: "Compass", glyph: "✥", requirement: { kind: "streak", value: 14 } },
  { id: "anchor", name: "Anchor", glyph: "⚓", requirement: { kind: "streak", value: 21 } },
  { id: "rose", name: "Rose", glyph: "❀", requirement: { kind: "wins", value: 50 } },
];

export interface SealProgress {
  streak: number;
  wins: number;
  rares: number;
  drafts: number;
}

export function isSealEarned(seal: Seal, p: SealProgress): boolean {
  switch (seal.requirement.kind) {
    case "always":
      return true;
    case "streak":
      return p.streak >= seal.requirement.value;
    case "wins":
      return p.wins >= seal.requirement.value;
    case "rare":
      return p.rares >= seal.requirement.value;
    case "drafts":
      return p.drafts >= seal.requirement.value;
  }
}
