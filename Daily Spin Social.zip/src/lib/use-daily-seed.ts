/**
 * Deterministic per-day RNG.
 * Hash the local YYYY-MM-DD string into a uint32, then expose a seeded
 * pseudo-random sequence so every user sees the same daily conditions.
 */

export function todayKey(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function xmur3(str: string) {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return () => {
    h = Math.imul(h ^ (h >>> 16), 2246822507);
    h = Math.imul(h ^ (h >>> 13), 3266489909);
    h ^= h >>> 16;
    return h >>> 0;
  };
}

function mulberry32(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function seededRng(seed: string) {
  const s = xmur3(seed)();
  return mulberry32(s);
}

export function pickFromSeed<T>(seed: string, items: readonly T[]): T {
  const rng = seededRng(seed);
  return items[Math.floor(rng() * items.length)];
}

export function chanceFromSeed(seed: string, p: number): boolean {
  return seededRng(seed)() < p;
}
