import { useCallback, useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getMyProfile, updateMyProfile } from "./profile.functions";
import { getPlayerStats } from "./gameplay.functions";
import { supabase } from "@/integrations/supabase/client";

const PERKS_KEY = "keryx.perks.v1";
const LOCAL_PREFS_KEY = "keryx.profile.prefs.v1";
const LAST_SPIN_KEY = "keryx.lastSpinDate.v1";

export interface ProfileState {
  avatar: string;
  motto: string;
  pointerColor: string;
  wheelGrain: "linen" | "parchment" | "vellum" | "obsidian";
  inkColor: string;
}

const DEFAULT_PROFILE: ProfileState = {
  avatar: "🦊",
  motto: "The wheel decides.",
  pointerColor: "var(--primary)",
  wheelGrain: "linen",
  inkColor: "var(--ink)",
};

function useSignedIn() {
  const [v, setV] = useState<boolean | null>(null);
  useEffect(() => {
    let m = true;
    supabase.auth.getUser().then(({ data }) => m && setV(!!data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => m && setV(!!s?.user));
    return () => { m = false; sub.subscription.unsubscribe(); };
  }, []);
  return v;
}

export function useProfile() {
  const qc = useQueryClient();
  const signedIn = useSignedIn();
  const getProfileFn = useServerFn(getMyProfile);
  const updateProfileFn = useServerFn(updateMyProfile);
  const getStatsFn = useServerFn(getPlayerStats);

  const profileQuery = useQuery({
    queryKey: ["my_profile"],
    queryFn: () => getProfileFn(),
    enabled: signedIn === true,
    staleTime: 60_000,
  });
  const statsQuery = useQuery({
    queryKey: ["player_stats"],
    queryFn: () => getStatsFn(),
    enabled: signedIn === true,
    staleTime: 10_000,
  });

  // Local-only visual preferences (pointer/wheel/ink color, perks).
  const [localPrefs, setLocalPrefs] = useState<Pick<ProfileState, "pointerColor" | "wheelGrain" | "inkColor">>({
    pointerColor: DEFAULT_PROFILE.pointerColor,
    wheelGrain: DEFAULT_PROFILE.wheelGrain,
    inkColor: DEFAULT_PROFILE.inkColor,
  });
  const [perks, setPerks] = useState<string[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const rawPrefs = localStorage.getItem(LOCAL_PREFS_KEY);
      if (rawPrefs) setLocalPrefs((p) => ({ ...p, ...JSON.parse(rawPrefs) }));
      const rawPerks = localStorage.getItem(PERKS_KEY);
      if (rawPerks) setPerks(JSON.parse(rawPerks));
    } catch { /* noop */ }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(LOCAL_PREFS_KEY, JSON.stringify(localPrefs));
      localStorage.setItem(PERKS_KEY, JSON.stringify(perks));
    } catch { /* noop */ }
  }, [localPrefs, perks, hydrated]);

  const profile: ProfileState = {
    avatar: profileQuery.data?.avatar_url || DEFAULT_PROFILE.avatar,
    motto: profileQuery.data?.motto || DEFAULT_PROFILE.motto,
    ...localPrefs,
  };
  const inkDrops = statsQuery.data?.ink_drops ?? 0;

  const update = useCallback((patch: Partial<ProfileState>) => {
    // Persist DB-backed fields server-side; local prefs to localStorage.
    const dbPatch: Record<string, string> = {};
    if (patch.avatar !== undefined) dbPatch.avatar_url = patch.avatar;
    if (patch.motto !== undefined) dbPatch.motto = patch.motto;
    if (Object.keys(dbPatch).length && signedIn) {
      updateProfileFn({ data: dbPatch }).then(() => {
        qc.invalidateQueries({ queryKey: ["my_profile"] });
      }).catch((e) => console.error("profile update failed", e));
    }
    const localPatch: Partial<typeof localPrefs> = {};
    if (patch.pointerColor !== undefined) localPatch.pointerColor = patch.pointerColor;
    if (patch.wheelGrain !== undefined) localPatch.wheelGrain = patch.wheelGrain;
    if (patch.inkColor !== undefined) localPatch.inkColor = patch.inkColor;
    if (Object.keys(localPatch).length) setLocalPrefs((p) => ({ ...p, ...localPatch }));
  }, [signedIn, updateProfileFn, qc]);

  const setInkDrops = useCallback((_n: number) => {
    // Ink drops are now server-authoritative (mutated by perform_spin).
    // This setter is a no-op kept for backwards compatibility.
    qc.invalidateQueries({ queryKey: ["player_stats"] });
  }, [qc]);

  const unlockPerk = useCallback((perkId: string, cost: number) => {
    if (perks.includes(perkId)) return false;
    if (inkDrops < cost) return false;
    setPerks((p) => [...p, perkId]);
    // TODO: server-side perk unlock + ink debit RPC. Local for now.
    return true;
  }, [perks, inkDrops]);

  const hasPerk = useCallback((perkId: string) => perks.includes(perkId), [perks]);

  return {
    profile,
    update,
    perks,
    hasPerk,
    unlockPerk,
    inkDrops,
    setInkDrops,
    hydrated: hydrated && (signedIn === false || profileQuery.isFetched),
  };
}

/** Derives "spun today" from server player_stats.last_spin_date; falls back to
 *  localStorage when signed out so the streak-risk timer still functions. */
export function useLastSpin() {
  const signedIn = useSignedIn();
  const getStatsFn = useServerFn(getPlayerStats);
  const statsQuery = useQuery({
    queryKey: ["player_stats"],
    queryFn: () => getStatsFn(),
    enabled: signedIn === true,
    staleTime: 10_000,
  });

  const [localISO, setLocalISO] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => {
    setLocalISO(typeof window !== "undefined" ? localStorage.getItem(LAST_SPIN_KEY) : null);
    setHydrated(true);
  }, []);

  const markSpunNow = useCallback(() => {
    const iso = new Date().toISOString();
    setLocalISO(iso);
    try { localStorage.setItem(LAST_SPIN_KEY, iso); } catch { /* noop */ }
  }, []);

  const today = new Date();
  const todayKey = `${today.getFullYear()}-${today.getMonth() + 1}-${today.getDate()}`;
  let hasSpunToday = false;
  if (signedIn && statsQuery.data?.last_spin_date) {
    const d = new Date(statsQuery.data.last_spin_date);
    hasSpunToday = `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}` === todayKey;
  } else if (localISO) {
    const last = new Date(localISO);
    hasSpunToday =
      last.getFullYear() === today.getFullYear() &&
      last.getMonth() === today.getMonth() &&
      last.getDate() === today.getDate();
  }

  return { hasSpunToday, markSpunNow, hydrated };
}
