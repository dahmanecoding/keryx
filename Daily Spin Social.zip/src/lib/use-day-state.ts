import { useCallback, useEffect, useState } from "react";
import { todayKey } from "./use-daily-seed";

export interface DayState {
  curseUsed: boolean;
  freeSpinClaimed: boolean;
  spinsToday: number;
  doubleOrNothingChain: number;
}

const DEFAULT: DayState = {
  curseUsed: false,
  freeSpinClaimed: false,
  spinsToday: 0,
  doubleOrNothingChain: 0,
};

function key(d = new Date()) {
  return `keryx.day.${todayKey(d)}.v1`;
}

export function useDayState() {
  const [state, setState] = useState<DayState>(DEFAULT);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(key());
      if (raw) setState({ ...DEFAULT, ...JSON.parse(raw) });
    } catch {
      /* noop */
    }
    setHydrated(true);
  }, []);

  const update = useCallback((patch: Partial<DayState>) => {
    setState((s) => {
      const next = { ...s, ...patch };
      try {
        localStorage.setItem(key(), JSON.stringify(next));
      } catch {
        /* noop */
      }
      return next;
    });
  }, []);

  return { state, update, hydrated };
}
