import { useCallback, useEffect, useState } from "react";

export interface Debt {
  amount: number;
  borrowedAt: number;
  dueDay: string; // YYYY-MM-DD
}

const KEY = "keryx.debt.v1";

function read(): Debt | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Debt) : null;
  } catch {
    return null;
  }
}

function write(d: Debt | null) {
  try {
    if (d) localStorage.setItem(KEY, JSON.stringify(d));
    else localStorage.removeItem(KEY);
  } catch {
    /* noop */
  }
}

export function useDebt() {
  const [debt, setDebt] = useState<Debt | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setDebt(read());
    setHydrated(true);
  }, []);

  const borrow = useCallback((amount: number) => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const dueDay = tomorrow.toISOString().slice(0, 10);
    const d: Debt = { amount, borrowedAt: Date.now(), dueDay };
    write(d);
    setDebt(d);
  }, []);

  const clear = useCallback(() => {
    write(null);
    setDebt(null);
  }, []);

  return { debt, borrow, clear, hydrated };
}
