import { useCallback } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listDrafts, addDraft, removeDraft } from "./drafts.functions";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";

export interface Draft {
  id: string;
  text: string;
  createdAt: number;
}

const TTL_MS = 24 * 60 * 60 * 1000;

export function useDrafts() {
  const qc = useQueryClient();
  const listFn = useServerFn(listDrafts);
  const addFn = useServerFn(addDraft);
  const removeFn = useServerFn(removeDraft);

  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  useEffect(() => {
    let m = true;
    supabase.auth.getUser().then(({ data }) => m && setSignedIn(!!data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => m && setSignedIn(!!s?.user));
    return () => { m = false; sub.subscription.unsubscribe(); };
  }, []);

  const query = useQuery({
    queryKey: ["drafts"],
    queryFn: () => listFn(),
    enabled: signedIn === true,
    staleTime: 30_000,
  });

  const drafts: Draft[] = (query.data ?? [])
    .map((r) => ({ id: r.id, text: r.body, createdAt: new Date(r.updated_at).getTime() }))
    .filter((d) => Date.now() - d.createdAt < TTL_MS);

  const addMut = useMutation({
    mutationFn: (body: string) => addFn({ data: { body } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["drafts"] }),
  });
  const removeMut = useMutation({
    mutationFn: (id: string) => removeFn({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["drafts"] }),
  });

  const add = useCallback((text: string) => { addMut.mutate(text); }, [addMut]);
  const remove = useCallback((id: string) => { removeMut.mutate(id); }, [removeMut]);

  function ripeness(d: Draft) {
    return Math.min(1, (Date.now() - d.createdAt) / TTL_MS);
  }

  return { drafts, add, remove, ripeness, hydrated: query.isFetched };
}
