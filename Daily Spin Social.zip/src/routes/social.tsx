import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Flame, Trophy, Sparkles, Crown, Sticker, Heart } from "lucide-react";
import { useEffect, useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { AppShell, ScreenHeader } from "@/components/keryx/AppShell";
import { listFeed, myReactions, toggleReaction } from "@/lib/feed.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/social")({
  head: () => ({
    meta: [
      { title: "Social — Keryx" },
      { name: "description", content: "Live verdicts from everyone who spun and posted." },
    ],
  }),
  component: SocialScreen,
});

type FeedRow = Awaited<ReturnType<typeof listFeed>>[number];

function timeAgo(iso: string) {
  const s = Math.max(1, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

function SocialScreen() {
  const qc = useQueryClient();
  const listFn = useServerFn(listFeed);
  const myRxFn = useServerFn(myReactions);
  const toggleFn = useServerFn(toggleReaction);

  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  useEffect(() => {
    let m = true;
    supabase.auth.getUser().then(({ data }) => m && setSignedIn(!!data.user));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => m && setSignedIn(!!s?.user));
    return () => { m = false; sub.subscription.unsubscribe(); };
  }, []);

  const feedQuery = useQuery({
    queryKey: ["feed"],
    queryFn: () => listFn(),
    staleTime: 15_000,
  });

  const postIds = useMemo(() => (feedQuery.data ?? []).map((p) => p.id), [feedQuery.data]);
  const myRxQuery = useQuery({
    queryKey: ["my_reactions", postIds],
    queryFn: () => myRxFn({ data: { postIds } }),
    enabled: signedIn === true && postIds.length > 0,
    staleTime: 30_000,
  });

  // Realtime: refetch feed on new posts/reactions.
  useEffect(() => {
    const ch = supabase
      .channel("feed-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "posts" }, () => {
        qc.invalidateQueries({ queryKey: ["feed"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "reactions" }, () => {
        qc.invalidateQueries({ queryKey: ["feed"] });
      })
      .subscribe();
    return () => { void supabase.removeChannel(ch); };
  }, [qc]);

  const myReactionSet = useMemo(() => {
    const m = new Map<string, Set<string>>();
    (myRxQuery.data ?? []).forEach((r) => {
      const s = m.get(r.post_id) ?? new Set();
      s.add(r.kind);
      m.set(r.post_id, s);
    });
    return m;
  }, [myRxQuery.data]);

  const reactMut = useMutation({
    mutationFn: (vars: { postId: string; kind: "hear" | "seal" | "crown" }) =>
      toggleFn({ data: vars }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["feed"] });
      qc.invalidateQueries({ queryKey: ["my_reactions"] });
    },
  });

  const top = (feedQuery.data ?? []).slice(0, 5);
  const rest = (feedQuery.data ?? []).slice(5);

  return (
    <AppShell>
      <ScreenHeader title="Social" subtitle="Verdicts from the wheel." />

      <section className="px-5">
        <SectionHeader icon={<Trophy className="h-3.5 w-3.5" />} title="Hall of moments" />
        {feedQuery.isLoading ? (
          <p className="mt-3 text-xs text-muted-foreground">Loading…</p>
        ) : top.length === 0 ? (
          <p className="mt-3 text-xs text-muted-foreground">No posts yet. Spin a win and be the first.</p>
        ) : (
          <div className="-mx-5 mt-3 flex gap-3 overflow-x-auto px-5 pb-2">
            {top.map((p, i) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, y: 16, rotate: -1.5 }}
                animate={{ opacity: 1, y: 0, rotate: 0 }}
                transition={{ delay: 0.15 + i * 0.07, duration: 0.45, ease: [0.22, 0.61, 0.36, 1] }}
                whileHover={{ y: -4, rotate: 0.5 }}
                className="glass relative w-[280px] shrink-0 overflow-hidden rounded-2xl p-4"
              >
                <div className="absolute right-3 top-3 grid h-6 w-6 place-items-center rounded-full bg-primary/15 font-display text-[11px] font-bold text-primary">
                  #{i + 1}
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="grid h-7 w-7 place-items-center rounded-full bg-surface-elevated text-base">
                    {p.avatar_url || "🦊"}
                  </span>
                  @{p.handle}
                </div>
                <p className="mt-3 font-display text-sm leading-snug">{p.body}</p>
                <div className="mt-3 text-[10px] uppercase tracking-widest text-primary">
                  {p.total_reactions} reactions
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      <section className="mt-6 px-5">
        <SectionHeader icon={<Sparkles className="h-3.5 w-3.5" />} title="Live verdicts" live />
        <div className="mt-3 space-y-2">
          {rest.map((p, i) => (
            <FeedRowCard
              key={p.id}
              post={p}
              i={i}
              mine={myReactionSet.get(p.id) ?? new Set()}
              signedIn={signedIn === true}
              onReact={(kind) => reactMut.mutate({ postId: p.id, kind })}
            />
          ))}
          {rest.length === 0 && feedQuery.data && feedQuery.data.length > 0 && (
            <p className="text-xs text-muted-foreground">That's everything.</p>
          )}
        </div>
      </section>
    </AppShell>
  );
}

function FeedRowCard({
  post: a,
  i,
  mine,
  signedIn,
  onReact,
}: {
  post: FeedRow;
  i: number;
  mine: Set<string>;
  signedIn: boolean;
  onReact: (kind: "hear" | "seal" | "crown") => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -14 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.2 + i * 0.05, duration: 0.35, ease: [0.22, 0.61, 0.36, 1] }}
      className="glass flex items-start gap-3 rounded-2xl p-3"
    >
      <span className="grid h-10 w-10 place-items-center rounded-full bg-surface-elevated text-xl">
        {a.avatar_url || "🦊"}
      </span>
      <div className="flex-1 leading-tight">
        <div className="text-sm">
          <span className="font-semibold">@{a.handle}</span>{" "}
          <span className="text-muted-foreground text-xs uppercase tracking-widest">{a.outcome}</span>
        </div>
        <p className="mt-1 font-display text-sm">{a.body}</p>
        <div className="mt-2 flex items-center gap-2">
          <ReactionPill icon={<Heart className="h-3 w-3" />} count={a.reactions.hear} active={mine.has("hear")} disabled={!signedIn} onClick={() => onReact("hear")} />
          <ReactionPill icon={<Sticker className="h-3 w-3" />} count={a.reactions.seal} active={mine.has("seal")} disabled={!signedIn} onClick={() => onReact("seal")} />
          <ReactionPill icon={<Crown className="h-3 w-3" />} count={a.reactions.crown} active={mine.has("crown")} disabled={!signedIn} onClick={() => onReact("crown")} />
          <span className="ml-auto text-[10px] uppercase tracking-widest text-muted-foreground">
            {timeAgo(a.created_at)}
          </span>
        </div>
      </div>
    </motion.div>
  );
}

function ReactionPill({
  icon,
  count,
  active,
  disabled,
  onClick,
}: {
  icon: React.ReactNode;
  count: number;
  active: boolean;
  disabled: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="flex items-center gap-1 rounded-full px-2 py-1 text-xs transition disabled:opacity-50"
      style={{
        background: active ? "color-mix(in oklab, var(--primary) 18%, transparent)" : "var(--surface-elevated, transparent)",
        color: active ? "var(--primary)" : "var(--muted-foreground)",
        border: "1px solid var(--color-border)",
      }}
    >
      {icon} {count}
    </button>
  );
}

function SectionHeader({ icon, title, live }: { icon: React.ReactNode; title: string; live?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-primary">
        {icon} {title}
        <Flame className="h-3 w-3 opacity-0" />
      </div>
      {live && (
        <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-muted-foreground">
          <span className="relative flex h-1.5 w-1.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-75" />
            <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-primary" />
          </span>
          Live
        </div>
      )}
    </div>
  );
}
