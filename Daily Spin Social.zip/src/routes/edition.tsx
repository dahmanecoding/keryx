import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AppShell, ScreenHeader } from "@/components/keryx/AppShell";
import { POSTS } from "@/lib/keryx-data";
import { useWeekly, isoWeekKey } from "@/lib/use-weekly";

export const Route = createFileRoute("/edition")({
  head: () => ({
    meta: [
      { title: "Collaborative Edition — Keryx" },
      { name: "description", content: "The weekly community wheel. Spin once. Vote with your landing." },
    ],
  }),
  component: EditionScreen,
});

// 24 community-submitted slices (cycled from mock POSTS).
const SLICES = Array.from({ length: 24 }, (_, i) => POSTS[i % POSTS.length]);

function EditionScreen() {
  const { state, vote } = useWeekly();
  const voted = state.votedSliceIndex !== null;
  const leaderboard = Object.entries(state.votes)
    .map(([k, v]) => ({ idx: Number(k), votes: v, post: SLICES[Number(k)] }))
    .sort((a, b) => b.votes - a.votes)
    .slice(0, 5);

  return (
    <AppShell>
      <ScreenHeader
        title="The Edition"
        subtitle={`Week ${isoWeekKey()} · Collaborative`}
      />
      <div className="px-6">
        <p className="text-sm" style={{ color: "var(--muted-foreground)" }}>
          24 slices, one vote per week. Land on a post to vote it toward the Hall of Fame.
        </p>
      </div>

      <div className="mt-5 grid grid-cols-3 gap-2 px-6">
        {SLICES.map((p, i) => {
          const isVoted = state.votedSliceIndex === i;
          return (
            <motion.button
              key={i}
              disabled={voted}
              onClick={() => vote(i)}
              whileTap={{ scale: 0.97 }}
              className="rounded-md p-2 text-left disabled:opacity-60"
              style={{
                border: `1px solid ${isVoted ? "var(--primary)" : "var(--color-border)"}`,
                background: isVoted ? "rgb(194 65 43 / 0.1)" : "var(--surface-elevated)",
                minHeight: 84,
              }}
            >
              <div
                className="mb-1 text-[8px] uppercase tabular-nums"
                style={{
                  letterSpacing: "0.2em",
                  fontFamily: "JetBrains Mono, monospace",
                  color: "var(--muted-foreground)",
                }}
              >
                № {String(i + 1).padStart(2, "0")} · {state.votes[i] ?? 0}♥
              </div>
              <p
                className="font-display italic"
                style={{
                  fontSize: 11,
                  lineHeight: 1.25,
                  color: "var(--ink)",
                  display: "-webkit-box",
                  WebkitLineClamp: 3,
                  WebkitBoxOrient: "vertical",
                  overflow: "hidden",
                }}
              >
                "{p.text}"
              </p>
            </motion.button>
          );
        })}
      </div>

      <section className="mt-6 px-6">
        <h2
          className="text-[10px] uppercase"
          style={{
            letterSpacing: "0.3em",
            fontFamily: "JetBrains Mono, monospace",
            color: "var(--ink)",
            fontWeight: 700,
          }}
        >
          Leaderboard
        </h2>
        <div className="mt-3 space-y-2">
          {leaderboard.length === 0 ? (
            <p className="text-xs" style={{ color: "var(--muted-foreground)" }}>
              No votes yet this week.
            </p>
          ) : (
            leaderboard.map((row, rank) => (
              <div
                key={row.idx}
                className="flex items-start gap-3 rounded-md p-3"
                style={{
                  background: "var(--surface-elevated)",
                  border: "1px solid var(--color-border)",
                }}
              >
                <span
                  className="font-display"
                  style={{ fontSize: 22, color: rank === 0 ? "var(--primary)" : "var(--ink)", fontWeight: 700 }}
                >
                  #{rank + 1}
                </span>
                <div className="flex-1">
                  <p className="font-display italic" style={{ fontSize: 13, color: "var(--ink)" }}>
                    "{row.post.text}"
                  </p>
                  <span
                    className="text-[9px] uppercase"
                    style={{
                      letterSpacing: "0.2em",
                      fontFamily: "JetBrains Mono, monospace",
                      color: "var(--muted-foreground)",
                    }}
                  >
                    @{row.post.handle} · {row.votes} vote{row.votes === 1 ? "" : "s"}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </AppShell>
  );
}
