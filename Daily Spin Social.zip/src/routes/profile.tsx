import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Flame, Settings, Eye, Bell, Ghost, Droplet, Sparkles } from "lucide-react";
import { AppShell, ScreenHeader } from "@/components/keryx/AppShell";
import { PerkCard } from "@/components/keryx/PerkCard";
import { BadgeChip } from "@/components/keryx/BadgeChip";
import { BADGES, getBadgeTier } from "@/lib/keryx-data";
import { PERKS, CATEGORY_LABEL, type PerkCategory } from "@/lib/perks";
import { useProfile } from "@/lib/use-profile";
import { useMotionBudget } from "@/lib/use-motion-budget";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Profile — Keryx" },
      { name: "description", content: "Your streak, wins, badges, perks, and customization." },
    ],
  }),
  component: ProfileScreen,
});

const AVATARS = ["🦊", "🐺", "🌙", "🐉", "✨", "🪐", "🦉", "🌿", "🔥", "📜", "🕯️", "⚱️", "🪶", "🗝️", "🪞", "🎭"];
const POINTER_COLORS = [
  { id: "primary", value: "var(--primary)", label: "Oxblood" },
  { id: "ink", value: "var(--ink)", label: "Ink" },
  { id: "ochre", value: "var(--ochre)", label: "Ochre" },
];
const GRAINS: { id: "linen" | "parchment" | "vellum" | "obsidian"; label: string; locked?: string }[] = [
  { id: "linen", label: "Linen" },
  { id: "parchment", label: "Parchment" },
  { id: "vellum", label: "Vellum", locked: "wheel-vellum" },
  { id: "obsidian", label: "Obsidian", locked: "wheel-obsidian" },
];

function ProfileScreen() {
  const { profile, update, perks, hasPerk, unlockPerk, inkDrops } = useProfile();
  const { reduceEffects, setReduceEffects } = useMotionBudget();
  const [anon, setAnon] = useState(false);
  const [notifs, setNotifs] = useState(true);
  const [visible, setVisible] = useState(true);
  const [perkFilter, setPerkFilter] = useState<PerkCategory | "all">("all");

  const filteredPerks = perkFilter === "all" ? PERKS : PERKS.filter((p) => p.category === perkFilter);
  const earnedCount = BADGES.filter((b) => getBadgeTier(b.count) !== null).length;

  return (
    <AppShell>
      <ScreenHeader title="Profile" subtitle="Your ritual, your wheel." />

      <header className="flex items-start justify-between px-5 pt-2">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div
              className={cn(
                "grid h-16 w-16 place-items-center rounded-full text-3xl",
                hasPerk("profile-animavatar") && !reduceEffects ? "keryx-avatar-breathe" : undefined,
              )}
              style={{
                background: "linear-gradient(135deg, rgb(194 65 43 / 0.18), rgb(218 165 32 / 0.18))",
                border: "1px solid var(--color-border)",
                willChange: hasPerk("profile-animavatar") ? "transform" : undefined,
              }}
            >
              {profile.avatar}
            </div>
            <div
              className="absolute -bottom-1 -right-1 grid h-6 w-6 place-items-center rounded-full font-display text-[11px] font-bold"
              style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
            >
              7
            </div>
          </div>
          <div>
            <h1 className="font-display text-xl font-bold">@nia.k</h1>
            {hasPerk("profile-motto") && profile.motto && (
              <p className="text-[11px] italic" style={{ color: "var(--muted-foreground)" }}>
                "{profile.motto}"
              </p>
            )}
            <p
              className="mt-0.5 flex items-center gap-1.5 text-[10px] uppercase"
              style={{
                letterSpacing: "0.2em",
                color: "var(--ochre)",
                fontFamily: "JetBrains Mono, monospace",
                fontWeight: 700,
              }}
            >
              <Droplet className="h-3 w-3" /> {inkDrops} ink drops
            </p>
          </div>
        </div>
        <button
          className="rounded-full p-2.5"
          style={{ background: "var(--surface-elevated)", border: "1px solid var(--color-border)" }}
        >
          <Settings className="h-4 w-4" />
        </button>
      </header>

      <section className="px-5 pt-5">
        <div
          className="grid grid-cols-3 divide-x rounded-lg py-4 text-center"
          style={{
            background: "var(--surface-elevated)",
            border: "1px solid var(--color-border)",
            borderColor: "var(--color-border)",
          }}
        >
          <Stat value="7" label="Streak" accent />
          <Stat value="48" label="Spins" />
          <Stat value="15" label="Wins" />
        </div>
      </section>

      {/* Customization */}
      <section className="mt-6 px-5">
        <SectionTitle>Customize</SectionTitle>
        <div
          className="mt-3 rounded-lg p-4"
          style={{ background: "var(--surface-elevated)", border: "1px solid var(--color-border)" }}
        >
          <Label>Avatar</Label>
          <div className="mt-2 grid grid-cols-8 gap-1.5">
            {AVATARS.map((a) => (
              <button
                key={a}
                onClick={() => update({ avatar: a })}
                className={cn(
                  "grid aspect-square place-items-center rounded text-lg transition",
                  profile.avatar === a ? "ring-2" : "opacity-70 hover:opacity-100",
                )}
                style={{
                  background: "var(--surface)",
                  borderColor: profile.avatar === a ? "var(--primary)" : "transparent",
                }}
              >
                {a}
              </button>
            ))}
          </div>

          <Label className="mt-4">Pointer color</Label>
          <div className="mt-2 flex gap-2">
            {POINTER_COLORS.map((c) => (
              <button
                key={c.id}
                onClick={() => update({ pointerColor: c.value })}
                className="flex items-center gap-2 rounded-full px-3 py-1.5 text-[10px] uppercase"
                style={{
                  letterSpacing: "0.2em",
                  fontFamily: "JetBrains Mono, monospace",
                  border: `1px solid ${profile.pointerColor === c.value ? c.value : "var(--color-border)"}`,
                  color: "var(--ink)",
                }}
              >
                <span className="h-3 w-3 rounded-full" style={{ background: c.value }} />
                {c.label}
              </button>
            ))}
          </div>

          <Label className="mt-4">Wheel paper</Label>
          <div className="mt-2 flex flex-wrap gap-2">
            {GRAINS.map((g) => {
              const locked = g.locked && !hasPerk(g.locked);
              const active = profile.wheelGrain === g.id;
              return (
                <button
                  key={g.id}
                  disabled={!!locked}
                  onClick={() => update({ wheelGrain: g.id })}
                  className="rounded-full px-3 py-1.5 text-[10px] uppercase transition disabled:cursor-not-allowed disabled:opacity-50"
                  style={{
                    letterSpacing: "0.2em",
                    fontFamily: "JetBrains Mono, monospace",
                    border: `1px solid ${active ? "var(--primary)" : "var(--color-border)"}`,
                    background: active ? "rgb(194 65 43 / 0.1)" : "transparent",
                    color: active ? "var(--primary)" : "var(--ink)",
                  }}
                >
                  {g.label}
                  {locked && " · locked"}
                </button>
              );
            })}
          </div>

          {hasPerk("profile-motto") && (
            <>
              <Label className="mt-4">Motto</Label>
              <input
                value={profile.motto}
                maxLength={48}
                onChange={(e) => update({ motto: e.target.value })}
                className="mt-2 w-full rounded-md px-3 py-2 text-sm focus:outline-none"
                style={{
                  background: "var(--surface)",
                  border: "1px solid var(--color-border)",
                  fontFamily: "Fraunces, serif",
                  fontStyle: "italic",
                }}
              />
            </>
          )}
        </div>
      </section>

      {/* Perks */}
      <section className="mt-6 px-5">
        <div className="flex items-end justify-between">
          <SectionTitle>Perks</SectionTitle>
          <span
            className="text-[9px] uppercase tabular-nums"
            style={{
              letterSpacing: "0.25em",
              fontFamily: "JetBrains Mono, monospace",
              color: "var(--muted-foreground)",
            }}
          >
            {perks.length} / {PERKS.length} unlocked
          </span>
        </div>

        <div className="mt-3 flex gap-1.5 overflow-x-auto pb-2 scrollbar-none">
          {(["all", "pointer", "wheel", "animation", "profile", "ritual"] as const).map((c) => {
            const active = perkFilter === c;
            return (
              <button
                key={c}
                onClick={() => setPerkFilter(c)}
                className="relative shrink-0 rounded-full px-3 py-1.5 text-[10px] uppercase"
                style={{
                  letterSpacing: "0.2em",
                  fontFamily: "JetBrains Mono, monospace",
                  color: active ? "var(--primary)" : "var(--muted-foreground)",
                }}
              >
                {active && (
                  <motion.span
                    layoutId="perk-pill"
                    className="absolute inset-0 rounded-full"
                    style={{
                      background: "rgb(194 65 43 / 0.1)",
                      border: "1px solid var(--primary)",
                    }}
                    transition={{ type: "tween", duration: 0.22, ease: [0.22, 0.61, 0.36, 1] }}
                  />
                )}
                <span className="relative">
                  {c === "all" ? "All" : CATEGORY_LABEL[c as PerkCategory]}
                </span>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <AnimatePresence mode="sync" initial={false}>
            {filteredPerks.map((p) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.18 }}
              >
                <PerkCard
                  perk={p}
                  unlocked={hasPerk(p.id)}
                  canAfford={inkDrops >= p.cost}
                  onUnlock={() => unlockPerk(p.id, p.cost)}
                />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </section>

      {/* Badges */}
      <section className="mt-6 px-5">
        <div className="mb-3 flex items-center justify-between">
          <SectionTitle>Badges</SectionTitle>
          <span
            className="text-[10px] uppercase"
            style={{
              letterSpacing: "0.2em",
              fontFamily: "JetBrains Mono, monospace",
              color: "var(--muted-foreground)",
            }}
          >
            {earnedCount} / {BADGES.length}
          </span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {BADGES.map((b, i) => (
            <BadgeChip key={b.id} badge={b} index={i} />
          ))}
        </div>
      </section>

      {/* Settings */}
      <section className="mt-6 px-5">
        <SectionTitle>Settings</SectionTitle>
        <div
          className="mt-3 divide-y overflow-hidden rounded-lg"
          style={{ background: "var(--surface-elevated)", border: "1px solid var(--color-border)" }}
        >
          <Toggle icon={<Bell className="h-4 w-4" />} label="Daily reminders" value={notifs} onChange={setNotifs} />
          <Toggle icon={<Ghost className="h-4 w-4" />} label="Anonymous mode" value={anon} onChange={setAnon} />
          <Toggle icon={<Eye className="h-4 w-4" />} label="Profile visible" value={visible} onChange={setVisible} />
          <Toggle
            icon={<Sparkles className="h-4 w-4" />}
            label="Reduce effects"
            value={reduceEffects}
            onChange={setReduceEffects}
          />
        </div>
      </section>

      <p
        className="mt-8 px-5 pb-4 text-center text-[10px] uppercase"
        style={{
          letterSpacing: "0.25em",
          fontFamily: "JetBrains Mono, monospace",
          color: "var(--muted-foreground)",
        }}
      >
        <Flame className="-mt-0.5 mr-1 inline h-3 w-3" style={{ color: "var(--primary)" }} />
        Keryx · The wheel decides
      </p>
    </AppShell>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2
      className="text-[10px] uppercase"
      style={{
        letterSpacing: "0.3em",
        fontFamily: "JetBrains Mono, monospace",
        color: "var(--ink)",
        fontWeight: 700,
      }}
    >
      {children}
    </h2>
  );
}

function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={cn("text-[9px] uppercase", className)}
      style={{
        letterSpacing: "0.25em",
        fontFamily: "JetBrains Mono, monospace",
        color: "var(--muted-foreground)",
      }}
    >
      {children}
    </div>
  );
}

function Stat({ value, label, accent }: { value: string; label: string; accent?: boolean }) {
  return (
    <div className="px-2">
      <div
        className="font-display tabular-nums"
        style={{
          fontSize: 26,
          fontWeight: 600,
          color: accent ? "var(--primary)" : "var(--ink)",
          letterSpacing: "-0.03em",
        }}
      >
        {value}
      </div>
      <div
        className="mt-0.5 text-[9px] uppercase"
        style={{
          letterSpacing: "0.25em",
          color: "var(--muted-foreground)",
          fontFamily: "JetBrains Mono, monospace",
        }}
      >
        {label}
      </div>
    </div>
  );
}

function Toggle({
  icon,
  label,
  value,
  onChange,
}: {
  icon: React.ReactNode;
  label: string;
  value: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!value)}
      className="flex w-full items-center gap-3 px-4 py-3.5 text-left transition"
    >
      <span style={{ color: "var(--muted-foreground)" }}>{icon}</span>
      <span className="flex-1 text-sm">{label}</span>
      <span
        className="relative h-6 w-10 rounded-full transition-colors"
        style={{ background: value ? "var(--primary)" : "var(--muted)" }}
      >
        <span
          className="absolute top-0.5 h-5 w-5 rounded-full transition-transform"
          style={{
            background: "var(--paper)",
            transform: `translateX(${value ? 18 : 2}px)`,
            willChange: "transform",
          }}
        />
      </span>
    </button>
  );
}
