import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { motion } from "framer-motion";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { AppShell } from "@/components/keryx/AppShell";
import { Wheel, type WheelHandle } from "@/components/keryx/Wheel";
import { ResultSheet } from "@/components/keryx/ResultSheet";
import { OddsMeter } from "@/components/keryx/OddsMeter";
import { StreakBadge } from "@/components/keryx/StreakBadge";
import { StreakRiskTimer } from "@/components/keryx/StreakRiskTimer";

import { CurseBanner } from "@/components/keryx/CurseBanner";
import { DraftBarrel } from "@/components/keryx/DraftBarrel";
import { WagerStrip, type WagerSelection } from "@/components/keryx/WagerStrip";
import { AnimatedCounter } from "@/lib/use-counter";
import { SLICES, type Slice } from "@/lib/keryx-data";
import { useResetCountdown, formatCountdown } from "@/lib/use-reset-countdown";
import { useProfile, useLastSpin } from "@/lib/use-profile";
import { getWheelTier, getNextTier } from "@/lib/wheel-tiers";

import { chanceFromSeed, todayKey } from "@/lib/use-daily-seed";
import { useDayState } from "@/lib/use-day-state";
import { useDrafts } from "@/lib/use-drafts";
import { usePendingWin, formatHoursLeft } from "@/lib/use-pending-win";
import {
  performSpin,
  getPlayerStats,
  publishPendingWin,
  discardPendingWin,
} from "@/lib/gameplay.functions";
import { supabase } from "@/integrations/supabase/client";
import { Clock3 } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Keryx — Spin to post" },
      { name: "description", content: "A daily spin-based social posting ritual." },
      { property: "og:title", content: "Keryx — Spin to post" },
      { property: "og:description", content: "A daily spin-based social posting ritual." },
    ],
  }),
  component: SpinScreen,
});

function SpinScreen() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const performSpinFn = useServerFn(performSpin);
  const getPlayerStatsFn = useServerFn(getPlayerStats);
  const publishPendingWinFn = useServerFn(publishPendingWin);
  const discardPendingWinFn = useServerFn(discardPendingWin);

  const [signedIn, setSignedIn] = useState<boolean | null>(null);
  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(({ data }) => {
      if (mounted) setSignedIn(!!data.user);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      if (mounted) setSignedIn(!!s?.user);
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const statsQuery = useQuery({
    queryKey: ["player_stats"],
    queryFn: () => getPlayerStatsFn(),
    enabled: signedIn === true,
    staleTime: 10_000,
  });

  const [result, setResult] = useState<Slice | null>(null);
  const [nearMissPrize, setNearMissPrize] = useState<Slice | null>(null);
  const [coinFaces, setCoinFaces] = useState<[0 | 1, 0 | 1] | null>(null);
  const [bonusOdds, setBonusOdds] = useState(false);
  const [rareBias, setRareBias] = useState(false);
  const [focus, setFocus] = useState(0);
  const [edition, setEdition] = useState<number | null>(null);
  const [wager, setWager] = useState<WagerSelection | null>(null);
  const [activeWager, setActiveWager] = useState<WagerSelection | null>(null);
  const wheelRef = useRef<WheelHandle>(null);
  const pendingWinIdRef = useRef<string | null>(null);

  const streak = statsQuery.data?.streak ?? 0;
  const totalSpins = statsQuery.data?.spins_total ?? 0;
  const wins = statsQuery.data?.wins_total ?? 0;
  const winRate = Math.round((wins / Math.max(1, totalSpins)) * 100);

  const { profile, perks } = useProfile();
  const { hasSpunToday } = useLastSpin();
  const { msLeft, stage, atRisk } = useResetCountdown(hasSpunToday);
  const { state: dayState, update: updateDayState } = useDayState();
  const { drafts, add: addDraft, remove: removeDraft, ripeness } = useDrafts();
  const { pending, save: savePending, clear: clearPending, msLeft: pendingMsLeft } = usePendingWin();

  const tier = getWheelTier(streak);
  const nextTier = getNextTier(streak);

  const isCursed = useMemo(() => chanceFromSeed(`curse:${todayKey()}`, 1 / 7), []);

  useEffect(() => {
    const epoch = new Date("2026-06-04T00:00:00Z").getTime();
    const days = Math.floor((Date.now() - epoch) / 86_400_000);
    setEdition(Math.max(1, days + 1));
  }, []);

  const forceMiss = isCursed && !dayState.curseUsed;

  const resumingRef = useRef(false);

  /** Server-authoritative outcome resolver passed to the Wheel. */
  const fetchTargetIndex = useCallback(async () => {
    if (signedIn !== true) {
      navigate({ to: "/auth" });
      throw new Error("not signed in");
    }
    const res = await performSpinFn({
      data: {
        calledShot: (activeWager?.type ?? wager?.type ?? null) as
          | "win" | "miss" | "rare" | "bonus" | "jolly" | null,
        forceMiss,
        rareBias,
        bonusOdds,
      },
    });
    pendingWinIdRef.current = res.pending_win_id;
    // Optimistically update stats cache from the server response.
    queryClient.setQueryData(["player_stats"], res.stats);
    return res.slice_index;
  }, [signedIn, navigate, performSpinFn, activeWager, wager, forceMiss, rareBias, bonusOdds, queryClient]);

  function handleClose() {
    if (result && !resumingRef.current) {
      // Stats already updated by the server. Just clear local modifiers
      // and refresh from server in the background.
      if (activeWager && activeWager.type === result.type) {
        setBonusOdds(true);
      }
      setActiveWager(null);
      updateDayState({
        spinsToday: dayState.spinsToday + 1,
        curseUsed: dayState.curseUsed || forceMiss,
        doubleOrNothingChain: 0,
      });
      queryClient.invalidateQueries({ queryKey: ["player_stats"] });
    }
    resumingRef.current = false;
    setResult(null);
    setNearMissPrize(null);
    setCoinFaces(null);
  }

  function handleResult(s: Slice, nm?: Slice | null) {
    setNearMissPrize(nm ?? null);
    if (s.type === "jolly") {
      setCoinFaces([
        (Math.random() < 0.5 ? 0 : 1) as 0 | 1,
        (Math.random() < 0.5 ? 0 : 1) as 0 | 1,
      ]);
    } else {
      setCoinFaces(null);
    }
    if (bonusOdds) setBonusOdds(false);
    if (rareBias) setRareBias(false);
    setResult(s);
  }

  function handleDraft() {
    const text = window.prompt("Draft a post idea — it ripens in 24h:");
    if (text && text.trim()) {
      addDraft(text.trim().slice(0, 180));
      // Debit wager already happened on spin; just close.
      setActiveWager(null);
      setResult(null);
    }
  }

  function handleDoubleOrNothing() {
    if (!result) return;
    updateDayState({ doubleOrNothingChain: dayState.doubleOrNothingChain + 1 });
    setBonusOdds(true);
    setResult(null);
    setNearMissPrize(null);
  }

  function handleDevelopDraft(d: { id: string; text: string }) {
    removeDraft(d.id);
    setRareBias(true);
  }

  function onSpinClick(e: React.MouseEvent) {
    const target = e.target as HTMLElement;
    if (!target.closest('button[aria-label="Spin"]')) return;
    if (wager) {
      setActiveWager(wager);
      setWager(null);
    }
  }

  const isPanic = stage === "panic" && atRisk;
  const editionShouldPulse = (stage === "warn" || stage === "alarm") && atRisk;

  return (
    <AppShell>
      <motion.div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-30"
        animate={{ opacity: focus }}
        transition={{ duration: 0.15 }}
        style={{ background: "var(--ink)", opacity: 0 }}
      />

      <header className="relative z-10 flex items-end justify-between px-6 pt-8">
        <div className="flex flex-col">
          <motion.span
            className="text-[9px] uppercase tabular-nums"
            animate={editionShouldPulse ? { opacity: [1, 0.5, 1] } : { opacity: 1 }}
            transition={
              editionShouldPulse
                ? { duration: 1.4, repeat: Infinity }
                : { duration: 0.3 }
            }
            style={{
              letterSpacing: "0.35em",
              color: "var(--primary)",
              fontFamily: "JetBrains Mono, monospace",
            }}
          >
            № {edition !== null ? edition.toString().padStart(3, "0") : "—"} · Daily Ritual
          </motion.span>
          <h1
            className="font-display italic"
            style={{
              fontSize: 40,
              fontWeight: 500,
              letterSpacing: "-0.04em",
              color: "var(--ink)",
              lineHeight: 1,
            }}
          >
            Keryx
          </h1>
          <span
            className="mt-0.5 text-[10px]"
            style={{
              color: "var(--muted-foreground)",
              fontFamily: "JetBrains Mono, monospace",
              letterSpacing: "0.1em",
            }}
          >
            {tier.name}
            {nextTier && (
              <span style={{ opacity: 0.6 }}>
                {" "}· {nextTier.minStreak - streak} to {nextTier.name}
              </span>
            )}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <DraftBarrel
            drafts={drafts}
            ripeness={ripeness}
            onDevelop={handleDevelopDraft}
            onDiscard={removeDraft}
          />
          <StreakBadge streak={streak} />
        </div>
      </header>

      <StreakRiskTimer msLeft={msLeft} stage={stage} atRisk={atRisk} />

      
      {isCursed && <CurseBanner used={dayState.curseUsed} />}

      <div className="mx-6 mt-4 h-px" style={{ background: "var(--color-border)" }} />

      <div className="relative z-10 mt-5 px-6">
        <p
          className="text-[9px] uppercase"
          style={{
            letterSpacing: "0.3em",
            color: "var(--muted-foreground)",
            fontFamily: "JetBrains Mono, monospace",
          }}
        >
          Today's Winner — @theo_
        </p>
        <blockquote
          className="mt-1 font-display italic"
          style={{
            fontSize: 18,
            lineHeight: 1.25,
            letterSpacing: "-0.015em",
            color: "var(--ink)",
            fontWeight: 400,
          }}
        >
          "Just told my barista I love her. The wheel made me do it."
        </blockquote>
      </div>

      <div className="mx-6 mt-5 h-px" style={{ background: "var(--color-border)" }} />

      <motion.div
        className="relative z-40 mt-6 flex flex-col items-center justify-center px-6"
        animate={isPanic ? { x: [0, -2, 2, -1, 1, 0], y: [0, 1, -1, 1, 0, 0] } : { x: 0, y: 0 }}
        transition={isPanic ? { duration: 0.18, repeat: Infinity } : { duration: 0 }}
        onClickCapture={onSpinClick}
      >
        <Wheel
          ref={wheelRef}
          streak={streak}
          perks={perks}
          pointerColor={profile.pointerColor}
          bonusOdds={bonusOdds}
          forceMiss={forceMiss}
          rareBias={rareBias}
          disabled={signedIn === false}
          highlightType={wager?.type ?? null}
          onFocusChange={setFocus}
          onResult={handleResult}
          getTargetIndex={fetchTargetIndex}
        />
      </motion.div>

      <WagerStrip
        wager={wager}
        onChange={setWager}
        disabled={!!result || forceMiss}
      />

      {pending && !result && (
        <button
          onClick={() => {
            resumingRef.current = true;
            setResult(pending.slice);
          }}
          className="mx-6 mt-4 flex w-[calc(100%-3rem)] items-center justify-between rounded-lg px-4 py-3 text-left transition hover:translate-y-[-1px]"
          style={{
            border: "1px dashed var(--primary)",
            background: "color-mix(in oklab, var(--primary) 8%, var(--paper))",
            boxShadow: "0 1px 0 color-mix(in oklab, var(--ink) 5%, transparent)",
          }}
        >
          <div className="flex items-center gap-3">
            <Clock3 className="h-4 w-4" style={{ color: "var(--primary)" }} />
            <div className="flex flex-col">
              <span
                className="text-[9px] uppercase"
                style={{
                  letterSpacing: "0.3em",
                  color: "var(--primary)",
                  fontFamily: "JetBrains Mono, monospace",
                  fontWeight: 700,
                }}
              >
                Held utterance
              </span>
              <span
                className="font-display italic"
                style={{ color: "var(--ink)", fontSize: 14, lineHeight: 1.2 }}
              >
                "{pending.text.slice(0, 40)}{pending.text.length > 40 ? "…" : ""}"
              </span>
            </div>
          </div>
          <span
            className="text-[10px] tabular-nums"
            style={{
              color: "var(--muted-foreground)",
              fontFamily: "JetBrains Mono, monospace",
              letterSpacing: "0.15em",
            }}
          >
            {formatHoursLeft(pendingMsLeft)} left
          </span>
        </button>
      )}

      <div className="relative z-10 mt-6 px-6">
        <OddsMeter />
      </div>

      <div
        className="relative z-10 mt-8 grid grid-cols-3 px-6 py-6"
        style={{ borderTop: "1px solid var(--color-border)" }}
      >
        <StaticStat value={formatCountdown(msLeft)} label="Next Reset" />
        <AnimatedStat value={winRate} suffix="%" label="Win Rate" highlight />
        <AnimatedStat value={totalSpins} label="Total" />
      </div>


      <ResultSheet
        slice={result}
        nearMissPrize={nearMissPrize}
        coinFaces={coinFaces}
        onClose={handleClose}
        onJollyBonusGranted={() => setBonusOdds(true)}
        onDraft={handleDraft}
        onDoubleOrNothing={handleDoubleOrNothing}
        doubleChain={dayState.doubleOrNothingChain}
        initialText={pending && result && pending.slice.id === result.id ? pending.text : undefined}
        onPendingSave={(text) => result && savePending(result, text)}
        onPosted={async (text?: string) => {
          const pendingId = pendingWinIdRef.current;
          if (pendingId && text && text.trim()) {
            try {
              await publishPendingWinFn({ data: { pendingId, body: text.trim() } });
              pendingWinIdRef.current = null;
            } catch (e) {
              console.error("publish failed", e);
            }
          } else if (pendingId) {
            try { await discardPendingWinFn({ data: { pendingId } }); } catch { /* noop */ }
            pendingWinIdRef.current = null;
          }
          clearPending();
        }}
      />
    </AppShell>
  );
}

function StatShell({ children, label }: { children: React.ReactNode; label: string }) {
  return (
    <div
      className={"flex flex-col items-center " + (label === "Win Rate" ? "border-x" : "")}
      style={label === "Win Rate" ? { borderColor: "var(--color-border)" } : undefined}
    >
      {children}
      <span
        className="mt-1 text-[9px] uppercase"
        style={{
          letterSpacing: "0.25em",
          color: "var(--muted-foreground)",
          fontFamily: "JetBrains Mono, monospace",
        }}
      >
        {label}
      </span>
    </div>
  );
}

function StaticStat({ value, label }: { value: string; label: string }) {
  return (
    <StatShell label={label}>
      <span
        className="tabular-nums"
        style={{
          fontFamily: "JetBrains Mono, ui-monospace, monospace",
          color: "var(--ink)",
          fontSize: 16,
          fontWeight: 600,
          letterSpacing: "-0.02em",
        }}
      >
        {value}
      </span>
    </StatShell>
  );
}

function AnimatedStat({
  value,
  label,
  suffix,
  highlight,
}: {
  value: number;
  label: string;
  suffix?: string;
  highlight?: boolean;
}) {
  return (
    <StatShell label={label}>
      <AnimatedCounter
        value={value}
        format={(n) => Math.round(n).toString() + (suffix ?? "")}
        className="tabular-nums"
        style={{
          fontFamily: "JetBrains Mono, ui-monospace, monospace",
          color: highlight ? "var(--primary)" : "var(--ink)",
          fontSize: 18,
          fontWeight: 600,
          letterSpacing: "-0.02em",
        }}
      />
    </StatShell>
  );
}

