import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Search, Heart } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { AppShell, ScreenHeader } from "@/components/keryx/AppShell";
import { POSTS, MOODS, VERDICTS, type Post, type Verdict } from "@/lib/keryx-data";
import { cn } from "@/lib/utils";


export const Route = createFileRoute("/archive")({
  head: () => ({
    meta: [
      { title: "Archive — Keryx" },
      { name: "description", content: "Past winning moments from the Keryx community." },
    ],
  }),
  component: ArchiveScreen,
});

function ArchiveScreen() {
  const [mood, setMood] = useState<(typeof MOODS)[number]>("all");
  const [q, setQ] = useState("");
  const [tab, setTab] = useState<"verdicts" | "feed">("verdicts");
  const [verdictFilter, setVerdictFilter] = useState<"all" | "WIN" | "RARE" | "MISS">("all");

  const filtered = POSTS.filter(
    (p) =>
      (mood === "all" || p.mood === mood) &&
      (q === "" || p.text.toLowerCase().includes(q.toLowerCase())),
  );
  const filteredVerdicts = VERDICTS.filter(
    (v) => verdictFilter === "all" || v.result === verdictFilter,
  );


  return (
    <AppShell>
      <ScreenHeader title="Archive" subtitle="A living memory of moments." />

      {/* Tab switcher */}
      <div className="px-5">
        <div
          className="relative flex rounded-full p-1"
          style={{ border: "1px solid var(--color-border)", background: "var(--surface-elevated)" }}
        >
          {(["verdicts", "feed"] as const).map((t) => (

            <button
              key={t}
              onClick={() => setTab(t)}
              className="relative flex-1 rounded-full py-2 text-[10px] uppercase transition-colors"
              style={{
                letterSpacing: "0.25em",
                fontFamily: "JetBrains Mono, monospace",
                color: tab === t ? "var(--paper)" : "var(--muted-foreground)",
                zIndex: 1,
              }}
            >
              {tab === t && (
                <motion.span
                  layoutId="archive-tab-pill"
                  className="absolute inset-0 rounded-full"
                  style={{ background: "var(--ink)", zIndex: -1 }}
                  transition={{ type: "tween", duration: 0.22, ease: [0.22, 0.61, 0.36, 1] }}
                />
              )}
              {t === "verdicts" ? "My Tickets" : "Public Feed"}
            </button>
          ))}
        </div>
      </div>


      {tab === "verdicts" ? (
        <div className="mt-5 px-5">
          <div className="mb-3 flex items-center justify-between">
            <p
              className="text-[9px] uppercase"
              style={{
                letterSpacing: "0.3em",
                color: "var(--muted-foreground)",
                fontFamily: "JetBrains Mono, monospace",
              }}
            >
              Your verdicts
            </p>
            <div className="flex gap-1">
              {(["all", "WIN", "RARE", "MISS"] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setVerdictFilter(f)}
                  className="relative rounded-full px-2.5 py-1 text-[9px] uppercase"
                  style={{
                    letterSpacing: "0.2em",
                    fontFamily: "JetBrains Mono, monospace",
                    color: verdictFilter === f ? "var(--primary)" : "var(--muted-foreground)",
                  }}
                >
                  {verdictFilter === f && (
                    <motion.span
                      layoutId="verdict-filter-pill"
                      className="absolute inset-0 rounded-full"
                      style={{ background: "rgb(194 65 43 / 0.1)", border: "1px solid var(--primary)" }}
                      transition={{ type: "tween", duration: 0.22, ease: [0.22, 0.61, 0.36, 1] }}
                    />
                  )}
                  <span className="relative">{f === "all" ? "All" : f}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <AnimatePresence mode="sync" initial={false}>
              {filteredVerdicts.map((v, i) => (
                <motion.div
                  key={v.id}
                  initial={{ opacity: 0, y: 10, rotate: -1.5 }}
                  animate={{ opacity: 1, y: 0, rotate: 0 }}
                  exit={{ opacity: 0, y: -10, rotate: 1.5 }}
                  transition={{ delay: Math.min(i, 6) * 0.04, duration: 0.32, ease: [0.22, 0.61, 0.36, 1] }}
                >
                  <VerdictTicket verdict={v} />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      ) : (

        <>
          <div className="mt-3 px-5">
            <div
              className="flex items-center gap-2 rounded-full px-4 py-2.5"
              style={{ border: "1px solid var(--color-border)", background: "var(--surface-elevated)" }}
            >
              <Search className="h-4 w-4" style={{ color: "var(--muted-foreground)" }} />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search moments…"
                className="w-full bg-transparent text-sm focus:outline-none"
                style={{ color: "var(--ink)" }}
              />
            </div>
          </div>

          <div className="mt-3 flex gap-2 overflow-x-auto px-5 pb-2 scrollbar-none">
            {MOODS.map((m) => (
              <button
                key={m}
                onClick={() => setMood(m)}
                className={cn(
                  "shrink-0 rounded-full border px-4 py-1.5 text-[10px] uppercase transition",
                )}
                style={{
                  letterSpacing: "0.2em",
                  fontFamily: "JetBrains Mono, monospace",
                  borderColor: mood === m ? "var(--primary)" : "var(--color-border)",
                  background: mood === m ? "rgb(194 65 43 / 0.1)" : "transparent",
                  color: mood === m ? "var(--primary)" : "var(--muted-foreground)",
                }}
              >
                {m}
              </button>
            ))}
          </div>

          <div className="space-y-3 px-5 pt-3">
            {filtered.map((p) => (
              <PostCard key={p.id} post={p} />
            ))}
            {filtered.length === 0 && (
              <div
                className="rounded-2xl border border-dashed p-8 text-center text-sm"
                style={{ borderColor: "var(--color-border)", color: "var(--muted-foreground)" }}
              >
                No moments match that yet.
              </div>
            )}
          </div>
        </>
      )}
    </AppShell>
  );
}

const RESULT_COLOR: Record<Verdict["result"], { fg: string; bg: string }> = {
  WIN: { fg: "var(--primary-foreground)", bg: "var(--primary)" },
  RARE: { fg: "var(--paper)", bg: "var(--rare)" },
  BONUS: { fg: "var(--ink)", bg: "var(--ochre)" },
  MISS: { fg: "var(--muted-foreground)", bg: "transparent" },
};

function VerdictTicket({ verdict }: { verdict: Verdict }) {
  const c = RESULT_COLOR[verdict.result];
  const isWin = verdict.result !== "MISS";

  return (
    <article
      className="relative overflow-hidden rounded-lg"
      style={{
        background: "var(--surface-elevated)",
        border: "1px solid var(--color-border)",
        boxShadow: isWin ? "0 1px 0 rgb(15 13 11 / 0.06), 0 8px 24px -16px rgb(194 65 43 / 0.3)" : undefined,
      }}
    >
      {/* Perforated tear-edge */}
      <div
        aria-hidden
        className="absolute top-0 bottom-0 left-[68px]"
        style={{
          width: 1,
          backgroundImage: "linear-gradient(to bottom, var(--color-border) 50%, transparent 50%)",
          backgroundSize: "1px 6px",
        }}
      />

      <div className="flex">
        {/* Stub */}
        <div
          className="flex w-[68px] flex-col items-center justify-center py-4"
          style={{ background: c.bg }}
        >
          <span
            className="text-[8px] uppercase tabular-nums"
            style={{
              letterSpacing: "0.2em",
              color: isWin ? c.fg : "var(--muted-foreground)",
              fontFamily: "JetBrains Mono, monospace",
              opacity: 0.7,
            }}
          >
            № {verdict.edition.toString().padStart(3, "0")}
          </span>
          <span
            className="mt-0.5 font-display italic"
            style={{
              fontSize: 22,
              fontWeight: 600,
              color: isWin ? c.fg : "var(--ink)",
              letterSpacing: "-0.03em",
              lineHeight: 1,
            }}
          >
            {verdict.date.split(" ")[1]}
          </span>
          <span
            className="text-[8px] uppercase"
            style={{
              letterSpacing: "0.2em",
              color: isWin ? c.fg : "var(--muted-foreground)",
              fontFamily: "JetBrains Mono, monospace",
              opacity: 0.7,
            }}
          >
            {verdict.date.split(" ")[0]}
          </span>
        </div>

        {/* Body */}
        <div className="flex-1 px-4 py-3">
          <div className="flex items-center justify-between">
            <span
              className="text-[10px] uppercase"
              style={{
                letterSpacing: "0.3em",
                fontFamily: "JetBrains Mono, monospace",
                color: isWin ? "var(--primary)" : "var(--muted-foreground)",
                fontWeight: 700,
              }}
            >
              {verdict.result}
            </span>
            <span
              className="text-[10px] tabular-nums"
              style={{
                fontFamily: "JetBrains Mono, monospace",
                color: "var(--muted-foreground)",
              }}
            >
              slice {verdict.sliceNumber.toString().padStart(2, "0")} / 24
            </span>
          </div>
          <p
            className="mt-1 font-display italic"
            style={{
              fontSize: 15,
              lineHeight: 1.3,
              color: verdict.note ? "var(--ink)" : "var(--muted-foreground)",
              fontWeight: 400,
            }}
          >
            {verdict.note ?? "Nothing said."}
          </p>
        </div>
      </div>
    </article>
  );
}

const MOOD_COLOR: Record<Post["mood"], string> = {
  deep: "text-primary",
  funny: "text-amber-600",
  wild: "text-fuchsia-600",
  felt: "text-rose-600",
};

function PostCard({ post }: { post: Post }) {
  return (
    <article
      className="rounded-lg p-4"
      style={{ background: "var(--surface-elevated)", border: "1px solid var(--color-border)" }}
    >
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <span
            className="grid h-7 w-7 place-items-center rounded-full text-base"
            style={{ background: "var(--surface)" }}
          >
            {post.avatar}
          </span>
          <span className="font-medium" style={{ color: "var(--ink)" }}>@{post.handle}</span>
          <span style={{ color: "var(--muted-foreground)" }}>· {post.time}</span>
        </div>
        <span
          className={cn("text-[9px] uppercase", MOOD_COLOR[post.mood])}
          style={{ letterSpacing: "0.25em", fontFamily: "JetBrains Mono, monospace" }}
        >
          {post.mood}
        </span>
      </div>
      <p
        className="mt-3 font-display italic"
        style={{ fontSize: 15, lineHeight: 1.35, color: "var(--ink)" }}
      >
        {post.text}
      </p>
      <div className="mt-3 flex items-center gap-3 text-xs" style={{ color: "var(--muted-foreground)" }}>
        <button className="flex items-center gap-1 transition hover:text-primary">
          <Heart className="h-3.5 w-3.5" /> {post.reactions}
        </button>
      </div>
    </article>
  );
}
