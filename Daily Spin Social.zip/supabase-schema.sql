-- =====================================================================
-- KERYX — Supabase schema
-- Run this entire file in your Supabase SQL Editor (Project → SQL Editor).
-- Safe to re-run: every statement is idempotent.
-- =====================================================================

-- ---------- Extensions ----------
create extension if not exists "pgcrypto";

-- ---------- Enums ----------
do $$ begin
  create type public.app_role as enum ('admin', 'user');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.spin_outcome as enum ('post', 'rare', 'bonus', 'jolly', 'miss');
exception when duplicate_object then null; end $$;

-- ---------- profiles ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  handle text unique,
  display_name text,
  motto text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

grant select on public.profiles to anon;
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;

alter table public.profiles enable row level security;

drop policy if exists "profiles_public_read" on public.profiles;
create policy "profiles_public_read" on public.profiles for select using (true);

drop policy if exists "profiles_self_insert" on public.profiles;
create policy "profiles_self_insert" on public.profiles for insert with check (auth.uid() = id);

drop policy if exists "profiles_self_update" on public.profiles;
create policy "profiles_self_update" on public.profiles for update using (auth.uid() = id);

-- ---------- user_roles ----------
create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  unique (user_id, role)
);

grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;

alter table public.user_roles enable row level security;

drop policy if exists "user_roles_self_read" on public.user_roles;
create policy "user_roles_self_read" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- ---------- player_stats (counters: spins, streak, ink drops) ----------
create table if not exists public.player_stats (
  user_id uuid primary key references auth.users(id) on delete cascade,
  spins_today int not null default 0,
  spins_total int not null default 0,
  streak int not null default 0,
  last_spin_date date,
  wins_total int not null default 0,
  ink_drops int not null default 0,
  updated_at timestamptz not null default now()
);

grant select, insert, update on public.player_stats to authenticated;
grant all on public.player_stats to service_role;
alter table public.player_stats enable row level security;

drop policy if exists "stats_self_read" on public.player_stats;
create policy "stats_self_read" on public.player_stats for select to authenticated using (auth.uid() = user_id);

drop policy if exists "stats_self_write" on public.player_stats;
create policy "stats_self_write" on public.player_stats for update to authenticated using (auth.uid() = user_id);

drop policy if exists "stats_self_insert" on public.player_stats;
create policy "stats_self_insert" on public.player_stats for insert to authenticated with check (auth.uid() = user_id);

-- ---------- spins (history) ----------
create table if not exists public.spins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  outcome public.spin_outcome not null,
  slice_index int not null,
  called_shot public.spin_outcome,
  bonus_awarded boolean not null default false,
  seed text,
  created_at timestamptz not null default now()
);

create index if not exists spins_user_created_idx on public.spins (user_id, created_at desc);

grant select, insert on public.spins to authenticated;
grant all on public.spins to service_role;
alter table public.spins enable row level security;

drop policy if exists "spins_self_read" on public.spins;
create policy "spins_self_read" on public.spins for select to authenticated using (auth.uid() = user_id);

-- inserts only via server fn using service role; deny direct insert
drop policy if exists "spins_no_direct_insert" on public.spins;
create policy "spins_no_direct_insert" on public.spins for insert to authenticated with check (false);

-- ---------- posts (the published utterances) ----------
create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  spin_id uuid references public.spins(id) on delete set null,
  outcome public.spin_outcome not null,
  body text not null check (char_length(body) between 1 and 600),
  created_at timestamptz not null default now()
);

create index if not exists posts_created_idx on public.posts (created_at desc);
create index if not exists posts_user_idx on public.posts (user_id, created_at desc);

grant select on public.posts to anon;
grant select, insert, delete on public.posts to authenticated;
grant all on public.posts to service_role;
alter table public.posts enable row level security;

drop policy if exists "posts_public_read" on public.posts;
create policy "posts_public_read" on public.posts for select using (true);

drop policy if exists "posts_self_insert" on public.posts;
create policy "posts_self_insert" on public.posts for insert to authenticated with check (auth.uid() = user_id);

drop policy if exists "posts_self_delete" on public.posts;
create policy "posts_self_delete" on public.posts for delete to authenticated using (auth.uid() = user_id);

-- ---------- reactions ----------
create table if not exists public.reactions (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('hear','seal','crown')),
  created_at timestamptz not null default now(),
  unique (post_id, user_id, kind)
);

create index if not exists reactions_post_idx on public.reactions (post_id);

grant select on public.reactions to anon;
grant select, insert, delete on public.reactions to authenticated;
grant all on public.reactions to service_role;
alter table public.reactions enable row level security;

drop policy if exists "reactions_public_read" on public.reactions;
create policy "reactions_public_read" on public.reactions for select using (true);

drop policy if exists "reactions_self_insert" on public.reactions;
create policy "reactions_self_insert" on public.reactions for insert to authenticated with check (auth.uid() = user_id);

drop policy if exists "reactions_self_delete" on public.reactions;
create policy "reactions_self_delete" on public.reactions for delete to authenticated using (auth.uid() = user_id);

-- ---------- drafts ----------
create table if not exists public.drafts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  body text not null default '',
  updated_at timestamptz not null default now()
);

create index if not exists drafts_user_idx on public.drafts (user_id, updated_at desc);

grant select, insert, update, delete on public.drafts to authenticated;
grant all on public.drafts to service_role;
alter table public.drafts enable row level security;

drop policy if exists "drafts_self_all" on public.drafts;
create policy "drafts_self_all" on public.drafts for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ---------- pending_wins (24h window to publish a win) ----------
create table if not exists public.pending_wins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  spin_id uuid not null references public.spins(id) on delete cascade,
  outcome public.spin_outcome not null,
  body text not null default '',
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

create index if not exists pending_wins_user_idx on public.pending_wins (user_id, expires_at desc);

grant select, insert, update, delete on public.pending_wins to authenticated;
grant all on public.pending_wins to service_role;
alter table public.pending_wins enable row level security;

drop policy if exists "pending_wins_self_all" on public.pending_wins;
create policy "pending_wins_self_all" on public.pending_wins for all to authenticated
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ---------- badges (evolutions: basic → gold → diamond → platinum → obsidian) ----------
create table if not exists public.badges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null,            -- e.g. 'rare', 'bonus', 'jolly', 'streak_7'
  hit_count int not null default 1,
  first_hit_at timestamptz not null default now(),
  last_hit_at timestamptz not null default now(),
  unique (user_id, kind)
);

grant select on public.badges to anon;
grant select on public.badges to authenticated;
grant all on public.badges to service_role;
alter table public.badges enable row level security;

drop policy if exists "badges_public_read" on public.badges;
create policy "badges_public_read" on public.badges for select using (true);

-- ---------- auto-create profile on signup ----------
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name, handle)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'handle', split_part(new.email, '@', 1))
  )
  on conflict (id) do nothing;

  insert into public.player_stats (user_id) values (new.id)
  on conflict (user_id) do nothing;

  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- updated_at touch helper ----------
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists profiles_touch on public.profiles;
create trigger profiles_touch before update on public.profiles
  for each row execute function public.touch_updated_at();

drop trigger if exists drafts_touch on public.drafts;
create trigger drafts_touch before update on public.drafts
  for each row execute function public.touch_updated_at();

drop trigger if exists stats_touch on public.player_stats;
create trigger stats_touch before update on public.player_stats
  for each row execute function public.touch_updated_at();
