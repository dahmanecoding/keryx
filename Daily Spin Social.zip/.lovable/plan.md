# Phase 2: Server-authoritative gameplay

Schema is live. Now move spin logic and persistence off the client.

## 1. Server-side spin RPC (migration)
Add a Postgres function `public.perform_spin(called_shot int)` (SECURITY DEFINER) that:
- Reads `auth.uid()`; rejects if null.
- Reads/locks the caller's `player_stats` row.
- Enforces daily spin cap and resets `spins_today` when `last_spin_date` changed.
- Generates outcome + `slice_index` server-side using `gen_random_bytes` (seed stored on row).
- Inserts into `spins`, updates `player_stats` (spins_today, spins_total, streak, last_spin_date, wins_total, ink_drops).
- On win, inserts a `pending_wins` row with a 10-minute `expires_at` (user must publish/discard).
- Returns the spin row + pending_win id.

Grant execute to `authenticated` only. No direct INSERT on `spins` / `player_stats` from clients (already blocked by `spins_no_direct_insert`).

## 2. Replace localStorage hooks
Swap these four hooks to use Supabase via TanStack Query + `requireSupabaseAuth` server functions (or direct browser client where RLS suffices):

- `usePlayerStats` → select from `player_stats` (browser client, RLS).
- `useSpin` → call `perform_spin` RPC; invalidate stats + pending wins on success.
- `useDrafts` → CRUD on `drafts` table.
- `usePosts` / `useReactions` → CRUD on `posts` + `reactions`, with realtime subscription for the feed.

Pending win flow:
- After spin win, UI reads the `pending_wins` row.
- "Publish" → server fn moves body into `posts` and deletes pending_win.
- "Discard" or expiry → delete pending_win (cron or on-read cleanup).

## 3. Auth wiring sanity check
Confirm `attachSupabaseAuth` is in `src/start.ts` middleware so RPC + protected fns get the bearer.

## 4. Verification
- Sign in, spin → row appears in `spins`, stats increment, pending_win created on win.
- Publish → post visible in feed across sessions.
- Refresh browser → state persists (no more localStorage).
- Second device shows same stats.

## Technical notes
- All new server functions live in `src/lib/*.functions.ts` (client-reachable; never import `client.server` at module scope).
- Game/feed routes stay under `src/routes/_authenticated/`.
- Public landing route loaders must not call protected fns.
- Realtime: subscribe in component `useEffect`, not in loader.

## Not in this phase
- Badges awarding logic (table exists; trigger can come next).
- Admin tooling / moderation.
- Rate limiting beyond daily cap.
